package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.AssistantAppearanceConfig
import com.example.data.repository.AssistantColorTheme
import com.example.data.repository.AssistantLanguage
import com.example.data.repository.AssistantPersonality
import com.example.data.repository.AssistantPreferencesManager
import com.example.data.repository.AssistantShape
import com.example.data.repository.WAKE_WORD_PRESETS
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("JARVIS", appName)
    }

    @Test
    fun `test assistant appearance preferences persistence`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = AssistantPreferencesManager(context)

        // Default configuration check
        val initialConfig = prefs.configFlow.value
        assertEquals("Hey Jarvis", initialConfig.wakeWordPreset)
        assertEquals(true, initialConfig.wakeWordEnabled)
        assertEquals(AssistantShape.CURVED_PILL, initialConfig.shape)
        assertEquals(AssistantColorTheme.SIRI_IRIDESCENT, initialConfig.colorTheme)
        assertEquals(AssistantLanguage.ENGLISH, initialConfig.voiceLanguage)

        // Update shape, theme and language
        prefs.setShape(AssistantShape.SIRI_ORB)
        prefs.setColorTheme(AssistantColorTheme.CYBER_CYAN)
        prefs.setWakeWordPreset("Hey Siri")
        prefs.setVoiceLanguage(AssistantLanguage.HINDI)

        val updated = prefs.configFlow.value
        assertEquals(AssistantShape.SIRI_ORB, updated.shape)
        assertEquals(AssistantColorTheme.CYBER_CYAN, updated.colorTheme)
        assertEquals("Hey Siri", updated.wakeWordPreset)
        assertEquals("Hey Siri", updated.effectiveWakeWord)
        assertEquals(AssistantLanguage.HINDI, updated.voiceLanguage)

        // Update to Hinglish
        prefs.setVoiceLanguage(AssistantLanguage.HINGLISH)
        val hinglishConfig = prefs.configFlow.value
        assertEquals(AssistantLanguage.HINGLISH, hinglishConfig.voiceLanguage)
    }

    @Test
    fun `test command parser for math, go home, open app and stop`() {
        val mathCmd = com.example.domain.JarvisCommandParser.parse("what is 25 times 4")
        assertTrue(mathCmd is com.example.domain.ParsedJarvisCommand.MathCalculation)
        assertEquals("100.", (mathCmd as com.example.domain.ParsedJarvisCommand.MathCalculation).result)

        val mathQuestionCmd = com.example.domain.JarvisCommandParser.parse("what is 25 times 4?")
        assertTrue(mathQuestionCmd is com.example.domain.ParsedJarvisCommand.MathCalculation)
        assertEquals("100.", (mathQuestionCmd as com.example.domain.ParsedJarvisCommand.MathCalculation).result)

        val diagCmd = com.example.domain.JarvisCommandParser.parse("open diagnostics")
        assertTrue(diagCmd is com.example.domain.ParsedJarvisCommand.OpenAssistantScreen)
        assertEquals(3, (diagCmd as com.example.domain.ParsedJarvisCommand.OpenAssistantScreen).tabIndex)

        val memCmd = com.example.domain.JarvisCommandParser.parse("open memory matrix")
        assertTrue(memCmd is com.example.domain.ParsedJarvisCommand.OpenAssistantScreen)
        assertEquals(4, (memCmd as com.example.domain.ParsedJarvisCommand.OpenAssistantScreen).tabIndex)

        val settingsCmd = com.example.domain.JarvisCommandParser.parse("open settings")
        assertTrue(settingsCmd is com.example.domain.ParsedJarvisCommand.OpenAssistantScreen)
        assertEquals(1, (settingsCmd as com.example.domain.ParsedJarvisCommand.OpenAssistantScreen).tabIndex)

        val homeCmd = com.example.domain.JarvisCommandParser.parse("go home")
        assertTrue(homeCmd is com.example.domain.ParsedJarvisCommand.GoHome)

        val stopCmd = com.example.domain.JarvisCommandParser.parse("stop speaking")
        assertTrue(stopCmd is com.example.domain.ParsedJarvisCommand.StopSpeaking)

        val youtubeCmd = com.example.domain.JarvisCommandParser.parse("open YouTube")
        assertTrue(youtubeCmd is com.example.domain.ParsedJarvisCommand.OpenApp)
        assertEquals("YouTube", (youtubeCmd as com.example.domain.ParsedJarvisCommand.OpenApp).appName)
    }

    @Test
    fun `test custom wake word configuration`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = AssistantPreferencesManager(context)

        prefs.setWakeWordPreset("Custom")
        prefs.setCustomWakeWord("Computer Alpha")

        val config = prefs.configFlow.value
        assertEquals("Custom", config.wakeWordPreset)
        assertEquals("Computer Alpha", config.customWakeWord)
        assertEquals("Computer Alpha", config.effectiveWakeWord)
    }

    @Test
    fun `test all shapes and themes and languages are available`() {
        assertTrue(AssistantShape.entries.isNotEmpty())
        assertTrue(AssistantColorTheme.entries.isNotEmpty())
        assertTrue(AssistantPersonality.entries.isNotEmpty())
        assertTrue(AssistantLanguage.entries.contains(AssistantLanguage.ENGLISH))
        assertTrue(AssistantLanguage.entries.contains(AssistantLanguage.HINDI))
        assertTrue(AssistantLanguage.entries.contains(AssistantLanguage.HINGLISH))
        assertTrue(WAKE_WORD_PRESETS.contains("Hey Jarvis"))
        assertTrue(WAKE_WORD_PRESETS.contains("Hey Siri"))
    }

    @Test
    fun `test lock screen hud device telemetry data model`() {
        val telemetry = com.example.device.DeviceTelemetry(
            batteryLevel = 84,
            isCharging = true,
            networkStatus = "Online (Wi-Fi)",
            batteryTemperatureCelsius = 31.2f,
            ramUsagePercent = 52
        )

        assertEquals(84, telemetry.batteryLevel)
        assertTrue(telemetry.isCharging)
        assertTrue(telemetry.networkStatus.contains("Wi-Fi"))
        assertEquals(31.2f, telemetry.batteryTemperatureCelsius, 0.01f)
        assertEquals(52, telemetry.ramUsagePercent)
    }

    @Test
    fun `test iron man combat and suit command parser`() {
        val hulkbusterCmd = com.example.domain.JarvisCommandParser.parse("deploy hulkbuster")
        assertTrue(hulkbusterCmd is com.example.domain.ParsedJarvisCommand.IronManProtocol)
        assertEquals("VERONICA", (hulkbusterCmd as com.example.domain.ParsedJarvisCommand.IronManProtocol).protocolType)

        val veronicaCmd = com.example.domain.JarvisCommandParser.parse("activate veronica")
        assertTrue(veronicaCmd is com.example.domain.ParsedJarvisCommand.IronManProtocol)
        assertEquals("VERONICA", (veronicaCmd as com.example.domain.ParsedJarvisCommand.IronManProtocol).protocolType)

        val housePartyCmd = com.example.domain.JarvisCommandParser.parse("house party protocol")
        assertTrue(housePartyCmd is com.example.domain.ParsedJarvisCommand.IronManProtocol)
        assertEquals("HOUSE_PARTY", (housePartyCmd as com.example.domain.ParsedJarvisCommand.IronManProtocol).protocolType)

        val sentryCmd = com.example.domain.JarvisCommandParser.parse("arm sentry mode")
        assertTrue(sentryCmd is com.example.domain.ParsedJarvisCommand.IronManProtocol)
        assertEquals("SENTRY_ARM", (sentryCmd as com.example.domain.ParsedJarvisCommand.IronManProtocol).protocolType)

        val disarmCmd = com.example.domain.JarvisCommandParser.parse("disarm sentry")
        assertTrue(disarmCmd is com.example.domain.ParsedJarvisCommand.IronManProtocol)
        assertEquals("SENTRY_DISARM", (disarmCmd as com.example.domain.ParsedJarvisCommand.IronManProtocol).protocolType)

        val repulsorCmd = com.example.domain.JarvisCommandParser.parse("fire repulsor")
        assertTrue(repulsorCmd is com.example.domain.ParsedJarvisCommand.FireRepulsor)

        val overclockCmd = com.example.domain.JarvisCommandParser.parse("arc reactor overclock")
        assertTrue(overclockCmd is com.example.domain.ParsedJarvisCommand.IronManProtocol)
        assertEquals("OVERCLOCK", (overclockCmd as com.example.domain.ParsedJarvisCommand.IronManProtocol).protocolType)

        val visorCmd = com.example.domain.JarvisCommandParser.parse("suit up")
        assertTrue(visorCmd is com.example.domain.ParsedJarvisCommand.OpenAssistantScreen)
        assertEquals(5, (visorCmd as com.example.domain.ParsedJarvisCommand.OpenAssistantScreen).tabIndex)

        val hudCmd = com.example.domain.JarvisCommandParser.parse("open tactical hud")
        assertTrue(hudCmd is com.example.domain.ParsedJarvisCommand.OpenAssistantScreen)
        assertEquals(5, (hudCmd as com.example.domain.ParsedJarvisCommand.OpenAssistantScreen).tabIndex)
    }

    @Test
    fun `test stark armor models and designations`() {
        assertEquals(5, com.example.domain.StarkArmorModel.entries.size)
        val mark85 = com.example.domain.StarkArmorModel.MARK_LXXXV
        assertEquals("MARK LXXXV", mark85.codeName)
        assertTrue(mark85.designation.contains("Nanotech"))

        val hulkbuster = com.example.domain.StarkArmorModel.MARK_XLIV_HULKBUSTER
        assertEquals("MARK XLIV", hulkbuster.codeName)
        assertTrue(hulkbuster.designation.contains("Veronica"))
    }
}
