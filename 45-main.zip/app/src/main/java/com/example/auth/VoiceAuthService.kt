package com.example.auth

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Base64
import android.util.Log
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.audio.TensorAudio
import org.tensorflow.lite.support.common.FileUtil
import org.tensorflow.lite.support.label.TensorLabel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

enum class AuthState {
    UNINITIALIZED, ENROLLING, VERIFYING, READY, ERROR
}

data class VoicePrint(
    val userId: String,
    val embedding: FloatArray,
    val quality: Float,
    val samplesCount: Int,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class VerificationResult(
    val isMatch: Boolean,
    val similarity: Float,
    val userId: String?,
    val confidence: VerificationConfidence
)

enum class VerificationConfidence {
    HIGH, MEDIUM, LOW, NONE
}

class VoiceAuthService @Inject constructor(
    private val context: Context
) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var interpreter: Interpreter? = null
    private val voicePrints = ConcurrentHashMap<String, VoicePrint>()
    private var audioRecord: AudioRecord? = null
    private var isRecording = false

    private val _state = MutableStateFlow(AuthState.UNINITIALIZED)
    val state: StateFlow<AuthState> = _state.asStateFlow()

    private val _enrollmentProgress = MutableStateFlow(0f)
    val enrollmentProgress: StateFlow<Float> = _enrollmentProgress.asStateFlow()

    private val _audioLevel = MutableStateFlow(0f)
    val audioLevel: StateFlow<Float> = _audioLevel.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val embeddingDim = 256 // ECAPA-TDNN embedding dimension
    private val sampleRate = 16000
    private val frameSize = 512
    private val minEnrollmentSamples = 3
    private val maxEnrollmentSamples = 10
    private val verificationThreshold = 0.75f

    init {
        initializeModel()
        loadVoicePrints()
    }

    private fun initializeModel() {
        scope.launch {
            try {
                val modelFile = FileUtil.loadMappedFile(context, "ecapa_tdnn.tflite")
                interpreter = Interpreter(modelFile)
                _state.value = AuthState.READY
                Log.d("VoiceAuthService", "Model loaded")
            } catch (e: Exception) {
                Log.e("VoiceAuthService", "Model init failed", e)
                _state.value = AuthState.ERROR
                _error.value = "Model not found. Add ecapa_tdnn.tflite to assets."
            }
        }
    }

    private fun loadVoicePrints() {
        scope.launch {
            try {
                val dir = File(context.filesDir, "voiceprints")
                if (dir.exists()) {
                    for (file in dir.listFiles() ?: emptyArray()) {
                        val userId = file.nameWithoutExtension
                        val embedding = readEmbedding(file)
                        if (embedding != null) {
                            voicePrints[userId] = VoicePrint(
                                userId = userId,
                                embedding = embedding,
                                quality = 1.0f,
                                samplesCount = 1
                            )
                        }
                    }
                }
                Log.d("VoiceAuthService", "Loaded ${voicePrints.size} voiceprints")
            } catch (e: Exception) {
                Log.e("VoiceAuthService", "Load voiceprints failed", e)
            }
        }
    }

    fun enrollUser(
        userId: String,
        onProgress: (Float) -> Unit,
        onComplete: (Boolean, String?) -> Unit
    ) {
        if (interpreter == null) {
            onComplete(false, "Model not loaded")
            return
        }

        _state.value = AuthState.ENROLLING
        _enrollmentProgress.value = 0f
        _error.value = null

        val embeddings = mutableListOf<FloatArray>()
        val samplesNeeded = maxEnrollmentSamples
        var samplesCollected = 0

        scope.launch {
            try {
                startRecording()
                
                while (samplesCollected < samplesNeeded && isRecording) {
                    val audioData = readAudioFrame()
                    if (audioData != null) {
                        val embedding = extractEmbedding(audioData)
                        if (embedding != null) {
                            embeddings.add(embedding)
                            samplesCollected++
                            _enrollmentProgress.value = samplesCollected.toFloat() / samplesNeeded
                            onProgress(_enrollmentProgress.value)
                            
                            // Small delay between samples
                            Thread.sleep(1000)
                        }
                    }
                }
                
                stopRecording()
                
                if (embeddings.size >= minEnrollmentSamples) {
                    // Average embeddings
                    val avgEmbedding = averageEmbeddings(embeddings)
                    val quality = calculateQuality(embeddings, avgEmbedding)
                    
                    val voicePrint = VoicePrint(
                        userId = userId,
                        embedding = avgEmbedding,
                        quality = quality,
                        samplesCount = embeddings.size
                    )
                    
                    voicePrints[userId] = voicePrint
                    saveVoicePrint(userId, avgEmbedding)
                    
                    _state.value = AuthState.READY
                    onComplete(true, null)
                } else {
                    _state.value = AuthState.ERROR
                    _error.value = "Not enough quality samples"
                    onComplete(false, "Not enough quality samples collected")
                }
                
            } catch (e: Exception) {
                Log.e("VoiceAuthService", "Enrollment failed", e)
                _state.value = AuthState.ERROR
                _error.value = e.message
                onComplete(false, e.message)
                stopRecording()
            }
        }
    }

    fun verifyUser(
        onResult: (VerificationResult) -> Unit
    ) {
        if (interpreter == null || voicePrints.isEmpty()) {
            onResult(VerificationResult(false, 0f, null, VerificationConfidence.NONE))
            return
        }

        _state.value = AuthState.VERIFYING

        scope.launch {
            try {
                startRecording()
                
                // Collect a few frames for verification
                val embeddings = mutableListOf<FloatArray>()
                for (i in 0 until 3) {
                    val audioData = readAudioFrame()
                    audioData?.let {
                        val emb = extractEmbedding(it)
                        emb?.let { embeddings.add(it) }
                    }
                    Thread.sleep(500)
                }
                
                stopRecording()
                
                if (embeddings.isEmpty()) {
                    onResult(VerificationResult(false, 0f, null, VerificationConfidence.NONE))
                    _state.value = AuthState.READY
                    return@launch
                }
                
                val avgEmbedding = averageEmbeddings(embeddings)
                
                // Compare against all enrolled users
                var bestMatch: VoicePrint? = null
                var bestSimilarity = 0f
                
                for (voicePrint in voicePrints.values) {
                    val similarity = cosineSimilarity(avgEmbedding, voicePrint.embedding)
                    if (similarity > bestSimilarity) {
                        bestSimilarity = similarity
                        bestMatch = voicePrint
                    }
                }
                
                val isMatch = bestSimilarity >= verificationThreshold
                val confidence = when {
                    bestSimilarity >= 0.9f -> VerificationConfidence.HIGH
                    bestSimilarity >= 0.8f -> VerificationConfidence.MEDIUM
                    bestSimilarity >= 0.75f -> VerificationConfidence.LOW
                    else -> VerificationConfidence.NONE
                }
                
                val result = VerificationResult(
                    isMatch = isMatch,
                    similarity = bestSimilarity,
                    userId = if (isMatch) bestMatch?.userId else null,
                    confidence = confidence
                )
                
                onResult(result)
                _state.value = AuthState.READY
                
            } catch (e: Exception) {
                Log.e("VoiceAuthService", "Verification failed", e)
                _error.value = e.message
                onResult(VerificationResult(false, 0f, null, VerificationConfidence.NONE))
                _state.value = AuthState.ERROR
                stopRecording()
            }
        }
    }

    fun quickVerify(userId: String, onResult: (VerificationResult) -> Unit) {
        val voicePrint = voicePrints[userId]
        if (voicePrint == null || interpreter == null) {
            onResult(VerificationResult(false, 0f, null, VerificationConfidence.NONE))
            return
        }

        _state.value = AuthState.VERIFYING

        scope.launch {
            try {
                startRecording()
                val audioData = readAudioFrame()
                stopRecording()
                
                audioData?.let {
                    val embedding = extractEmbedding(it)
                    embedding?.let { emb ->
                        val similarity = cosineSimilarity(emb, voicePrint.embedding)
                        val isMatch = similarity >= verificationThreshold
                        val confidence = when {
                            similarity >= 0.9f -> VerificationConfidence.HIGH
                            similarity >= 0.8f -> VerificationConfidence.MEDIUM
                            similarity >= 0.75f -> VerificationConfidence.LOW
                            else -> VerificationConfidence.NONE
                        }
                        onResult(VerificationResult(isMatch, similarity, if (isMatch) userId else null, confidence))
                    } ?: onResult(VerificationResult(false, 0f, null, VerificationConfidence.NONE))
                } ?: onResult(VerificationResult(false, 0f, null, VerificationConfidence.NONE))
                
                _state.value = AuthState.READY
            } catch (e: Exception) {
                Log.e("VoiceAuthService", "Quick verify failed", e)
                onResult(VerificationResult(false, 0f, null, VerificationConfidence.NONE))
                _state.value = AuthState.ERROR
                stopRecording()
            }
        }
    }

    fun deleteUser(userId: String): Boolean {
        voicePrints.remove(userId)
        val file = File(context.filesDir, "voiceprints/$userId.emb")
        return file.delete()
    }

    fun getEnrolledUsers(): List<String> = voicePrints.keys.toList()

    fun getVoicePrint(userId: String): VoicePrint? = voicePrints[userId]

    fun updateThreshold(threshold: Float) {
        // verificationThreshold = threshold.coerceIn(0.5f, 0.95f)
    }

    private fun startRecording() {
        val bufferSize = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        
        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize * 2
        )
        
        audioRecord?.startRecording()
        isRecording = true
    }

    private fun stopRecording() {
        isRecording = false
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
    }

    private fun readAudioFrame(): FloatArray? {
        return if (isRecording && audioRecord != null) {
            val buffer = ShortArray(frameSize)
            val read = audioRecord?.read(buffer, 0, frameSize)
            if (read == frameSize) {
                // Convert to float and normalize
                val floatBuffer = FloatArray(frameSize)
                for (i in 0 until frameSize) {
                    floatBuffer[i] = buffer[i] / 32768.0f
                }
                updateAudioLevel(floatBuffer)
                floatBuffer
            } else null
        } else null
    }

    private fun updateAudioLevel(audioData: FloatArray) {
        var sum = 0f
        for (sample in audioData) {
            sum += sample * sample
        }
        val rms = kotlin.math.sqrt(sum / audioData.size)
        _audioLevel.value = rms
    }

    private fun extractEmbedding(audioData: FloatArray): FloatArray? {
        return try {
            // Prepare input tensor
            val input = arrayOf(audioData)
            val output = Array(1) { FloatArray(embeddingDim) }
            
            interpreter?.run(input, output)
            output[0]
        } catch (e: Exception) {
            Log.e("VoiceAuthService", "Embedding extraction failed", e)
            null
        }
    }

    private fun averageEmbeddings(embeddings: List<FloatArray>): FloatArray {
        val avg = FloatArray(embeddingDim)
        for (emb in embeddings) {
            for (i in 0 until embeddingDim) {
                avg[i] += emb[i]
            }
        }
        for (i in 0 until embeddingDim) {
            avg[i] /= embeddings.size
        }
        // Normalize
        var norm = 0f
        for (v in avg) norm += v * v
        norm = kotlin.math.sqrt(norm)
        if (norm > 0) {
            for (i in 0 until embeddingDim) avg[i] /= norm
        }
        return avg
    }

    private fun calculateQuality(embeddings: List<FloatArray>, avg: FloatArray): Float {
        if (embeddings.size < 2) return 1f
        
        var totalSimilarity = 0f
        var count = 0
        
        for (i in 0 until embeddings.size) {
            for (j in i + 1 until embeddings.size) {
                totalSimilarity += cosineSimilarity(embeddings[i], embeddings[j])
                count++
            }
        }
        
        return if (count > 0) totalSimilarity / count else 1f
    }

    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return 0f
        var dot = 0f
        var normA = 0f
        var normB = 0f
        for (i in a.indices) {
            dot += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        return if (normA > 0 && normB > 0) {
            dot / (kotlin.math.sqrt(normA) * kotlin.math.sqrt(normB))
        } else 0f
    }

    private fun saveVoicePrint(userId: String, embedding: FloatArray) {
        val dir = File(context.filesDir, "voiceprints")
        dir.mkdirs()
        val file = File(dir, "$userId.emb")
        try {
            val fos = FileOutputStream(file)
            val buffer = ByteBuffer.allocate(embedding.size * 4)
            buffer.order(ByteOrder.LITTLE_ENDIAN)
            buffer.asFloatBuffer().put(embedding)
            fos.write(buffer.array())
            fos.close()
        } catch (e: Exception) {
            Log.e("VoiceAuthService", "Save voiceprint failed", e)
        }
    }

    private fun readEmbedding(file: File): FloatArray? {
        return try {
            val fis = FileInputStream(file)
            val buffer = ByteBuffer.allocate(fis.channel.size().toInt())
            buffer.order(ByteOrder.LITTLE_ENDIAN)
            fis.channel.read(buffer)
            fis.close()
            val array = FloatArray(buffer.capacity() / 4)
            buffer.asFloatBuffer().get(array)
            array
        } catch (e: Exception) {
            Log.e("VoiceAuthService", "Read voiceprint failed", e)
            null
        }
    }

    fun shutdown() {
        scope.coroutineContext.cancel()
        stopRecording()
        interpreter?.close()
    }

    companion object {
        private const val TAG = "VoiceAuthService"
    }
}