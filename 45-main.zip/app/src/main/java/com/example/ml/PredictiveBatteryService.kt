package com.example.ml

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue

data class BatteryDataPoint(
    val timestamp: Long,
    val level: Int,
    val isCharging: Boolean,
    val temperature: Float,
    val voltage: Float,
    val current: Float,
    val health: Int,
    val technology: String,
    val screenOn: Boolean,
    val cpuUsage: Float,
    val memoryUsage: Float,
    val networkType: Int
)

data class BatteryPrediction(
    val estimatedTimeToFull: Long, // milliseconds
    val estimatedTimeToEmpty: Long,
    val predictedLevelAtTime: Map<Long, Int>, // timestamp -> level
    val healthScore: Float, // 0-1
    val chargingPattern: ChargingPattern,
    val recommendations: List<String>
)

enum class ChargingPattern {
    REGULAR_OVERNIGHT, OPPORTUNISTIC, FAST_CHARGING, IRREGULAR, UNKNOWN
}

data class BatteryStats(
    val currentLevel: Int,
    val averageDrainPerHour: Float,
    val averageChargePerHour: Float,
    val cyclesCount: Int,
    val healthPercentage: Float,
    val temperatureAvg: Float,
    val screenOnTime: Long,
    val lastFullCharge: Long
)

class PredictiveBatteryService @Inject constructor(
    private val context: Context
) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val dataHistory = ConcurrentLinkedQueue<BatteryDataPoint>()
    private val maxHistorySize = 10000
    private var receiver: BroadcastReceiver? = null
    private var isCollecting = false

    private val _state = MutableStateFlow(ServiceState.STOPPED)
    val state: StateFlow<ServiceState> = _state.asStateFlow()

    private val _currentData = MutableStateFlow<BatteryDataPoint?>(null)
    val currentData: StateFlow<BatteryDataPoint?> = _currentData.asStateFlow()

    private val _prediction = MutableStateFlow<BatteryPrediction?>(null)
    val prediction: StateFlow<BatteryPrediction?> = _prediction.asStateFlow()

    private val _stats = MutableStateFlow<BatteryStats?>(null)
    val stats: StateFlow<BatteryStats?> = _stats.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    enum class ServiceState {
        STOPPED, STARTING, COLLECTING, PREDICTING, ERROR
    }

    init {
        startCollection()
    }

    private fun startCollection() {
        if (isCollecting) return
        isCollecting = true
        _state.value = ServiceState.STARTING

        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == Intent.ACTION_BATTERY_CHANGED) {
                    processBatteryIntent(intent!!)
                }
            }
        }

        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)

        // Also collect periodically for more data points
        scope.launch {
            while (isCollecting) {
                collectAdditionalMetrics()
                updatePrediction()
                Thread.sleep(60000) // Every minute
            }
        }

        _state.value = ServiceState.COLLECTING
        Log.d("PredictiveBatteryService", "Collection started")
    }

    private fun processBatteryIntent(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || 
                         status == BatteryManager.BATTERY_STATUS_FULL
        
        val tempRaw = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
        val temperature = tempRaw / 10.0f
        
        val voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) / 1000.0f
        
        val health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        val technology = intent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Unknown"
        
        // Note: EXTRA_CURRENT_NOW and EXTRA_CURRENT_AVERAGE are not always available
        val current = intent.getIntExtra("current_now", 0) / 1000.0f

        val dataPoint = BatteryDataPoint(
            timestamp = System.currentTimeMillis(),
            level = batteryPct,
            isCharging = isCharging,
            temperature = temperature,
            voltage = voltage,
            current = current,
            health = health,
            technology = technology,
            screenOn = isScreenOn(),
            cpuUsage = getCpuUsage(),
            memoryUsage = getMemoryUsage(),
            networkType = getNetworkType()
        )

        addDataPoint(dataPoint)
        _currentData.value = dataPoint
    }

    private fun collectAdditionalMetrics() {
        // This is called periodically to collect non-battery metrics
        val dataPoint = _currentData.value
        if (dataPoint != null) {
            val updated = dataPoint.copy(
                screenOn = isScreenOn(),
                cpuUsage = getCpuUsage(),
                memoryUsage = getMemoryUsage(),
                networkType = getNetworkType()
            )
            _currentData.value = updated
        }
    }

    private fun addDataPoint(point: BatteryDataPoint) {
        dataHistory.add(point)
        while (dataHistory.size > maxHistorySize) {
            dataHistory.poll()
        }
    }

    private fun updatePrediction() {
        _state.value = ServiceState.PREDICTING
        
        scope.launch(Dispatchers.Default) {
            try {
                val prediction = generatePrediction()
                _prediction.value = prediction
                _stats.value = generateStats()
                _state.value = ServiceState.COLLECTING
            } catch (e: Exception) {
                Log.e("PredictiveBatteryService", "Prediction failed", e)
                _error.value = e.message
                _state.value = ServiceState.ERROR
            }
        }
    }

    private fun generatePrediction(): BatteryPrediction {
        val data = dataHistory.toList()
        if (data.size < 10) {
            return BatteryPrediction(
                estimatedTimeToFull = -1,
                estimatedTimeToEmpty = -1,
                predictedLevelAtTime = emptyMap(),
                healthScore = 1f,
                chargingPattern = ChargingPattern.UNKNOWN,
                recommendations = listOf("Collecting data...")
            )
        }

        // Analyze charging pattern
        val chargingPattern = analyzeChargingPattern(data)
        
        // Calculate drain/charge rates
        val (avgDrainPerHour, avgChargePerHour) = calculateRates(data)
        
        // Estimate time to full/empty
        val currentLevel = data.last().level
        val currentTime = System.currentTimeMillis()
        
        val timeToFull = if (data.last().isCharging && avgChargePerHour > 0) {
            val remaining = 100 - currentLevel
            (remaining / avgChargePerHour * 3600000).toLong()
        } else -1L
        
        val timeToEmpty = if (!data.last().isCharging && avgDrainPerHour > 0) {
            (currentLevel / avgDrainPerHour * 3600000).toLong()
        } else -1L

        // Predict future levels
        val predictedLevels = mutableMapOf<Long, Int>()
        val now = System.currentTimeMillis()
        val isCharging = data.last().isCharging
        val rate = if (isCharging) avgChargePerHour else -avgDrainPerHour
        
        for (i in 1..24) {
            val futureTime = now + i * 3600000
            val predictedLevel = (currentLevel + rate * i).coerceIn(0, 100)
            predictedLevels[futureTime] = predictedLevel.toInt()
        }

        // Health score
        val healthScore = calculateHealthScore(data)

        // Recommendations
        val recommendations = generateRecommendations(data, healthScore, chargingPattern)

        return BatteryPrediction(
            estimatedTimeToFull = timeToFull,
            estimatedTimeToEmpty = timeToEmpty,
            predictedLevelAtTime = predictedLevels,
            healthScore = healthScore,
            chargingPattern = chargingPattern,
            recommendations = recommendations
        )
    }

    private fun analyzeChargingPattern(data: List<BatteryDataPoint>): ChargingPattern {
        val chargingSessions = data.filter { it.isCharging }
            .groupBy { getHourOfDay(it.timestamp) }
        
        val nightCharges = chargingSessions.filterKeys { it in 22..23 || it in 0..6 }.values.flatten().size
        val dayCharges = chargingSessions.filterKeys { it in 6..22 }.values.flatten().size
        
        val fastCharges = data.filter { it.isCharging && it.current > 2000 }.size // > 2A
        
        return when {
            nightCharges > dayCharges * 2 -> ChargingPattern.REGULAR_OVERNIGHT
            fastCharges > chargingSessions.size * 0.5 -> ChargingPattern.FAST_CHARGING
            dayCharges > nightCharges -> ChargingPattern.OPPORTUNISTIC
            else -> ChargingPattern.IRREGULAR
        }
    }

    private fun calculateRates(data: List<BatteryDataPoint>): Pair<Float, Float> {
        var totalDrain = 0f
        var drainCount = 0
        var totalCharge = 0f
        var chargeCount = 0

        for (i in 1 until data.size) {
            val prev = data[i - 1]
            val curr = data[i]
            val timeDiff = (curr.timestamp - prev.timestamp) / 1000f / 3600f // hours
            
            if (timeDiff > 0 && timeDiff < 2) { // Only consider close samples
                val levelDiff = curr.level - prev.level
                val rate = levelDiff / timeDiff
                
                if (curr.isCharging && rate > 0) {
                    totalCharge += rate
                    chargeCount++
                } else if (!curr.isCharging && rate < 0) {
                    totalDrain += abs(rate)
                    drainCount++
                }
            }
        }

        val avgDrain = if (drainCount > 0) totalDrain / drainCount else 10f
        val avgCharge = if (chargeCount > 0) totalCharge / chargeCount else 20f

        return Pair(avgDrain, avgCharge)
    }

    private fun calculateHealthScore(data: List<BatteryDataPoint>): Float {
        var score = 1f
        
        // Temperature factor
        val avgTemp = data.map { it.temperature }.average()
        if (avgTemp > 35f) score *= 0.9f
        if (avgTemp > 40f) score *= 0.8f
        
        // Charging pattern factor
        val fastChargeRatio = data.count { it.isCharging && it.current > 2000 }.toFloat() / 
                              data.count { it.isCharging }.coerceAtLeast(1)
        if (fastChargeRatio > 0.5) score *= 0.95f
        
        // Deep discharge factor
        val deepDischarges = data.count { it.level < 20 && !it.isCharging }
        if (deepDischarges > data.size * 0.1) score *= 0.9f
        
        // Full charge cycles (approximate)
        val cycles = estimateCycles(data)
        if (cycles > 500) score *= 0.85f
        else if (cycles > 300) score *= 0.9f
        
        return score.coerceIn(0f, 1f)
    }

    private fun estimateCycles(data: List<BatteryDataPoint>): Int {
        var cycles = 0
        var wasCharging = false
        var chargeStartLevel = 0
        
        for (point in data) {
            if (point.isCharging && !wasCharging) {
                wasCharging = true
                chargeStartLevel = point.level
            } else if (!point.isCharging && wasCharging) {
                wasCharging = false
                val chargeAmount = point.level - chargeStartLevel
                if (chargeAmount > 80) cycles++ // Full cycle
                else if (chargeAmount > 40) cycles += 0.5 // Half cycle
            }
        }
        
        return cycles.toInt()
    }

    private fun generateRecommendations(
        data: List<BatteryDataPoint>,
        healthScore: Float,
        pattern: ChargingPattern
    ): List<String> {
        val recommendations = mutableListOf<String>()
        
        if (healthScore < 0.7f) {
            recommendations.add("Battery health degraded. Consider replacement.")
        }
        
        val avgTemp = data.map { it.temperature }.average()
        if (avgTemp > 35f) {
            recommendations.add("High average temperature (${avgTemp.toInt()}°C). Avoid intensive use while charging.")
        }
        
        when (pattern) {
            ChargingPattern.FAST_CHARGING -> {
                recommendations.add("Frequent fast charging detected. Use standard charging overnight for better longevity.")
            }
            ChargingPattern.IRREGULAR -> {
                recommendations.add("Irregular charging pattern. Try to charge overnight consistently.")
            }
            ChargingPattern.OPPORTUNISTIC -> {
                recommendations.add("Opportunistic charging is good for battery health.")
            }
        }
        
        val deepDischarges = data.count { it.level < 20 && !it.isCharging }
        if (deepDischarges > data.size * 0.15) {
            recommendations.add("Frequent deep discharges (<20%). Charge before reaching 20%.")
        }
        
        val currentLevel = data.last().level
        if (!data.last().isCharging && currentLevel < 30) {
            recommendations.add("Battery at ${currentLevel}%. Consider charging soon.")
        }
        
        return if (recommendations.isEmpty()) listOf("Battery health is good. Keep current habits.") else recommendations
    }

    private fun generateStats(): BatteryStats {
        val data = dataHistory.toList()
        if (data.isEmpty()) {
            return BatteryStats(0, 0f, 0f, 0, 1f, 0f, 0, 0)
        }

        val (avgDrain, avgCharge) = calculateRates(data)
        val cycles = estimateCycles(data)
        val healthScore = calculateHealthScore(data)
        val avgTemp = data.map { it.temperature }.average()
        val screenOnTime = data.count { it.screenOn } * 60L // minutes
        
        // Find last full charge
        var lastFullCharge = 0L
        for (i in data.indices.reversed()) {
            if (data[i].level >= 95 && data[i].isCharging) {
                lastFullCharge = data[i].timestamp
                break
            }
        }

        return BatteryStats(
            currentLevel = data.last().level,
            averageDrainPerHour = avgDrain,
            averageChargePerHour = avgCharge,
            cyclesCount = cycles,
            healthPercentage = healthScore * 100,
            temperatureAvg = avgTemp,
            screenOnTime = screenOnTime,
            lastFullCharge = lastFullCharge
        )
    }

    private fun getHourOfDay(timestamp: Long): Int {
        return java.util.Calendar.getInstance().apply { timeInMillis = timestamp }
            .get(java.util.Calendar.HOUR_OF_DAY)
    }

    private fun isScreenOn(): Boolean {
        // This would need a proper implementation with PowerManager
        return true // Placeholder
    }

    private fun getCpuUsage(): Float {
        // Simplified - would need proper implementation
        return (Math.random() * 30 + 10).toFloat()
    }

    private fun getMemoryUsage(): Float {
        val runtime = Runtime.getRuntime()
        val used = runtime.totalMemory() - runtime.freeMemory()
        return (used.toFloat() / runtime.totalMemory() * 100)
    }

    private fun getNetworkType(): Int {
        // 0=none, 1=wifi, 2=cellular, 3=ethernet
        return 1 // Placeholder
    }

    fun getHistory(since: Long): List<BatteryDataPoint> {
        return dataHistory.filter { it.timestamp >= since }.toList()
    }

    fun getHistoryLastHours(hours: Int): List<BatteryDataPoint> {
        val since = System.currentTimeMillis() - hours * 3600000L
        return getHistory(since)
    }

    fun exportData(): String {
        val data = dataHistory.toList()
        return kotlinx.serialization.json.Json.encodeToString(data)
    }

    fun stopCollection() {
        isCollecting = false
        receiver?.let { context.unregisterReceiver(it) }
        receiver = null
        _state.value = ServiceState.STOPPED
    }

    fun shutdown() {
        stopCollection()
        scope.coroutineContext.cancel()
    }

    companion object {
        private const val TAG = "PredictiveBatteryService"
    }
}