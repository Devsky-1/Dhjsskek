package com.example.ui.developer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ColorMatrixColorFilter
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AdvancedUIComponents.GlassCard
import com.example.ui.components.AdvancedUIComponents.GlassElevation
import com.example.ui.components.AdvancedUIComponents.GlassTint
import com.example.ui.components.AdvancedUIComponents.NeonButton
import com.example.ui.components.AdvancedUIComponents.NeonSize
import com.example.ui.components.AdvancedUIComponents.NeonStyle
import com.example.ui.components.AdvancedUIComponents.StatusPill
import com.example.ui.theme.JarvisAmber
import com.example.ui.theme.JarvisGreen
import com.example.ui.theme.JarvisObsidian
import com.example.ui.theme.JarvisRed
import com.example.ui.theme.JarvisTextMuted
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DeveloperConsoleScreen(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    
    val commandHistory = remember { mutableStateListOf<ConsoleEntry>() }
    val commandInput = remember { mutableStateOf("") }
    val historyIndex = remember { mutableStateOf(-1) }
    val isExecuting = remember { mutableStateOf(false) }
    val showSystemMonitor = remember { mutableStateOf(true) }
    val selectedTab = remember { mutableStateOf(0) } // 0: Console, 1: REPL, 2: System, 3: Network
    
    val scope = rememberCoroutineScope()
    
    // Add welcome message
    LaunchedEffect(Unit) {
        addEntry(ConsoleEntry(
            type = EntryType.SYSTEM,
            text = "JARVIS Developer Console v1.0\nType 'help' for available commands\nConnected to local runtime",
            timestamp = System.currentTimeMillis()
        ))
    }
    
    fun addEntry(entry: ConsoleEntry) {
        commandHistory.add(entry)
        if (commandHistory.size > 1000) {
            commandHistory.removeAt(0)
        }
    }
    
    fun executeCommand(cmd: String) {
        if (cmd.trim().isBlank()) return
        
        addEntry(ConsoleEntry(
            type = EntryType.INPUT,
            text = "> $cmd",
            timestamp = System.currentTimeMillis()
        ))
        
        commandInput.value = ""
        historyIndex.value = -1
        isExecuting.value = true
        
        scope.launch(Dispatchers.IO) {
            try {
                val result = when {
                    cmd == "help" -> executeHelp()
                    cmd == "clear" -> { commandHistory.clear(); addEntry(ConsoleEntry(EntryType.SYSTEM, "Console cleared", System.currentTimeMillis())); "" }
                    cmd == "sysinfo" -> executeSysInfo()
                    cmd == "meminfo" -> executeMemInfo()
                    cmd == "cpuinfo" -> executeCpuInfo()
                    cmd == "netinfo" -> executeNetInfo()
                    cmd == "battery" -> executeBattery()
                    cmd.startsWith("run ") -> executeCode(cmd.substring(4))
                    cmd.startsWith("eval ") -> evaluateExpression(cmd.substring(5))
                    cmd == "devices" -> executeDevices()
                    cmd == "services" -> executeServices()
                    cmd == "logs" -> executeLogs()
                    cmd == "version" -> "JARVIS v1.0.0 (Build 2024.10.21)"
                    cmd == "uptime" -> executeUptime()
                    cmd == "gc" -> { System.gc(); "Garbage collection triggered" }
                    cmd == "threads" -> executeThreads()
                    cmd == "env" -> executeEnv()
                    cmd == "alias" -> executeAlias()
                    else -> executeShellCommand(cmd)
                }
                
                addEntry(ConsoleEntry(
                    type = if (result.contains("Error", ignoreCase = true) || result.contains("Exception")) EntryType.ERROR else EntryType.OUTPUT,
                    text = result,
                    timestamp = System.currentTimeMillis()
                ))
            } catch (e: Exception) {
                addEntry(ConsoleEntry(
                    type = EntryType.ERROR,
                    text = "Execution error: ${e.message}",
                    timestamp = System.currentTimeMillis()
                ))
            } finally {
                isExecuting.value = false
            }
        }
    }
    
    fun executeHelp(): String {
        return """Available Commands:
  help          - Show this help
  clear         - Clear console
  sysinfo       - System information
  meminfo       - Memory details
  cpuinfo       - CPU information
  netinfo       - Network status
  battery       - Battery status
  devices       - Connected Matter devices
  services      - Running services
  logs          - Recent system logs
  version       - JARVIS version
  uptime        - System uptime
  gc            - Trigger garbage collection
  threads       - Thread dump
  env           - Environment variables
  alias         - Show command aliases
  run <code>    - Execute Kotlin/Python code
  eval <expr>   - Evaluate expression
  <shell cmd>   - Execute shell command
  
Keyboard Shortcuts:
  ↑/↓           - History navigation
  Ctrl+L        - Clear console
  Ctrl+C        - Interrupt
  Tab           - Auto-complete (future)"""
    }
    
    fun executeSysInfo(): String {
        return """System Information:
  Model: ${Build.MODEL}
  Manufacturer: ${Build.MANUFACTURER}
  Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})
  Build: ${Build.FINGERPRINT}
  Architecture: ${System.getProperty("os.arch")}
  Java VM: ${System.getProperty("java.vm.version")}
  Available CPUs: ${Runtime.getRuntime().availableProcessors()}
  Total Memory: ${Runtime.getRuntime().totalMemory() / 1024 / 1024} MB
  Max Memory: ${Runtime.getRuntime().maxMemory() / 1024 / 1024} MB"""
    }
    
    fun executeMemInfo(): String {
        val runtime = Runtime.getRuntime()
        val used = runtime.totalMemory() - runtime.freeMemory()
        return """Memory Information:
  Total: ${runtime.totalMemory() / 1024 / 1024} MB
  Used: ${used / 1024 / 1024} MB
  Free: ${runtime.freeMemory() / 1024 / 1024} MB
  Max: ${runtime.maxMemory() / 1024 / 1024} MB
  Usage: ${(used * 100 / runtime.totalMemory())}%"""
    }
    
    fun executeCpuInfo(): String {
        return """CPU Information:
  Cores: ${Runtime.getRuntime().availableProcessors()}
  Architecture: ${Build.SUPPORTED_ABIS.joinToString(", ")}
  ABI: ${Build.CPU_ABI}
  ABI2: ${Build.CPU_ABI2}"""
    }
    
    fun executeNetInfo(): String {
        return """Network Information:
  (Requires connectivity manager integration)
  Use 'sysinfo' for basic system info"""
    }
    
    fun executeBattery(): String {
        val intent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = intent?.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == android.os.BatteryManager.BATTERY_STATUS_CHARGING || status == android.os.BatteryManager.BATTERY_STATUS_FULL
        val temp = (intent?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0f
        return """Battery Status:
  Level: $pct%
  Charging: $charging
  Temperature: ${String.format("%.1f", temp)}°C"""
    }
    
    fun executeDevices(): String {
        return """Connected Devices:
  (Matter device integration pending)
  Use MatterService for device management"""
    }
    
    fun executeServices(): String {
        return """Running Services:
  - JarvisBackgroundService
  - JarvisVoiceInteractionService
  - JarvisFloatingOverlayService
  (Use 'dumpsys activity services' for full list)"""
    }
    
    fun executeLogs(): String {
        return """Recent Logs:
  (Logcat integration requires READ_LOGS permission)
  Use 'adb logcat' for full logs"""
    }
    
    fun executeUptime(): String {
        val uptimeMillis = android.os.SystemClock.uptimeMillis()
        val hours = uptimeMillis / 3600000
        val minutes = (uptimeMillis % 3600000) / 60000
        return "Uptime: ${hours}h ${minutes}m"
    }
    
    fun executeThreads(): String {
        val threads = Thread.getAllStackTraces().keys
        return """Active Threads: ${threads.size}
${threads.take(10).joinToString("\n") { it.name }}
... and ${threads.size - 10} more"""
    }
    
    fun executeEnv(): String {
        return System.getenv().toSortedMap().map { "${it.key}=${it.value}" }.joinToString("\n")
    }
    
    fun executeAlias(): String {
        return """Aliases:
  ll = run kotlin code
  py = run python code
  sh = shell command"""
    }
    
    fun executeShellCommand(cmd: String): String {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            val output = StringBuilder()
            val error = StringBuilder()
            process.inputStream.use { it.reader().use { r -> output.append(r.readText()) } }
            process.errorStream.use { it.reader().use { r -> error.append(r.readText()) } }
            process.waitFor()
            if (error.isNotEmpty()) "Error: ${error.trim()}" else output.toString().trim().ifBlank { "Command executed (no output)" }
        } catch (e: Exception) {
            "Shell error: ${e.message}"
        }
    }
    
    fun executeCode(code: String): String {
        return "Code execution requires CodeExecutionService integration"
    }
    
    fun evaluateExpression(expr: String): String {
        return "Expression evaluation: $expr = [not implemented]"
    }

    Box(modifier = Modifier.fillMaxSize().background(JarvisObsidian)) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top bar
            GlassCard(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                elevation = GlassElevation.HIGH,
                tint = GlassTint.PRIMARY
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp).height(56.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Outlined.ArrowBack, "Back", tint = JarvisTextPrimary, modifier = Modifier.size(24.dp))
                        }
                        StatusPill(text = "DEV CONSOLE", icon = Icons.Default.Terminal, color = Color(0x00D4FF))
                        
                        // Tab selector
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("Console", "REPL", "System", "Network").forEachIndexed { index, title ->
                                val isSelected = selectedTab.value == index
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 4.dp)
                                        .clickable { selectedTab.value = index }
                                        .background(
                                            if (isSelected) Color(0x00D4FF).copy(alpha = 0.2f) else Color.Transparent,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = title,
                                        color = if (isSelected) Color(0x00D4FF) else JarvisTextSecondary,
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                    
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (selectedTab.value == 0) {
                            NeonButton(
                                text = isExecuting.value ? "Running..." : "Execute",
                                icon = if (isExecuting.value) Icons.Default.Stop else Icons.Default.PlayArrow,
                                onClick = { if (!isExecuting.value) executeCommand(commandInput.value) },
                                enabled = commandInput.value.isNotBlank() && !isExecuting.value,
                                style = NeonStyle.SUCCESS,
                                size = NeonSize.SMALL
                            )
                            NeonButton(
                                text = "Clear",
                                icon = Icons.Default.Delete,
                                onClick = { commandHistory.clear() },
                                style = NeonStyle.GHOST,
                                size = NeonSize.SMALL
                            )
                        }
                        Switch(
                            checked = showSystemMonitor.value,
                            onCheckedChange = { showSystemMonitor.value = it },
                            colors = androidx.compose.material3.SwitchDefaults.colors(
                                checkedThumbColor = Color(0x00D4FF),
                                checkedTrackColor = Color(0x00D4FF).copy(alpha = 0.3f)
                            )
                        )
                    }
                }
            }
            
            // Main content
            Box(modifier = Modifier.fillMaxSize().padding(16.dp).weight(1f)) {
                when (selectedTab.value) {
                    0 -> ConsoleView(
                        entries = commandHistory,
                        commandInput = commandInput,
                        historyIndex = historyIndex,
                        isExecuting = isExecuting,
                        onExecute = ::executeCommand,
                        onKeyEvent = { event ->
                            when (event.key) {
                                Key.Enter -> {
                                    if (!event.isShiftPressed) {
                                        executeCommand(commandInput.value)
                                        true
                                    } else false
                                }
                                Key.ArrowUp -> {
                                    if (historyIndex.value < commandHistory.size - 1) {
                                        historyIndex.value++
                                        commandInput.value = commandHistory[commandHistory.size - 1 - historyIndex.value].text.removePrefix("> ")
                                        true
                                    } else false
                                }
                                Key.ArrowDown -> {
                                    if (historyIndex.value > 0) {
                                        historyIndex.value--
                                        commandInput.value = commandHistory[commandHistory.size - 1 - historyIndex.value].text.removePrefix("> ")
                                        true
                                    } else if (historyIndex.value == 0) {
                                        historyIndex.value = -1
                                        commandInput.value = ""
                                        true
                                    } else false
                                }
                                else -> false
                            }
                        }
                    )
                    1 -> ReplView(onDismiss = onDismiss)
                    2 -> SystemMonitorView()
                    3 -> NetworkMonitorView()
                }
            }
            
            // Input bar (Console tab only)
            AnimatedVisibility(
                visible = selectedTab.value == 0,
                enter = androidx.compose.animation.slideInVertically(animationSpec = tween(200)),
                exit = androidx.compose.animation.slideOutVertically(animationSpec = tween(150))
            ) {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, bottom = 16.dp)
                        .height(70.dp),
                    elevation = GlassElevation.HIGH,
                    tint = GlassTint.NEUTRAL
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "jarvis@local:~$ ",
                            color = Color(0x00D4FF),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        OutlinedTextField(
                            value = commandInput.value,
                            onValueChange = { commandInput.value = it },
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 12.dp)
                                .fillMaxHeight(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = androidx.compose.foundation.text.KeyboardActions(onDone = { executeCommand(commandInput.value) }),
                            colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0x00D4FF),
                                unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                focusedTextColor = JarvisTextPrimary,
                                unfocusedTextColor = JarvisTextPrimary,
                                cursorColor = Color(0x00D4FF),
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            ),
                            placeholder = { Text("Enter command...", color = JarvisTextMuted, fontFamily = FontFamily.Monospace) },
                            textStyle = androidx.compose.ui.text.TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 14.sp,
                                color = JarvisTextPrimary
                            )
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(onClick = { clipboardManager.setText(AnnotatedString(commandInput.value)) }) {
                                Icon(Icons.Default.ContentCopy, "Copy", tint = JarvisTextSecondary, modifier = Modifier.size(20.dp))
                            }
                            IconButton(onClick = { commandHistory.clear() }) {
                                Icon(Icons.Default.Delete, "Clear", tint = JarvisRed, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ConsoleView(
    entries: androidx.compose.runtime.SnapshotStateList<ConsoleEntry>,
    commandInput: androidx.compose.runtime.MutableState<String>,
    historyIndex: androidx.compose.runtime.MutableState<Int>,
    isExecuting: androidx.compose.runtime.MutableState<Boolean>,
    onExecute: (String) -> Unit,
    onKeyEvent: (androidx.compose.ui.input.key.KeyEvent) -> Boolean
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .onKeyEvent(onKeyEvent)
            .padding(bottom = 16.dp)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            reverseLayout = true,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(entries.reversed()) { entry ->
                ConsoleEntryView(entry = entry)
            }
        }
    }
}

@Composable
fun ConsoleEntryView(entry: ConsoleEntry) {
    val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
    val time = timeFormat.format(Date(entry.timestamp))
    
    val (textColor, prefix) = when (entry.type) {
        ConsoleEntry.EntryType.INPUT -> Pair(JarvisTextPrimary, "❯ ")
        ConsoleEntry.EntryType.OUTPUT -> Pair(JarvisGreen, "")
        ConsoleEntry.EntryType.ERROR -> Pair(JarvisRed, "✗ ")
        ConsoleEntry.EntryType.SYSTEM -> Pair(JarvisAmber, "● ")
    }
    
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        elevation = GlassElevation.LOW,
        tint = when (entry.type) {
            ConsoleEntry.EntryType.ERROR -> GlassTint.ERROR
            ConsoleEntry.EntryType.SYSTEM -> GlassTint.WARNING
            else -> GlassTint.NEUTRAL
        }
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "$prefix${entry.text}",
                    color = textColor,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    style = androidx.compose.ui.text.TextStyle(
                        lineHeight = 20.sp
                    )
                )
                Text(
                    text = time,
                    color = JarvisTextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun ReplView(onDismiss: () -> Unit) {
    // Kotlin REPL placeholder
    GlassCard(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        elevation = GlassElevation.HIGH,
        tint = GlassTint.NEUTRAL
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.BugReport, "REPL", tint = Color(0x00D4FF), modifier = Modifier.size(64.dp))
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "KOTLIN REPL",
                color = JarvisTextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Interactive Kotlin REPL coming soon\nRequires kotlinc-jvm or scripting engine",
                color = JarvisTextSecondary,
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(24.dp))
            NeonButton(
                text = "Back to Console",
                onClick = onDismiss,
                style = NeonStyle.PRIMARY
            )
        }
    }
}

@Composable
fun SystemMonitorView() {
    GlassCard(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        elevation = GlassElevation.HIGH,
        tint = GlassTint.NEUTRAL
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.Memory, "System", tint = Color(0x00D4FF), modifier = Modifier.size(64.dp))
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "SYSTEM MONITOR",
                color = JarvisTextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Real-time system metrics dashboard\nCPU, Memory, Battery, Thermal\nComing soon with full integration",
                color = JarvisTextSecondary,
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun NetworkMonitorView() {
    GlassCard(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        elevation = GlassElevation.HIGH,
        tint = GlassTint.NEUTRAL
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.Wifi, "Network", tint = Color(0x00D4FF), modifier = Modifier.size(64.dp))
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "NETWORK MONITOR",
                color = JarvisTextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Network traffic analysis\nBandwidth, Latency, Connections\nComing soon",
                color = JarvisTextSecondary,
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

data class ConsoleEntry(
    val type: EntryType,
    val text: String,
    val timestamp: Long
) {
    enum class EntryType {
        INPUT, OUTPUT, ERROR, SYSTEM
    }
}