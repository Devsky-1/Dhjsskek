package com.example.ui.components

import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ColorMatrixColorFilter
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.drawRect
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    elevation: GlassElevation = GlassElevation.MEDIUM,
    tint: GlassTint = GlassTint.NEUTRAL,
    borderWidth: Float = 1f,
    content: @Composable () -> Unit
) {
    val density = LocalDensity.current
    val colors = GlassColors(tint)
    
    Surface(
        modifier = modifier
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        colors.topStart,
                        colors.bottomEnd
                    )
                )
            )
            .border(
                width = borderWidth.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        colors.borderStart,
                        colors.borderEnd
                    )
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .shadow(elevation.shadow, shape = RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        center = androidx.compose.ui.geometry.Offset(0.5f, 0f),
                        radius = 1.5f,
                        colors = listOf(
                            Color.White.copy(alpha = 0.05f),
                            Color.Transparent
                        )
                    )
                )
                .clip(RoundedCornerShape(20.dp))
        ) {
            content()
        }
    }
}

enum class GlassElevation {
    LOW(2.dp, 4.dp, 0.05f),
    MEDIUM(4.dp, 12.dp, 0.08f),
    HIGH(8.dp, 24.dp, 0.12f),
    ULTRA(16.dp, 48.dp, 0.16f);

    val offset: androidx.compose.ui.unit.Dp
    val blur: androidx.compose.ui.unit.Dp
    val alpha: Float

    val shadow: Shadow
        get() = Shadow(
            offset = androidx.compose.ui.geometry.Offset(0f, offset.toPx()),
            blurRadius = blur.toPx(),
            color = Color.Black.copy(alpha = alpha)
        )
}

enum class GlassTint {
    NEUTRAL,
    PRIMARY,
    ACCENT,
    SUCCESS,
    WARNING,
    ERROR,
    VIBRANT
}

data class GlassColors(
    val topStart: Color,
    val bottomEnd: Color,
    val borderStart: Color,
    val borderEnd: Color
) {
    constructor(tint: GlassTint) : this(
        topStart = when (tint) {
            GlassTint.NEUTRAL -> Color.White.copy(alpha = 0.1f)
            GlassTint.PRIMARY -> Color(0x00D4FF).copy(alpha = 0.15f)
            GlassTint.ACCENT -> Color(0x00FF88).copy(alpha = 0.15f)
            GlassTint.SUCCESS -> Color(0x10B981).copy(alpha = 0.15f)
            GlassTint.WARNING -> Color(0xF59E0B).copy(alpha = 0.15f)
            GlassTint.ERROR -> Color(0xEF4444).copy(alpha = 0.15f)
            GlassTint.VIBRANT -> Color(0xFF6B35).copy(alpha = 0.15f)
        },
        bottomEnd = when (tint) {
            GlassTint.NEUTRAL -> Color.White.copy(alpha = 0.02f)
            GlassTint.PRIMARY -> Color(0x00D4FF).copy(alpha = 0.05f)
            GlassTint.ACCENT -> Color(0x00FF88).copy(alpha = 0.05f)
            GlassTint.SUCCESS -> Color(0x10B981).copy(alpha = 0.05f)
            GlassTint.WARNING -> Color(0xF59E0B).copy(alpha = 0.05f)
            GlassTint.ERROR -> Color(0xEF4444).copy(alpha = 0.05f)
            GlassTint.VIBRANT -> Color(0xFF6B35).copy(alpha = 0.05f)
        },
        borderStart = when (tint) {
            GlassTint.NEUTRAL -> Color.White.copy(alpha = 0.3f)
            GlassTint.PRIMARY -> Color(0x00D4FF).copy(alpha = 0.5f)
            GlassTint.ACCENT -> Color(0x00FF88).copy(alpha = 0.5f)
            GlassTint.SUCCESS -> Color(0x10B981).copy(alpha = 0.5f)
            GlassTint.WARNING -> Color(0xF59E0B).copy(alpha = 0.5f)
            GlassTint.ERROR -> Color(0xEF4444).copy(alpha = 0.5f)
            GlassTint.VIBRANT -> Color(0xFF6B35).copy(alpha = 0.5f)
        },
        borderEnd = when (tint) {
            GlassTint.NEUTRAL -> Color.White.copy(alpha = 0.05f)
            GlassTint.PRIMARY -> Color(0x00D4FF).copy(alpha = 0.1f)
            GlassTint.ACCENT -> Color(0x00FF88).copy(alpha = 0.1f)
            GlassTint.SUCCESS -> Color(0x10B981).copy(alpha = 0.1f)
            GlassTint.WARNING -> Color(0xF59E0B).copy(alpha = 0.1f)
            GlassTint.ERROR -> Color(0xEF4444).copy(alpha = 0.1f)
            GlassTint.VIBRANT -> Color(0xFF6B35).copy(alpha = 0.1f)
        }
    )
}

@Composable
fun NeonButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    style: NeonStyle = NeonStyle.PRIMARY,
    size: NeonSize = NeonSize.MEDIUM
) {
    val colors = NeonColors(style)
    val (pressed, notPressed) = androidx.compose.foundation.rememberPressInteraction()
    
    val scale = if (pressed) 0.96f else 1f
    val glowIntensity = if (pressed) 1.5f else 1f
    
    Box(
        modifier = modifier
            .size(
                width = when (size) {
                    NeonSize.SMALL -> 120.dp
                    NeonSize.MEDIUM -> 160.dp
                    NeonSize.LARGE -> 200.dp
                    NeonSize.FULL_WIDTH -> androidx.compose.ui.unit.Constraints.Infinity
                },
                height = when (size) {
                    NeonSize.SMALL -> 44.dp
                    NeonSize.MEDIUM -> 52.dp
                    NeonSize.LARGE -> 60.dp
                    NeonSize.FULL_WIDTH -> 56.dp
                }
            )
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        if (enabled) colors.bgTop else colors.bgTop.copy(alpha = 0.5f),
                        if (enabled) colors.bgBottom else colors.bgBottom.copy(alpha = 0.5f)
                    )
                )
            )
            .border(
                width = 1.5.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        if (enabled) colors.borderStart else colors.borderStart.copy(alpha = 0.3f),
                        if (enabled) colors.borderEnd else colors.borderEnd.copy(alpha = 0.3f)
                    )
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .shadow(
                Shadow(
                    offset = androidx.compose.ui.geometry.Offset(0f, 0f),
                    blurRadius = (8 * glowIntensity).dp.toPx(),
                    color = if (enabled) colors.glowColor.copy(alpha = 0.4f * glowIntensity) else Color.Transparent
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .scale(scale)
            .animationSpec = tween(100)
            .clickable(enabled = enabled, onClick = onClick)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            icon?.let {
                Icon(
                    imageVector = it,
                    contentDescription = null,
                    tint = if (enabled) colors.textColor else colors.textColor.copy(alpha = 0.5f),
                    modifier = Modifier.size(20.dp).padding(end = 8.dp)
                )
            }
            Text(
                text = text,
                color = if (enabled) colors.textColor else colors.textColor.copy(alpha = 0.5f),
                fontSize = when (size) {
                    NeonSize.SMALL -> 13.sp
                    NeonSize.MEDIUM -> 15.sp
                    NeonSize.LARGE -> 17.sp
                    NeonSize.FULL_WIDTH -> 16.sp
                },
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
            )
        }
    }
}

enum class NeonStyle {
    PRIMARY, ACCENT, SUCCESS, WARNING, ERROR, GHOST, VIBRANT
}

enum class NeonSize {
    SMALL, MEDIUM, LARGE, FULL_WIDTH
}

data class NeonColors(
    val bgTop: Color,
    val bgBottom: Color,
    val borderStart: Color,
    val borderEnd: Color,
    val glowColor: Color,
    val textColor: Color
) {
    constructor(style: NeonStyle) : this(
        bgTop = when (style) {
            NeonStyle.PRIMARY -> Color(0x1A00D4FF)
            NeonStyle.ACCENT -> Color(0x1A00FF88)
            NeonStyle.SUCCESS -> Color(0x1A10B981)
            NeonStyle.WARNING -> Color(0x1AF59E0B)
            NeonStyle.ERROR -> Color(0x1AEF4444)
            NeonStyle.GHOST -> Color(0x1AFFFFFF)
            NeonStyle.VIBRANT -> Color(0x1AFF6B35)
        },
        bgBottom = when (style) {
            NeonStyle.PRIMARY -> Color(0x0A00D4FF)
            NeonStyle.ACCENT -> Color(0x0A00FF88)
            NeonStyle.SUCCESS -> Color(0x0A10B981)
            NeonStyle.WARNING -> Color(0x0AF59E0B)
            NeonStyle.ERROR -> Color(0x0AEF4444)
            NeonStyle.GHOST -> Color(0x0AFFFFFF)
            NeonStyle.VIBRANT -> Color(0x0AFF6B35)
        },
        borderStart = when (style) {
            NeonStyle.PRIMARY -> Color(0x00D4FF)
            NeonStyle.ACCENT -> Color(0x00FF88)
            NeonStyle.SUCCESS -> Color(0x10B981)
            NeonStyle.WARNING -> Color(0xF59E0B)
            NeonStyle.ERROR -> Color(0xEF4444)
            NeonStyle.GHOST -> Color.White.copy(alpha = 0.5f)
            NeonStyle.VIBRANT -> Color(0xFF6B35)
        },
        borderEnd = when (style) {
            NeonStyle.PRIMARY -> Color(0x00D4FF).copy(alpha = 0.3f)
            NeonStyle.ACCENT -> Color(0x00FF88).copy(alpha = 0.3f)
            NeonStyle.SUCCESS -> Color(0x10B981).copy(alpha = 0.3f)
            NeonStyle.WARNING -> Color(0xF59E0B).copy(alpha = 0.3f)
            NeonStyle.ERROR -> Color(0xEF4444).copy(alpha = 0.3f)
            NeonStyle.GHOST -> Color.White.copy(alpha = 0.1f)
            NeonStyle.VIBRANT -> Color(0xFF6B35).copy(alpha = 0.3f)
        },
        glowColor = when (style) {
            NeonStyle.PRIMARY -> Color(0x00D4FF)
            NeonStyle.ACCENT -> Color(0x00FF88)
            NeonStyle.SUCCESS -> Color(0x10B981)
            NeonStyle.WARNING -> Color(0xF59E0B)
            NeonStyle.ERROR -> Color(0xEF4444)
            NeonStyle.GHOST -> Color.White
            NeonStyle.VIBRANT -> Color(0xFF6B35)
        },
        textColor = when (style) {
            NeonStyle.PRIMARY -> Color(0x00D4FF)
            NeonStyle.ACCENT -> Color(0x00FF88)
            NeonStyle.SUCCESS -> Color(0x10B981)
            NeonStyle.WARNING -> Color(0xF59E0B)
            NeonStyle.ERROR -> Color.White
            NeonStyle.GHOST -> Color.White
            NeonStyle.VIBRANT -> Color.White
        }
    )
}

@Composable
fun AnimatedProgressRing(
    progress: Float,
    modifier: Modifier = Modifier.size(80.dp),
    strokeWidth: Float = 6f,
    style: ProgressRingStyle = ProgressRingStyle.NEON,
    showPercentage: Boolean = true,
    animate: Boolean = true
) {
    val animatedProgress by androidx.compose.animation.animateFloatAsState(
        targetValue = if (animate) progress else progress,
        animationSpec = androidx.compose.animation.core.tween(500, delayMillis = 0, easing = { it * it })
    )
    
    val colors = ProgressRingColors(style)
    
    androidx.compose.foundation.Canvas(modifier = modifier) {
        val center = androidx.compose.ui.geometry.Offset(size.width / 2f, size.height / 2f)
        val radius = (size.width - strokeWidth.dp.toPx()) / 2f
        
        // Background ring
        drawCircle(
            color = colors.trackColor,
            center = center,
            radius = radius,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth.dp.toPx())
        )
        
        // Progress ring with gradient
        val sweepAngle = 360f * animatedProgress
        val path = androidx.compose.ui.graphics.Path().apply {
            addArc(
                left = center.x - radius,
                top = center.y - radius,
                right = center.x + radius,
                bottom = center.y + radius,
                startAngle = -90f,
                sweepAngle = sweepAngle
            )
        }
        
        drawPath(
            path = path,
            color = colors.progressColor,
            style = androidx.compose.ui.graphics.drawscope.Stroke(
                width = strokeWidth.dp.toPx(),
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        )
        
        // Glow effect
        if (animatedProgress > 0) {
            val glowPath = androidx.compose.ui.graphics.Path().apply {
                addArc(
                    left = center.x - radius - 4f,
                    top = center.y - radius - 4f,
                    right = center.x + radius + 4f,
                    bottom = center.y + radius + 4f,
                    startAngle = -90f,
                    sweepAngle = sweepAngle
                )
            }
            drawPath(
                path = glowPath,
                color = colors.glowColor.copy(alpha = 0.3f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = (strokeWidth + 4f).dp.toPx(),
                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                )
            )
        }
        
        // Secondary progress ring
        val secondaryProgress = (animatedProgress * 0.6f) % 1f
        val secondarySweep = 360f * secondaryProgress
        val secondaryPath = androidx.compose.ui.graphics.Path().apply {
            addArc(
                left = center.x - radius + 12f,
                top = center.y - radius + 12f,
                right = center.x + radius - 12f,
                bottom = center.y + radius - 12f,
                startAngle = 90f,
                sweepAngle = secondarySweep
            )
        }
        drawPath(
            path = secondaryPath,
            color = colors.secondaryColor.copy(alpha = 0.4f),
            style = androidx.compose.ui.graphics.drawscope.Stroke(
                width = 2.dp.toPx(),
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        )
        
        if (showPercentage) {
            drawIntoCanvas {
                it.drawText(
                    text = androidx.compose.ui.text.AnnotatedString(
                        text = "${(animatedProgress * 100).toInt()}%",
                        style = androidx.compose.ui.text.TextStyle(
                            color = colors.textColor,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        )
                    ),
                    x = center.x - 25f,
                    y = center.y + 7f
                )
            }
        }
    }
}

enum class ProgressRingStyle {
    NEON, MINIMAL, GLASS, VIBRANT
}

data class ProgressRingColors(
    val trackColor: Color,
    val progressColor: Color,
    val glowColor: Color,
    val secondaryColor: Color,
    val textColor: Color
) {
    constructor(style: ProgressRingStyle) : this(
        trackColor = when (style) {
            ProgressRingStyle.NEON -> Color.White.copy(alpha = 0.1f)
            ProgressRingStyle.MINIMAL -> Color.White.copy(alpha = 0.2f)
            ProgressRingStyle.GLASS -> Color.White.copy(alpha = 0.15f)
            ProgressRingStyle.VIBRANT -> Color(0xFF6B35).copy(alpha = 0.2f)
        },
        progressColor = when (style) {
            ProgressRingStyle.NEON -> Color(0x00D4FF)
            ProgressRingStyle.MINIMAL -> Color.White
            ProgressRingStyle.GLASS -> Color(0x00D4FF)
            ProgressRingStyle.VIBRANT -> Color(0xFF6B35)
        },
        glowColor = when (style) {
            ProgressRingStyle.NEON -> Color(0x00D4FF)
            ProgressRingStyle.MINIMAL -> Color.White
            ProgressRingStyle.GLASS -> Color(0x00D4FF)
            ProgressRingStyle.VIBRANT -> Color(0xFF6B35)
        },
        secondaryColor = when (style) {
            ProgressRingStyle.NEON -> Color(0x00FF88)
            ProgressRingStyle.MINIMAL -> Color.White.copy(alpha = 0.5f)
            ProgressRingStyle.GLASS -> Color(0x00FF88)
            ProgressRingStyle.VIBRANT -> Color(0xFF6B35)
        },
        textColor = when (style) {
            ProgressRingStyle.NEON -> Color(0x00D4FF)
            ProgressRingStyle.MINIMAL -> Color.White
            ProgressRingStyle.GLASS -> Color(0x00D4FF)
            ProgressRingStyle.VIBRANT -> Color.White
        }
    )
}

@Composable
fun ShimmerLoading(
    modifier: Modifier = Modifier.fillMaxWidth().height(20.dp),
    cornerRadius: Float = 8f,
    baseColor: Color = Color.White.copy(alpha = 0.1f),
    highlightColor: Color = Color.White.copy(alpha = 0.3f),
    animationDuration: Int = 1500
) {
    val progress = androidx.compose.animation.core.animateFloat(
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(animationDuration),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        ),
        label = "shimmer"
    ).value
    
    androidx.compose.foundation.Canvas(modifier = modifier) {
        val rect = androidx.compose.ui.graphics.Rect(0f, 0f, size.width, size.height)
        
        // Base
        drawRect(
            color = baseColor,
            topLeft = rect.topLeft,
            size = rect.size,
            style = androidx.compose.ui.graphics.drawscope.Fill,
            clip = androidx.compose.ui.graphics.Outline.RoundedRect(rect, cornerRadius.dp.toPx())
        )
        
        // Shimmer sweep
        val sweepWidth = size.width * 0.3f
        val sweepX = -sweepWidth + (size.width + sweepWidth) * progress
        
        val shimmerRect = androidx.compose.ui.graphics.Rect(
            left = sweepX,
            top = 0f,
            right = sweepX + sweepWidth,
            bottom = size.height
        )
        
        if (sweepX < size.width && sweepX + sweepWidth > 0) {
            drawRect(
                color = highlightColor,
                topLeft = shimmerRect.topLeft,
                size = shimmerRect.size,
                style = androidx.compose.ui.graphics.drawscope.Fill,
                clip = androidx.compose.ui.graphics.Outline.RoundedRect(rect, cornerRadius.dp.toPx())
            )
        }
    }
}

@Composable
fun ParticleBackground(
    modifier: Modifier = Modifier.fillMaxSize(),
    particleCount: Int = 30,
    color: Color = Color(0x00D4FF),
    speed: Float = 1f,
    interactionEnabled: Boolean = true
) {
    val particles = remember {
        (1..particleCount).map { _ ->
            Particle(
                x = Math.random().toFloat(),
                y = Math.random().toFloat(),
                vx = (Math.random().toFloat() - 0.5f) * 0.0005f * speed,
                vy = (Math.random().toFloat() - 0.5f) * 0.0005f * speed,
                size = (Math.random().toFloat() * 2f + 1f) * speed,
                alpha = (Math.random().toFloat() * 0.3f + 0.05f),
                color = color
            )
        }
    }
    
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
    val _ by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(16, delayMillis = 0, easing = { it }),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        )
    )
    
    androidx.compose.foundation.Canvas(modifier = modifier) {
        for (particle in particles) {
            // Update position
            particle.x += particle.vx
            particle.y += particle.vy
            
            // Wrap around
            if (particle.x < 0) particle.x = 1f
            if (particle.x > 1) particle.x = 0f
            if (particle.y < 0) particle.y = 1f
            if (particle.y > 1) particle.y = 0f
            
            val x = particle.x * size.width
            val y = particle.y * size.height
            val radius = particle.size.dp.toPx()
            
            drawCircle(
                color = particle.color.copy(alpha = particle.alpha),
                center = androidx.compose.ui.geometry.Offset(x, y),
                radius = radius
            )
        }
    }
}

data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val size: Float,
    val alpha: Float,
    val color: Color
)

@Composable
fun HolographicScanner(
    modifier: Modifier = Modifier.size(200.dp),
    color: Color = Color(0x00D4FF),
    scanSpeed: Float = 1f,
    showGrid: Boolean = true
) {
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
    val scanProgress = infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween((2000 / scanSpeed).toInt(), easing = { it }),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        )
    )
    
    val rotationAngle = infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween((4000 / scanSpeed).toInt(), easing = { it }),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        )
    )
    
    androidx.compose.foundation.Canvas(modifier = modifier) {
        val centerX = size.width / 2f
        val centerY = size.height / 2f
        val radius = min(size.width, size.height) / 2f * 0.9f
        
        // Grid
        if (showGrid) {
            val gridSize = radius / 8f
            for (i in -8..8) {
                val x = centerX + i * gridSize
                val alpha = 0.05f + 0.03f * kotlin.math.sin(rotationAngle.value * 0.01f + i * 0.5f)
                drawLine(
                    color = color.copy(alpha = alpha),
                    start = androidx.compose.ui.geometry.Offset(x, centerY - radius),
                    end = androidx.compose.ui.geometry.Offset(x, centerY + radius),
                    strokeWidth = 0.5f
                )
            }
            for (i in -8..8) {
                val y = centerY + i * gridSize
                val alpha = 0.05f + 0.03f * kotlin.math.sin(rotationAngle.value * 0.01f + i * 0.3f)
                drawLine(
                    color = color.copy(alpha = alpha),
                    start = androidx.compose.ui.geometry.Offset(centerX - radius, y),
                    end = androidx.compose.ui.geometry.Offset(centerX + radius, y),
                    strokeWidth = 0.5f
                )
            }
        }
        
        // Concentric rings
        for (i in 1..5) {
            val ringRadius = radius * i / 5f
            val alpha = 0.1f / i
            drawCircle(
                color = color.copy(alpha = alpha),
                center = androidx.compose.ui.geometry.Offset(centerX, centerY),
                radius = ringRadius,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 0.5f)
            )
        }
        
        // Rotating ring
        val rotRingRadius = radius * 0.7f
        androidx.compose.ui.draw.rotate(degrees = rotationAngle.value, pivotX = centerX, pivotY = centerY) {
            drawCircle(
                color = color.copy(alpha = 0.3f),
                center = androidx.compose.ui.geometry.Offset(centerX, centerY),
                radius = rotRingRadius,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f)
            )
        }
        
        // Scanning line
        val scanY = centerY - radius + 2 * radius * scanProgress.value
        val scanAlpha = 1f - kotlin.math.abs(scanProgress.value - 0.5f) * 2f
        
        drawLine(
            color = color.copy(alpha = 0.8f * scanAlpha),
            start = androidx.compose.ui.geometry.Offset(centerX - radius, scanY),
            end = androidx.compose.ui.geometry.Offset(centerX + radius, scanY),
            strokeWidth = 2f
        )
        
        // Scan glow
        val glowPath = androidx.compose.ui.graphics.Path().apply {
            moveTo(centerX - radius, scanY - 10f)
            lineTo(centerX + radius, scanY - 10f)
            lineTo(centerX + radius, scanY + 10f)
            lineTo(centerX - radius, scanY + 10f)
            close()
        }
        drawPath(
            path = glowPath,
            color = color.copy(alpha = 0.1f * scanAlpha),
            style = androidx.compose.ui.graphics.drawscope.Fill
        )
        
        // Center crosshair
        val crosshairSize = 20f
        drawLine(
            color = color.copy(alpha = 0.5f),
            start = androidx.compose.ui.geometry.Offset(centerX - crosshairSize, centerY),
            end = androidx.compose.ui.geometry.Offset(centerX + crosshairSize, centerY),
            strokeWidth = 1f
        )
        drawLine(
            color = color.copy(alpha = 0.5f),
            start = androidx.compose.ui.geometry.Offset(centerX, centerY - crosshairSize),
            end = androidx.compose.ui.geometry.Offset(centerX, centerY + crosshairSize),
            strokeWidth = 1f
        )
        
        // Corner brackets
        val bracketSize = 30f
        val bracketPositions = listOf(
            Pair(centerX - radius, centerY - radius), // TL
            Pair(centerX + radius, centerY - radius), // TR
            Pair(centerX - radius, centerY + radius), // BL
            Pair(centerX + radius, centerY + radius)  // BR
        )
        for ((bx, by) in bracketPositions) {
            val isLeft = bx < centerX
            val isTop = by < centerY
            val bracketPath = androidx.compose.ui.graphics.Path().apply {
                if (isLeft && isTop) {
                    moveTo(bx, by + bracketSize)
                    lineTo(bx, by)
                    lineTo(bx + bracketSize, by)
                } else if (!isLeft && isTop) {
                    moveTo(bx - bracketSize, by)
                    lineTo(bx, by)
                    lineTo(bx, by + bracketSize)
                } else if (isLeft && !isTop) {
                    moveTo(bx, by - bracketSize)
                    lineTo(bx, by)
                    lineTo(bx + bracketSize, by)
                } else {
                    moveTo(bx, by - bracketSize)
                    lineTo(bx, by)
                    lineTo(bx - bracketSize, by)
                }
            }
            drawPath(
                path = bracketPath,
                color = color.copy(alpha = 0.6f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
            )
        }
    }
}

@Composable
fun FloatingActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    backgroundColor: Color = Color(0x00D4FF),
    contentColor: Color = Color.White,
    size: Float = 56f,
    extended: Boolean = false,
    label: String? = null
) {
    val interactionSource = androidx.compose.foundation.rememberMutableInteractionSource()
    val pressed = interactionSource.collectIsPressedAsState()
    
    val scale = if (pressed.value) 0.9f else 1f
    val elevation = if (pressed.value) 4.dp else 8.dp
    
    Box(
        modifier = modifier
            .size(size.dp, size.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(backgroundColor)
            .shadow(elevation, shape = androidx.compose.foundation.shape.CircleShape)
            .scale(scale)
            .animationSpec = androidx.compose.animation.core.tween(100)
            .clickable(interactionSource = interactionSource, onClick = onClick)
    ) {
        if (extended && label != null) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
                    .wrapContentSize(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(24.dp).padding(end = 8.dp)
                )
                Text(
                    text = label,
                    color = contentColor,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        } else {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier
                    .size(28.dp)
                    .align(Alignment.Center)
            )
        }
    }
}

@Composable
fun TypingIndicator(
    modifier: Modifier = Modifier.padding(16.dp),
    color: Color = Color(0x00D4FF),
    dotCount: Int = 3,
    animationDuration: Int = 600
) {
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
    
    Row(
        modifier = modifier,
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(4.dp)
    ) {
        for (i in 0 until dotCount) {
            val animatedY = infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                    animation = androidx.compose.animation.core.tween(
                        animationDuration,
                        delayMillis = i * 150,
                        easing = { it * it }
                    ),
                    repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
                )
            )
            
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .graphicsLayer {
                        translationY = -8.dp.toPx() * animatedY.value
                    }
                    .background(
                        color = color,
                        shape = androidx.compose.foundation.shape.CircleShape
                    )
            )
        }
    }
}

@Composable
fun StatusPill(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    color: Color = Color(0x00D4FF),
    modifier: Modifier = Modifier,
    animated: Boolean = true
) {
    val pulseScale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (animated) 1.05f else 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(1000, easing = { it * it }),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        )
    )
    
    Surface(
        modifier = modifier
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .graphicsLayer { scaleX = pulseScale; scaleY = pulseScale }
            .animationSpec = androidx.compose.animation.core.tween(100),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        color = color.copy(alpha = 0.15f),
        border = androidx.compose.foundation.border(
            1.dp,
            color.copy(alpha = 0.5f),
            androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            icon?.let {
                Icon(
                    imageVector = it,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(14.dp).padding(end = 6.dp)
                )
            }
            Text(
                text = text,
                color = color,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                letterSpacing = 0.5.sp
            )
        }
    }
}