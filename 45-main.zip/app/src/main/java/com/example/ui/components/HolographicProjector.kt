package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Canvas as ComposeCanvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawCircle
import androidx.compose.ui.graphics.drawscope.drawLine
import androidx.compose.ui.graphics.drawscope.drawPath
import androidx.compose.ui.graphics.drawscope.drawRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.px
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Random

enum class HologramMode {
    IDLE, SCANNING, PROCESSING, PROJECTING, ALERT, COMMUNICATION
}

data class HologramConfig(
    val primaryColor: Color = Color(0xFF00D4FF),
    val secondaryColor: Color = Color(0xFF00FF88),
    val accentColor: Color = Color(0xFFFF6B35),
    val intensity: Float = 1.0f,
    val scanSpeed: Float = 1.0f,
    val particleCount: Int = 50
)

@Composable
fun HolographicProjector(
    modifier: Modifier = Modifier,
    mode: HologramMode = HologramMode.IDLE,
    config: HologramConfig = HologramConfig(),
    onProjectionComplete: (() -> Unit)? = null
) {
    val density = LocalDensity.current
    val scanProgress by animateFloatAsState(
        targetValue = if (mode == HologramMode.SCANNING) 1f else 0f,
        animationSpec = tween(2000, delayMillis = 0, easing = { it })
    )

    val rotationAngle by animateFloatAsState(
        targetValue = if (mode == HologramMode.PROCESSING) 360f else 0f,
        animationSpec = tween(4000, delayMillis = 0, easing = { it })
    )

    val pulseScale by animateFloatAsState(
        targetValue = if (mode == HologramMode.PROJECTING) 1.2f else 1.0f,
        animationSpec = tween(800, delayMillis = 0, easing = { it -> (1 - (1 - it) * (1 - it)) })
    )

    val alertFlash by animateFloatAsState(
        targetValue = if (mode == HologramMode.ALERT) 1f else 0f,
        animationSpec = tween(200, delayMillis = 0)
    )

    val particles = remember {
        (1..config.particleCount).map { _ ->
            HologramParticle(
                angle = Random.nextFloat() * 360f,
                radius = Random.nextFloat() * 0.8f + 0.1f,
                speed = Random.nextFloat() * 0.5f + 0.1f,
                size = Random.nextFloat() * 3f + 1f,
                color = when (Random.nextInt(3)) {
                    0 -> config.primaryColor
                    1 -> config.secondaryColor
                    else -> config.accentColor
                }
            )
        }
    }

    val scope = rememberCoroutineScope()

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent)
    ) {
        val centerX = size.width / 2f
        val centerY = size.height / 2f
        val radius = min(size.width, size.height) / 2f * 0.85f

        // Draw holographic rings
        drawHolographicRings(centerX, centerY, radius, config, scanProgress, rotationAngle, pulseScale, alertFlash)

        // Draw scanning beam
        if (mode == HologramMode.SCANNING) {
            drawScanningBeam(centerX, centerY, radius, config, scanProgress)
        }

        // Draw projection cone
        if (mode == HologramMode.PROJECTING) {
            drawProjectionCone(centerX, centerY, radius, config, pulseScale)
        }

        // Draw particles
        drawParticles(centerX, centerY, radius, particles, mode, config)

        // Draw center core
        drawCore(centerX, centerY, radius * 0.15f, config, pulseScale, alertFlash)

        // Draw data streams
        if (mode == HologramMode.PROCESSING || mode == HologramMode.COMMUNICATION) {
            drawDataStreams(centerX, centerY, radius, config, rotationAngle)
        }

        // Draw holographic text display area
        if (mode == HologramMode.PROJECTING) {
            drawHolographicDisplay(centerX, centerY, radius, config, pulseScale)
        }
    }
}

@Composable
fun HolographicInterface(
    modifier: Modifier = Modifier,
    mode: HologramMode = HologramMode.IDLE,
    config: HologramConfig = HologramConfig(),
    displayText: String = "",
    onTap: (() -> Unit)? = null
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .clickable(onClick = onTap ?: {})
    ) {
        HolographicProjector(
            modifier = Modifier.fillMaxSize(),
            mode = mode,
            config = config
        )

        // Floating holographic UI elements
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Top status bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    HolographicText("J.A.R.V.I.S. HOLO-MATRIX", config.primaryColor, 12.sp)
                    HolographicText(mode.name, config.accentColor, 10.sp)
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Center display text
            if (displayText.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 32.dp)
                        .wrapContentHeight()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    config.primaryColor.copy(alpha = 0.1f),
                                    Color.Transparent
                                )
                            ),
                            shape = RoundedCornerShape(16.dp)
                        )
                        .padding(24.dp)
                ) {
                    HolographicText(displayText, config.primaryColor, 18.sp, textAlign = TextAlign.Center)
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Bottom controls hint
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    HolographicIcon(Icons.Default.Mic, config.primaryColor, 24.dp)
                    Spacer(modifier = Modifier.width(16.dp))
                    HolographicText("TAP TO ACTIVATE", config.secondaryColor, 10.sp)
                    Spacer(modifier = Modifier.width(16.dp))
                    HolographicIcon(Icons.Default.Close, config.accentColor, 24.dp)
                }
            }
        }
    }
}

@Composable
fun HolographicRingProgress(
    modifier: Modifier = Modifier.size(120.dp),
    progress: Float,
    config: HologramConfig = HologramConfig(),
    showPercentage: Boolean = true
) {
    Canvas(modifier = modifier) {
        val centerX = size.width / 2f
        val centerY = size.height / 2f
        val radius = min(size.width, size.height) / 2f - 8f

        // Background ring
        drawCircle(
            color = config.primaryColor.copy(alpha = 0.1f),
            center = androidx.compose.ui.geometry.Offset(centerX, centerY),
            radius = radius,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 6f)
        )

        // Progress ring
        val sweepAngle = 360f * progress
        val path = Path().apply {
            addArc(
                left = centerX - radius,
                top = centerY - radius,
                right = centerX + radius,
                bottom = centerY + radius,
                startAngle = -90f,
                sweepAngle = sweepAngle
            )
        }
        drawPath(
            path = path,
            color = config.primaryColor,
            style = androidx.compose.ui.graphics.drawscope.Stroke(
                width = 6f,
                cap = StrokeCap.Round
            )
        )

        // Secondary progress ring
        val secondaryProgress = (progress * 0.7f) % 1f
        val secondarySweep = 360f * secondaryProgress
        val secondaryPath = Path().apply {
            addArc(
                left = centerX - radius + 12f,
                top = centerY - radius + 12f,
                right = centerX + radius - 12f,
                bottom = centerY + radius - 12f,
                startAngle = 90f,
                sweepAngle = secondarySweep
            )
        }
        drawPath(
            path = secondaryPath,
            color = config.secondaryColor.copy(alpha = 0.6f),
            style = androidx.compose.ui.graphics.drawscope.Stroke(
                width = 3f,
                cap = StrokeCap.Round
            )
        )

        if (showPercentage) {
            drawIntoCanvas {
                it.drawText(
                    text = androidx.compose.ui.text.AnnotatedString(
                        text = "${(progress * 100).toInt()}%",
                        style = androidx.compose.ui.text.TextStyle(
                            color = config.primaryColor,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    ),
                    x = centerX - 30f,
                    y = centerY + 8f
                )
            }
        }
    }
}

@Composable
fun HolographicWaveform(
    modifier: Modifier = Modifier.fillMaxWidth().height(80.dp),
    audioLevel: Float,
    config: HologramConfig = HologramConfig(),
    barCount: Int = 32
) {
    Canvas(modifier = modifier) {
        val barWidth = size.width / barCount
        val maxHeight = size.height * 0.8f

        for (i in 0 until barCount) {
            val x = i * barWidth + barWidth / 2f
            val normalizedIndex = i / (barCount - 1f)
            val phase = (System.currentTimeMillis() / 100f + normalizedIndex * 100f) % 360f
            val waveHeight = (maxHeight * 0.3f + maxHeight * 0.7f * audioLevel) *
                    (0.5f + 0.5f * kotlin.math.sin(Math.toRadians(phase)))

            val barColor = when {
                normalizedIndex < 0.33f -> config.primaryColor
                normalizedIndex < 0.66f -> config.secondaryColor
                else -> config.accentColor
            }

            drawRect(
                color = barColor.copy(alpha = (0.3f + 0.7f * audioLevel)),
                topLeft = androidx.compose.ui.geometry.Offset(x - barWidth * 0.3f, size.height - waveHeight),
                size = androidx.compose.ui.geometry.Size(barWidth * 0.6f, waveHeight)
            )

            // Glow effect
            drawRect(
                color = barColor.copy(alpha = 0.1f),
                topLeft = androidx.compose.ui.geometry.Offset(x - barWidth * 0.5f, size.height - waveHeight * 1.5f),
                size = androidx.compose.ui.geometry.Size(barWidth, waveHeight * 1.5f)
            )
        }

        // Center line
        drawLine(
            color = config.primaryColor.copy(alpha = 0.2f),
            start = androidx.compose.ui.geometry.Offset(0f, size.height / 2f),
            end = androidx.compose.ui.geometry.Offset(size.width, size.height / 2f),
            strokeWidth = 1f,
            pathEffect = PathEffect.makeDashPathEffect(floatArrayOf(5f, 5f), 0f)
        )
    }
}

@Composable
private fun HolographicText(
    text: String,
    color: Color,
    fontSize: androidx.compose.ui.unit.TextUnit,
    textAlign: TextAlign = TextAlign.Start
) {
    Text(
        text = text,
        color = color.copy(alpha = 0.9f),
        fontSize = fontSize,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace,
        letterSpacing = 1.5.sp,
        textAlign = textAlign,
        style = androidx.compose.ui.text.TextStyle(
            shadow = androidx.compose.ui.graphics.Shadow(
                color = color.copy(alpha = 0.5f),
                offset = androidx.compose.ui.geometry.Offset(0f, 0f),
                blurRadius = 8f
            )
        )
    )
}

@Composable
private fun HolographicIcon(
    icon: androidx.compose.material.icons.Icons.Default,
    color: Color,
    size: androidx.compose.ui.unit.Dp
) {
    Icon(
        imageVector = icon,
        contentDescription = null,
        tint = color.copy(alpha = 0.8f),
        modifier = Modifier.size(size)
    )
}

private fun drawHolographicRings(
    centerX: Float, centerY: Float, radius: Float,
    config: HologramConfig, scanProgress: Float, rotationAngle: Float,
    pulseScale: Float, alertFlash: Float
) {
    val ringCount = 6
    for (i in 0 until ringCount) {
        val ringRadius = radius * (0.2f + 0.13f * i) * pulseScale
        val alpha = (0.15f + 0.1f * i) * config.intensity
        val ringColor = when (i % 3) {
            0 -> config.primaryColor.copy(alpha = alpha)
            1 -> config.secondaryColor.copy(alpha = alpha)
            else -> config.accentColor.copy(alpha = alpha)
        }

        // Rotate alternating rings
        val rotation = if (i % 2 == 0) rotationAngle else -rotationAngle
        rotate(degrees = rotation, pivotX = centerX, pivotY = centerY) {
            drawCircle(
                color = ringColor,
                center = androidx.compose.ui.geometry.Offset(centerX, centerY),
                radius = ringRadius,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f)
            )
        }

        // Scanning highlight
        if (scanProgress > 0f) {
            val scanAngle = scanProgress * 360f
            val scanWidth = 30f
            val scanPath = Path().apply {
                addArc(
                    left = centerX - ringRadius,
                    top = centerY - ringRadius,
                    right = centerX + ringRadius,
                    bottom = centerY + ringRadius,
                    startAngle = scanAngle - scanWidth / 2,
                    sweepAngle = scanWidth
                )
            }
            drawPath(
                path = scanPath,
                color = config.accentColor.copy(alpha = 0.8f * scanProgress),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f, cap = StrokeCap.Round)
            )
        }
    }

    // Alert flash overlay
    if (alertFlash > 0f) {
        drawCircle(
            color = config.accentColor.copy(alpha = 0.3f * alertFlash),
            center = androidx.compose.ui.geometry.Offset(centerX, centerY),
            radius = radius * pulseScale,
            style = androidx.compose.ui.graphics.drawscope.Fill
        )
    }
}

private fun drawScanningBeam(
    centerX: Float, centerY: Float, radius: Float,
    config: HologramConfig, scanProgress: Float
) {
    val angle = scanProgress * 360f - 90f
    val radians = Math.toRadians(angle.toDouble())
    val endX = centerX + radius * kotlin.math.cos(radians).toFloat()
    val endY = centerY + radius * kotlin.math.sin(radians).toFloat()

    // Main beam
    drawLine(
        color = config.accentColor.copy(alpha = 0.8f),
        start = androidx.compose.ui.geometry.Offset(centerX, centerY),
        end = androidx.compose.ui.geometry.Offset(endX, endY),
        strokeWidth = 2f
    )

    // Beam glow
    val glowPath = Path().apply {
        moveTo(centerX, centerY)
        lineTo(endX + 10f, endY + 10f)
        lineTo(endX - 10f, endY - 10f)
        close()
    }
    drawPath(
        path = glowPath,
        color = config.accentColor.copy(alpha = 0.15f),
        style = androidx.compose.ui.graphics.drawscope.Fill
    )

    // Scanning line perpendicular to beam
    val perpAngle = angle + 90f
    val perpRadians = Math.toRadians(perpAngle.toDouble())
    val perpLength = radius * 0.3f
    val perpX1 = endX + perpLength * kotlin.math.cos(perpRadians).toFloat()
    val perpY1 = endY + perpLength * kotlin.math.sin(perpRadians).toFloat()
    val perpX2 = endX - perpLength * kotlin.math.cos(perpRadians).toFloat()
    val perpY2 = endY - perpLength * kotlin.math.sin(perpRadians).toFloat()

    drawLine(
        color = config.primaryColor.copy(alpha = 0.6f),
        start = androidx.compose.ui.geometry.Offset(perpX1, perpY1),
        end = androidx.compose.ui.geometry.Offset(perpX2, perpY2),
        strokeWidth = 1.5f
    )
}

private fun drawProjectionCone(
    centerX: Float, centerY: Float, radius: Float,
    config: HologramConfig, pulseScale: Float
) {
    val coneHeight = radius * 1.5f * pulseScale
    val coneWidth = radius * 0.8f * pulseScale

    val path = Path().apply {
        moveTo(centerX, centerY)
        lineTo(centerX - coneWidth, centerY - coneHeight)
        lineTo(centerX + coneWidth, centerY - coneHeight)
        close()
    }

    // Cone fill with gradient
    drawPath(
        path = path,
        color = config.primaryColor.copy(alpha = 0.08f),
        style = androidx.compose.ui.graphics.drawscope.Fill
    )

    // Cone edges
    drawPath(
        path = path,
        color = config.primaryColor.copy(alpha = 0.5f),
        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f, cap = StrokeCap.Round)
    )

    // Horizontal scan lines in cone
    for (i in 1..5) {
        val y = centerY - coneHeight * i / 6f
        val lineWidth = coneWidth * i / 6f
        drawLine(
            color = config.secondaryColor.copy(alpha = 0.3f),
            start = androidx.compose.ui.geometry.Offset(centerX - lineWidth, y),
            end = androidx.compose.ui.geometry.Offset(centerX + lineWidth, y),
            strokeWidth = 0.5f
        )
    }
}

private fun drawParticles(
    centerX: Float, centerY: Float, radius: Float,
    particles: List<HologramParticle>,
    mode: HologramMode,
    config: HologramConfig
) {
    for (particle in particles) {
        val particleRadius = radius * particle.radius
        val angleRadians = Math.toRadians((particle.angle + System.currentTimeMillis() / 1000f * particle.speed * 50f) % 360f)
        val x = centerX + particleRadius * kotlin.math.cos(angleRadians).toFloat()
        val y = centerY + particleRadius * kotlin.math.sin(angleRadians).toFloat()

        val alpha = when (mode) {
            HologramMode.IDLE -> 0.3f
            HologramMode.SCANNING -> 0.6f
            HologramMode.PROCESSING -> 0.8f
            HologramMode.PROJECTING -> 1.0f
            HologramMode.ALERT -> 1.0f
            HologramMode.COMMUNICATION -> 0.7f
        } * config.intensity

        drawCircle(
            color = particle.color.copy(alpha = alpha),
            center = androidx.compose.ui.geometry.Offset(x, y),
            radius = particle.size * config.intensity
        )

        // Trail effect
        if (mode == HologramMode.PROCESSING || mode == HologramMode.PROJECTING) {
            val trailLength = 5
            for (j in 1..trailLength) {
                val trailAngle = (particle.angle - j * 10f + System.currentTimeMillis() / 1000f * particle.speed * 50f) % 360f
                val trailRadians = Math.toRadians(trailAngle.toDouble())
                val trailX = centerX + particleRadius * 0.9f * kotlin.math.cos(trailRadians).toFloat()
                val trailY = centerY + particleRadius * 0.9f * kotlin.math.sin(trailRadians).toFloat()
                drawCircle(
                    color = particle.color.copy(alpha = alpha * (1f - j / trailLength.toFloat()) * 0.3f),
                    center = androidx.compose.ui.geometry.Offset(trailX, trailY),
                    radius = particle.size * (1f - j / trailLength.toFloat()) * 0.5f
                )
            }
        }
    }
}

private fun drawCore(
    centerX: Float, centerY: Float, coreRadius: Float,
    config: HologramConfig, pulseScale: Float, alertFlash: Float
) {
    val effectiveRadius = coreRadius * pulseScale

    // Core glow layers
    for (i in 0..3) {
        val glowRadius = effectiveRadius * (1f + i * 0.5f)
        val glowAlpha = (0.3f - i * 0.07f) * config.intensity
        drawCircle(
            color = config.primaryColor.copy(alpha = glowAlpha),
            center = androidx.compose.ui.geometry.Offset(centerX, centerY),
            radius = glowRadius,
            style = androidx.compose.ui.graphics.drawscope.Fill
        )
    }

    // Core center
    drawCircle(
        color = Color.White.copy(alpha = 0.9f),
        center = androidx.compose.ui.geometry.Offset(centerX, centerY),
        radius = effectiveRadius * 0.6f,
        style = androidx.compose.ui.graphics.drawscope.Fill
    )

    // Core ring
    drawCircle(
        color = config.primaryColor,
        center = androidx.compose.ui.geometry.Offset(centerX, centerY),
        radius = effectiveRadius,
        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
    )

    // Alert pulse
    if (alertFlash > 0f) {
        drawCircle(
            color = config.accentColor.copy(alpha = 0.5f * alertFlash),
            center = androidx.compose.ui.geometry.Offset(centerX, centerY),
            radius = effectiveRadius * (1f + alertFlash),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f)
        )
    }
}

private fun drawDataStreams(
    centerX: Float, centerY: Float, radius: Float,
    config: HologramConfig, rotationAngle: Float
) {
    val streamCount = 8
    for (i in 0 until streamCount) {
        val angle = (rotationAngle + i * 360f / streamCount) % 360f
        val radians = Math.toRadians(angle.toDouble())
        val startRadius = radius * 0.3f
        val endRadius = radius * 0.9f

        val startX = centerX + startRadius * kotlin.math.cos(radians).toFloat()
        val startY = centerY + startRadius * kotlin.math.sin(radians).toFloat()
        val endX = centerX + endRadius * kotlin.math.cos(radians).toFloat()
        val endY = centerY + endRadius * kotlin.math.sin(radians).toFloat()

        val streamColor = when (i % 3) {
            0 -> config.primaryColor
            1 -> config.secondaryColor
            else -> config.accentColor
        }

        // Dashed line for data stream
        drawLine(
            color = streamColor.copy(alpha = 0.5f),
            start = androidx.compose.ui.geometry.Offset(startX, startY),
            end = androidx.compose.ui.geometry.Offset(endX, endY),
            strokeWidth = 1f,
            pathEffect = PathEffect.makeDashPathEffect(floatArrayOf(8f, 4f), (System.currentTimeMillis() / 10f) % 12f)
        )

        // Data packets moving along stream
        val packetProgress = (System.currentTimeMillis() / 500f + i * 100f) % 100f / 100f
        val packetX = startX + (endX - startX) * packetProgress
        val packetY = startY + (endY - startY) * packetProgress
        drawCircle(
            color = streamColor.copy(alpha = 0.8f),
            center = androidx.compose.ui.geometry.Offset(packetX, packetY),
            radius = 3f
        )
    }
}

private fun drawHolographicDisplay(
    centerX: Float, centerY: Float, radius: Float,
    config: HologramConfig, pulseScale: Float
) {
    val displayY = centerY - radius * 1.8f * pulseScale
    val displayWidth = radius * 1.6f
    val displayHeight = radius * 0.8f

    // Display frame
    val framePath = Path().apply {
        addRoundRect(
            left = centerX - displayWidth / 2f,
            top = displayY - displayHeight / 2f,
            right = centerX + displayWidth / 2f,
            bottom = displayY + displayHeight / 2f,
            rx = 12f, ry = 12f
        )
    }
    drawPath(
        path = framePath,
        color = config.primaryColor.copy(alpha = 0.2f),
        style = androidx.compose.ui.graphics.drawscope.Fill
    )
    drawPath(
        path = framePath,
        color = config.primaryColor.copy(alpha = 0.6f),
        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
    )

    // Corner brackets
    val bracketSize = 16f
    val corners = listOf(
        Pair(centerX - displayWidth / 2f, displayY - displayHeight / 2f), // TL
        Pair(centerX + displayWidth / 2f, displayY - displayHeight / 2f), // TR
        Pair(centerX - displayWidth / 2f, displayY + displayHeight / 2f), // BL
        Pair(centerX + displayWidth / 2f, displayY + displayHeight / 2f)  // BR
    )
    for ((cx, cy) in corners) {
        val isLeft = cx < centerX
        val isTop = cy < centerY
        val bracketPath = Path().apply {
            if (isLeft && isTop) {
                moveTo(cx, cy + bracketSize)
                lineTo(cx, cy)
                lineTo(cx + bracketSize, cy)
            } else if (!isLeft && isTop) {
                moveTo(cx - bracketSize, cy)
                lineTo(cx, cy)
                lineTo(cx, cy + bracketSize)
            } else if (isLeft && !isTop) {
                moveTo(cx, cy - bracketSize)
                lineTo(cx, cy)
                lineTo(cx + bracketSize, cy)
            } else {
                moveTo(cx, cy - bracketSize)
                lineTo(cx, cy)
                lineTo(cx - bracketSize, cy)
            }
        }
        drawPath(
            path = bracketPath,
            color = config.accentColor.copy(alpha = 0.8f),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f, cap = StrokeCap.Round)
        )
    }

    // "PROJECTING" label
    drawIntoCanvas {
        it.drawText(
            text = androidx.compose.ui.text.AnnotatedString(
                text = "HOLOGRAPHIC PROJECTION ACTIVE",
                style = androidx.compose.ui.text.TextStyle(
                    color = config.secondaryColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )
            ),
            x = centerX - 100f,
            y = displayY + displayHeight / 2f + 20f
        )
    }
}

data class HologramParticle(
    var angle: Float,
    val radius: Float,
    val speed: Float,
    val size: Float,
    val color: Color
)

private fun rememberCoroutineScope(): CoroutineScope {
    val scope = remember { kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.Main) }
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { scope.coroutineContext.cancel() }
    }
    return scope
}

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.text.TextAlign
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp