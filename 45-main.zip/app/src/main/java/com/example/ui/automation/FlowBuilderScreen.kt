package com.example.ui.automation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.dragDetected
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DragIndicator
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.px
import com.example.ui.components.AdvancedUIComponents.GlassCard
import com.example.ui.components.AdvancedUIComponents.GlassElevation
import com.example.ui.components.AdvancedUIComponents.GlassTint
import com.example.ui.components.AdvancedUIComponents.NeonButton
import com.example.ui.components.AdvancedUIComponents.NeonSize
import com.example.ui.components.AdvancedUIComponents.NeonStyle
import com.example.ui.components.AdvancedUIComponents.StatusPill
import com.example.ui.theme.JarvisAmber
import com.example.ui.theme.JarvisGreen
import com.example.ui.theme.JarvisObsidian
import com.example.ui.theme.JarvisRed
import com.example.ui.theme.JarvisTextMuted
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

data class FlowNode(
    val id: String = UUID.randomUUID().toString(),
    val type: NodeType,
    val position: Position = Position(0f, 0f),
    val config: Map<String, Any> = emptyMap(),
    val label: String = ""
)

data class Position(val x: Float, val y: Float)

enum class NodeType(
    val name: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color,
    val category: String,
    val inputs: Int,
    val outputs: Int
) {
    TRIGGER_VOICE("Voice Command", Icons.Default.Mic, Color(0x00D4FF), "Triggers", 0, 1),
    TRIGGER_TIME("Time Schedule", Icons.Default.Schedule, Color(0xF59E0B), "Triggers", 0, 1),
    TRIGGER_SENSOR("Sensor Event", Icons.Default.Sensors, Color(0x10B981), "Triggers", 0, 1),
    TRIGGER_WEBHOOK("Webhook", Icons.Default.Webhook, Color(0x8B5CF6), "Triggers", 0, 1),
    
    ACTION_LIGHT("Control Light", Icons.Default.Lightbulb, Color(0xF59E0B), "Actions", 1, 1),
    ACTION_SWITCH("Toggle Switch", Icons.Default.ToggleOn, Color(0x10B981), "Actions", 1, 1),
    ACTION_THERMOSTAT("Set Temperature", Icons.Default.Thermostat, Color(0xEF4444), "Actions", 1, 1),
    ACTION_LOCK("Lock/Unlock", Icons.Default.Lock, Color(0x8B5CF6), "Actions", 1, 1),
    ACTION_NOTIFICATION("Send Notification", Icons.Default.Notifications, Color(0x00D4FF), "Actions", 1, 1),
    ACTION_SPEAK("Speak Text", Icons.Default.VolumeUp, Color(0x00FF88), "Actions", 1, 1),
    ACTION_WEB_REQUEST("HTTP Request", Icons.Default.Http, Color(0x6366F1), "Actions", 1, 1),
    ACTION_DELAY("Delay", Icons.Default.Timer, Color(0x64748B), "Actions", 1, 1),
    
    CONDITION_IF("If Condition", Icons.Default.FilterList, Color(0x6366F1), "Logic", 2, 2),
    CONDITION_COMPARE("Compare Values", Icons.Default.Compare, Color(0x8B5CF6), "Logic", 2, 2),
    CONDITION_AND("And", Icons.Default.CheckBox, Color(0x00D4FF), "Logic", 2, 1),
    CONDITION_OR("Or", Icons.Default.CheckBoxOutlineBlank, Color(0x00FF88), "Logic", 2, 1),
    
    TRANSFORM_JSON("Parse JSON", Icons.Default.Code, Color(0xEC4899), "Transform", 1, 1),
    TRANSFORM_TEMPLATE("Format Text", Icons.Default.FormatQuote, Color(0xF97316), "Transform", 1, 1),
    TRANSFORM_MATH("Calculate", Icons.Default.Calculate, Color(0x14B8A6), "Transform", 1, 1)
)

data class Connection(
    val id: String = UUID.randomUUID().toString(),
    val fromNodeId: String,
    val fromOutput: Int,
    val toNodeId: String,
    val toInput: Int
)

@Composable
fun AutomationFlowBuilder(
    onSave: (FlowDefinition) -> Unit,
    onTest: (FlowDefinition) -> Unit,
    initialFlow: FlowDefinition? = null
) {
    val nodes = remember { mutableStateListOf<FlowNode>() }
    val connections = remember { mutableStateListOf<Connection>() }
    val selectedNode = remember { mutableStateOf<FlowNode?>(null) }
    val connectingFrom = remember { mutableStateOf<Pair<String, Int>?>(null) }
    val panOffset = remember { mutableStateOf(Position(0f, 0f)) }
    val scale = remember { mutableStateOf(1f) }
    val showNodePalette = remember { mutableStateOf(true) }
    val isRunning = remember { mutableStateOf(false) }
    
    // Initialize with default flow or empty
    LaunchedEffect(initialFlow) {
        nodes.clear()
        connections.clear()
        initialFlow?.nodes?.forEach { nodes.add(it) }
        initialFlow?.connections?.forEach { connections.add(it) }
    }

    Box(modifier = Modifier.fillMaxSize().background(JarvisObsidian)) {
        // Canvas area
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 120.dp, top = 80.dp)
                .pointerInput(Unit) {
                    // Pan gesture
                    androidx.compose.foundation.gestures.detectDragGestures(
                        onDrag = { change ->
                            panOffset.value = Position(
                                panOffset.value.x + change.positionChange().x / scale.value,
                                panOffset.value.y + change.positionChange().y / scale.value
                            )
                        }
                    )
                }
        ) {
            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                
                // Draw grid
                drawGrid(canvasWidth, canvasHeight, panOffset.value, scale.value)
                
                // Draw connections
                for (connection in connections) {
                    val fromNode = nodes.find { it.id == connection.fromNodeId }
                    val toNode = nodes.find { it.id == connection.toNodeId }
                    if (fromNode != null && toNode != null) {
                        drawConnection(
                            fromNode, toNode,
                            connection.fromOutput, connection.toInput,
                            panOffset.value, scale.value
                        )
                    }
                }
                
                // Draw connection in progress
                connectingFrom.value?.let { (fromId, fromOutput) ->
                    val fromNode = nodes.find { it.id == fromId }
                    fromNode?.let { node ->
                        drawPendingConnection(
                            node, fromOutput,
                            panOffset.value, scale.value
                        )
                    }
                }
            }
            
            // Draw nodes
            for (node in nodes) {
                FlowNodeView(
                    node = node,
                    isSelected = selectedNode.value?.id == node.id,
                    onClick = { selectedNode.value = node },
                    onDrag = { delta ->
                        val updated = node.copy(position = Position(
                            node.position.x + delta.x / scale.value,
                            node.position.y + delta.y / scale.value
                        ))
                        val index = nodes.indexOf(node)
                        if (index >= 0) nodes[index] = updated
                    },
                    onOutputClick = { outputIndex ->
                        if (connectingFrom.value == null) {
                            connectingFrom.value = node.id to outputIndex
                        }
                    },
                    onInputClick = { inputIndex ->
                        connectingFrom.value?.let { (fromId, fromOutput) ->
                            if (fromId != node.id) {
                                connections.add(Connection(
                                    fromNodeId = fromId,
                                    fromOutput = fromOutput,
                                    toNodeId = node.id,
                                    toInput = inputIndex
                                ))
                            }
                            connectingFrom.value = null
                        }
                    },
                    panOffset = panOffset.value,
                    scale = scale.value
                )
            }
        }
        
        // Top toolbar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .height(60.dp)
                .align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusPill(
                        text = "FLOW BUILDER",
                        icon = Icons.Default.Settings,
                        color = Color(0x00D4FF)
                    )
                    
                    StatusPill(
                        text = "${nodes.size} nodes",
                        color = JarvisAmber
                    )
                    
                    StatusPill(
                        text = "${connections.size} connections",
                        color = JarvisGreen
                    )
                }
                
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonButton(
                        text = "Test",
                        icon = Icons.Default.PlayArrow,
                        onClick = {
                            val flow = FlowDefinition(nodes.toList(), connections.toList())
                            onTest(flow)
                            isRunning.value = true
                        },
                        style = NeonStyle.SUCCESS,
                        size = NeonSize.SMALL
                    )
                    
                    NeonButton(
                        text = "Save",
                        icon = Icons.Default.Check,
                        onClick = {
                            val flow = FlowDefinition(nodes.toList(), connections.toList())
                            onSave(flow)
                        },
                        style = NeonStyle.PRIMARY,
                        size = NeonSize.SMALL
                    )
                }
            }
        }
        
        // Node Palette (bottom)
        AnimatedVisibility(
            visible = showNodePalette.value,
            enter = androidx.compose.animation.slideInVertically(
                initialOffsetY = { it },
                animationSpec = tween(300, easing = FastOutSlowInEasing)
            ),
            exit = androidx.compose.animation.slideOutVertically(
                targetOffsetY = { it },
                animationSpec = tween(200, easing = FastOutSlowInEasing)
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 16.dp, horizontal = 16.dp)
            ) {
                GlassCard(
                    modifier = Modifier.fillMaxSize(),
                    elevation = GlassElevation.HIGH,
                    tint = GlassTint.NEUTRAL
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "NODE PALETTE",
                                color = JarvisTextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 1.sp
                            )
                            IconButton(onClick = { showNodePalette.value = false }) {
                                Icon(Icons.Default.Close, "Close", tint = JarvisTextMuted, modifier = Modifier.size(20.dp))
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        androidx.compose.foundation.layout.Box(
                            modifier = Modifier.fillMaxWidth().height(60.dp)
                        ) {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp),
                                userScrollEnabled = true
                            ) {
                                items(NodeType.values().groupBy { it.category }.keys) { category ->
                                    FlowCategorySection(category = category)
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // Node config panel
        selectedNode.value?.let { node ->
            AnimatedVisibility(
                visible = true,
                enter = fadeIn(tween(200)),
                exit = fadeOut(tween(150))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 140.dp, horizontal = 16.dp)
                ) {
                    FlowNodeConfigPanel(
                        node = node,
                        onConfigChange = { newConfig ->
                            val index = nodes.indexOf(node)
                            if (index >= 0) nodes[index] = node.copy(config = newConfig)
                        },
                        onDelete = {
                            nodes.remove(node)
                            connections.removeAll { it.fromNodeId == node.id || it.toNodeId == node.id }
                            selectedNode.value = null
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun FlowCategorySection(category: String) {
    val nodesInCategory = NodeType.values().filter { it.category == category }
    
    Column(
        modifier = Modifier.padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = category.uppercase(),
            color = JarvisTextMuted,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            nodesInCategory.forEach { nodeType ->
                DraggableFlowNode(
                    nodeType = nodeType,
                    onDragStart = { /* Handle drag to canvas */ }
                )
            }
        }
    }
}

@Composable
fun DraggableFlowNode(
    nodeType: NodeType,
    onDragStart: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(70.dp, 60.dp)
            .background(
                Brush.verticalGradient(
                    listOf(
                        nodeType.color.copy(alpha = 0.2f),
                        nodeType.color.copy(alpha = 0.05f)
                    )
                ),
                shape = RoundedCornerShape(12.dp)
            )
            .border(1.dp, nodeType.color.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            .pointerInput(nodeType) {
                androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress(
                    onDragStart = { onDragStart() },
                    onDrag = { change, _ -> },
                    onDragEnd = { /* Drop on canvas */ },
                    onDragCancel = { }
                )
            }
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = nodeType.icon,
                contentDescription = null,
                tint = nodeType.color,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = nodeType.name,
                color = JarvisTextPrimary,
                fontSize = 8.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = androidx.compose.ui.text.TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun FlowNodeView(
    node: FlowNode,
    isSelected: Boolean,
    onClick: () -> Unit,
    onDrag: (Position) -> Unit,
    onOutputClick: (Int) -> Unit,
    onInputClick: (Int) -> Unit,
    panOffset: Position,
    scale: Float
) {
    val screenX = (node.position.x + panOffset.x) * scale
    val screenY = (node.position.y + panOffset.y) * scale
    val nodeWidth = 140f * scale
    val nodeHeight = (80 + node.type.outputs * 20).dp.toPx()
    
    Box(
        modifier = Modifier
            .size(nodeWidth, nodeHeight)
            .offset(x = (screenX - nodeWidth / 2).dp, y = (screenY - nodeHeight / 2).dp)
            .pointerInput(node) {
                androidx.compose.foundation.gestures.detectDragGestures(
                    onDrag = { change ->
                        onDrag(Position(
                            change.positionChange().x / scale,
                            change.positionChange().y / scale
                        ))
                    }
                )
            }
            .clickable(onClick = onClick)
    ) {
        GlassCard(
            modifier = Modifier.fillMaxSize(),
            elevation = if (isSelected) GlassElevation.HIGH else GlassElevation.MEDIUM,
            tint = GlassTint.values().firstOrNull { it.name == node.type.category.uppercase() } ?: GlassTint.NEUTRAL
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = node.type.icon,
                            contentDescription = null,
                            tint = node.type.color,
                            modifier = Modifier.size(16.dp).padding(end = 6.dp)
                        )
                        Text(
                            text = node.type.name,
                            color = JarvisTextPrimary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    if (isSelected) {
                        Icon(Icons.Default.Check, "Selected", tint = node.type.color, modifier = Modifier.size(14.dp))
                    }
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                // Inputs
                if (node.type.inputs > 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (i in 0 until node.type.inputs) {
                            InputPort(
                                color = node.type.color,
                                onClick = { onInputClick(i) }
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                // Outputs
                if (node.type.outputs > 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (i in 0 until node.type.outputs) {
                            OutputPort(
                                color = node.type.color,
                                onClick = { onOutputClick(i) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InputPort(color: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(12.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = 0.3f))
            .border(1.5.dp, color, CircleShape)
            .clickable(onClick = onClick)
    )
}

@Composable
fun OutputPort(color: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(12.dp)
            .clip(CircleShape)
            .background(color)
            .clickable(onClick = onClick)
    ) {
        Icon(
            imageVector = Icons.Default.ArrowForward,
            contentDescription = null,
            tint = Color.Black,
            modifier = Modifier.size(8.dp).align(Alignment.Center)
        )
    }
}

@Composable
fun FlowNodeConfigPanel(
    node: FlowNode,
    onConfigChange: (Map<String, Any>) -> Unit,
    onDelete: () -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxSize(),
        elevation = GlassElevation.HIGH,
        tint = GlassTint.NEUTRAL
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${node.type.name} CONFIG",
                    color = node.type.color,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, "Delete", tint = JarvisRed, modifier = Modifier.size(20.dp))
                }
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Config fields based on node type
            when (node.type) {
                NodeType.TRIGGER_VOICE -> {
                    OutlinedTextField(
                        value = node.config["phrase"] as? String ?: "",
                        onValueChange = { onConfigChange(node.config + ("phrase" to it)) },
                        label = { Text("Voice Phrase", color = JarvisTextSecondary, fontSize = 11.sp) },
                        placeholder = { Text("e.g., 'turn on lights'", color = JarvisTextMuted) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                NodeType.ACTION_LIGHT -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = node.config["deviceId"] as? String ?: "",
                            onValueChange = { onConfigChange(node.config + ("deviceId" to it)) },
                            label = { Text("Device ID", color = JarvisTextSecondary, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = (node.config["brightness"] as? Int ?: 100).toString(),
                            onValueChange = { onConfigChange(node.config + ("brightness" to it.toIntOrNull() ?: 100)) },
                            label = { Text("Brightness %", color = JarvisTextSecondary, fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                            modifier = Modifier.width(100.dp)
                        )
                    }
                }
                NodeType.ACTION_DELAY -> {
                    OutlinedTextField(
                        value = (node.config["ms"] as? Long ?: 1000).toString(),
                        onValueChange = { onConfigChange(node.config + ("ms" to it.toLongOrNull() ?: 1000)) },
                        label = { Text("Delay (ms)", color = JarvisTextSecondary, fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                NodeType.ACTION_SPEAK -> {
                    OutlinedTextField(
                        value = node.config["text"] as? String ?: "",
                        onValueChange = { onConfigChange(node.config + ("text" to it)) },
                        label = { Text("Text to Speak", color = JarvisTextSecondary, fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = false,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done)
                    )
                }
                else -> {
                    Text(
                        text = "No configuration available for ${node.type.name}",
                        color = JarvisTextMuted,
                        fontSize = 12.sp,
                        modifier = Modifier.fillMaxWidth().padding(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun drawGrid(
    width: Float, height: Float,
    panOffset: Position, scale: Float
) {
    val gridSize = 40f * scale
    val cols = (width / gridSize).toInt() + 2
    val rows = (height / gridSize).toInt() + 2
    
    val startX = -(panOffset.x * scale) % gridSize
    val startY = -(panOffset.y * scale) % gridSize
    
    for (i in 0..cols) {
        val x = startX + i * gridSize
        val alpha = 0.03f + 0.02f * kotlin.math.sin((x + panOffset.x) * 0.01)
        drawLine(
            color = Color.White.copy(alpha = alpha),
            start = androidx.compose.ui.geometry.Offset(x, 0f),
            end = androidx.compose.ui.geometry.Offset(x, height),
            strokeWidth = 0.5f
        )
    }
    
    for (i in 0..rows) {
        val y = startY + i * gridSize
        val alpha = 0.03f + 0.02f * kotlin.math.sin((y + panOffset.y) * 0.01)
        drawLine(
            color = Color.White.copy(alpha = alpha),
            start = androidx.compose.ui.geometry.Offset(0f, y),
            end = androidx.compose.ui.geometry.Offset(width, y),
            strokeWidth = 0.5f
        )
    }
}

@Composable
fun drawConnection(
    fromNode: FlowNode, toNode: FlowNode,
    fromOutput: Int, toInput: Int,
    panOffset: Position, scale: Float
) {
    val fromX = (fromNode.position.x + panOffset.x) * scale + fromNodeWidth(fromNode, scale) / 2
    val fromY = (fromNode.position.y + panOffset.y) * scale + outputPortY(fromNode, fromOutput, scale)
    val toX = (toNode.position.x + panOffset.x) * scale - toNodeWidth(toNode, scale) / 2
    val toY = (toNode.position.y + panOffset.y) * scale + inputPortY(toNode, toInput, scale)
    
    val path = Path().apply {
        moveTo(fromX, fromY)
        // Bezier curve
        val ctrlX1 = fromX + (toX - fromX) * 0.3f
        val ctrlY1 = fromY
        val ctrlX2 = toX - (toX - fromX) * 0.3f
        val ctrlY2 = toY
        cubicTo(ctrlX1, ctrlY1, ctrlX2, ctrlY2, toX, toY)
    }
    
    drawPath(
        path = path,
        color = Color(0x00D4FF).copy(alpha = 0.5f),
        style = androidx.compose.ui.graphics.drawscope.Stroke(
            width = 2f * scale,
            cap = androidx.compose.ui.graphics.StrokeCap.Round,
            pathEffect = PathEffect.makeDashPathEffect(floatArrayOf(8f, 4f) * scale, 0f)
        )
    )
    
    // Arrowhead
    val arrowSize = 8f * scale
    val angle = kotlin.math.atan2(toY - ctrlY2, toX - ctrlX2)
    val arrowPath = Path().apply {
        moveTo(toX, toY)
        lineTo(
            toX - arrowSize * kotlin.math.cos(angle - 0.5f),
            toY - arrowSize * kotlin.math.sin(angle - 0.5f)
        )
        moveTo(toX, toY)
        lineTo(
            toX - arrowSize * kotlin.math.cos(angle + 0.5f),
            toY - arrowSize * kotlin.math.sin(angle + 0.5f)
        )
    }
    drawPath(
        path = arrowPath,
        color = Color(0x00D4FF).copy(alpha = 0.7f),
        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f * scale)
    )
}

@Composable
fun drawPendingConnection(
    fromNode: FlowNode, fromOutput: Int,
    panOffset: Position, scale: Float
) {
    // This would draw a line from the output port to the current touch position
    // Implementation depends on touch position tracking
}

fun fromNodeWidth(node: FlowNode, scale: Float): Float = 140f * scale
fun toNodeWidth(node: FlowNode, scale: Float): Float = 140f * scale
fun outputPortY(node: FlowNode, outputIndex: Int, scale: Float): Float = (40 + outputIndex * 20).dp.toPx() * scale
fun inputPortY(node: FlowNode, inputIndex: Int, scale: Float): Float = (40 + inputIndex * 20).dp.toPx() * scale

data class FlowDefinition(
    val nodes: List<FlowNode> = emptyList(),
    val connections: List<Connection> = emptyList(),
    val name: String = "Untitled Flow",
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)