package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ColorMatrixColorFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.JarvisCoreEngine
import com.example.ui.components.HologramMode
import com.example.ui.components.HolographicConfig
import com.example.ui.components.HolographicProjector
import com.example.ui.components.HolographicRingProgress
import com.example.ui.components.HolographicWaveform
import com.example.ui.components.JarvisState
import com.example.ui.theme.JarvisAmber
import com.example.ui.theme.JarvisGreen
import com.example.ui.theme.JarvisObsidian
import com.example.ui.theme.JarvisRed
import com.example.ui.theme.JarvisTextMuted
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun HolographicChamberScreen(
    engine: JarvisCoreEngine,
    onDismiss: () -> Unit
) {
    val jarvisState by engine.jarvisState.collectAsState()
    val rmsAudio by engine.rmsAudioLevel.collectAsState()
    val config by engine.appearanceConfig.collectAsState()
    val context = LocalContext.current

    var currentMode by remember { mutableStateOf(HologramMode.IDLE) }
    var displayMessage by remember { mutableStateOf("") }
    var showControlPanel by remember { mutableStateOf(true) }
    var voiceCommandActive by remember { mutableStateOf(false) }
    var voiceCommandText by remember { mutableStateOf("") }
    
    val infiniteTransition = rememberInfiniteTransition(label = "hologram_ambient")
    val ambientPulse by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ambient_pulse"
    )
    
    val scanLineProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scan_line"
    )

    // Auto-transition modes based on Jarvis state
    LaunchedEffect(jarvisState) {
        currentMode = when (jarvisState) {
            JarvisState.LISTENING -> HologramMode.SCANNING
            JarvisState.PROCESSING -> HologramMode.PROCESSING
            JarvisState.SPEAKING -> HologramMode.COMMUNICATION
            JarvisState.ALERT -> HologramMode.ALERT
            else -> HologramMode.IDLE
        }
    }

    // Voice command listener for hologram-specific commands
    LaunchedEffect(engine.currentQueryInput) {
        val query = engine.currentQueryInput.value.lowercase()
        if (query.contains("hologram") || query.contains("holo") || query.contains("projection") || 
            query.contains("chamber") || query.contains("scan") || query.contains("project")) {
            when {
                query.contains("scan") || query.contains("scanning") -> {
                    currentMode = HologramMode.SCANNING
                    displayMessage = "DEEP SCAN INITIATED"
                }
                query.contains("project") || query.contains("projection") -> {
                    currentMode = HologramMode.PROJECTING
                    displayMessage = "HOLOGRAPHIC PROJECTION ACTIVE"
                }
                query.contains("alert") || query.contains("tactical") -> {
                    currentMode = HologramMode.ALERT
                    displayMessage = "TACTICAL ALERT ENGAGED"
                }
                query.contains("comm") || query.contains("channel") -> {
                    currentMode = HologramMode.COMMUNICATION
                    displayMessage = "SECURE CHANNEL ESTABLISHED"
                }
                query.contains("idle") || query.contains("standby") -> {
                    currentMode = HologramMode.IDLE
                    displayMessage = "STANDBY MODE"
                }
                query.contains("process") || query.contains("analyze") -> {
                    currentMode = HologramMode.PROCESSING
                    displayMessage = "PROCESSING DATA..."
                }
            }
        }
    }

    val hologramConfig = HolographicConfig(
        primaryColor = config.colorTheme.primaryColor,
        secondaryColor = config.colorTheme.secondaryColor,
        accentColor = config.colorTheme.accentColor,
        intensity = 1.0f,
        scanSpeed = 1.0f,
        particleCount = 100
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisObsidian)
            .clickable(onClick = { showControlPanel = !showControlPanel })
    ) {
        // Full-screen holographic projector with enhanced visuals
        HolographicProjector(
            modifier = Modifier.fillMaxSize(),
            mode = currentMode,
            config = hologramConfig
        )

        // Enhanced ambient grid overlay with scan line
        HolographicGridOverlay(
            modifier = Modifier.fillMaxSize(),
            pulseScale = ambientPulse,
            primaryColor = config.colorTheme.primaryColor,
            scanLineProgress = scanLineProgress
        )

        // Voice command indicator
        if (jarvisState == JarvisState.LISTENING) {
            VoiceCommandIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 100.dp, horizontal = 16.dp),
                config = config,
                rmsAudio = rmsAudio
            )
        }

        // Top status bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Mode indicator with pulsing animation
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(
                                when (currentMode) {
                                    HologramMode.IDLE -> config.colorTheme.primaryColor.copy(alpha = 0.5f)
                                    HologramMode.SCANNING -> config.colorTheme.accentColor
                                    HologramMode.PROCESSING -> JarvisAmber
                                    HologramMode.PROJECTING -> config.colorTheme.secondaryColor
                                    HologramMode.ALERT -> JarvisRed
                                    HologramMode.COMMUNICATION -> JarvisGreen
                                }
                            )
                            .animateScale(
                                targetValue = if (currentMode == HologramMode.SCANNING || currentMode == HologramMode.PROCESSING) 1.4f else 1f,
                                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
                            )
                    )
                    Column {
                        Text(
                            text = "HOLO-CHAMBER ACTIVE",
                            color = JarvisTextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            letterSpacing = 1.5.sp
                        )
                        Text(
                            text = "MODE: ${currentMode.name} • ${jarvisState.name}",
                            color = config.colorTheme.accentColor,
                            fontSize = 9.sp,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = { showControlPanel = !showControlPanel },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = if (showControlPanel) Icons.Default.Close else Icons.Default.Menu,
                            contentDescription = "Toggle Controls",
                            tint = JarvisTextSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Exit Holo-Chamber",
                            tint = JarvisRed,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }

        // Central holographic display area with voice feedback
        if (displayMessage.isNotBlank() || jarvisState == JarvisState.SPEAKING) {
            HolographicDisplayPanel(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp, vertical = 16.dp)
                    .align(Alignment.TopCenter),
                message = if (jarvisState == JarvisState.SPEAKING) engine.lastJarvisResponse.value else displayMessage,
                config = config,
                mode = currentMode,
                isSpeaking = jarvisState == JarvisState.SPEAKING
            )
        }

        // Control Panel (bottom)
        AnimatedVisibility(
            visible = showControlPanel,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 32.dp, horizontal = 16.dp)
                    .align(Alignment.BottomCenter)
            ) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xE00F1626)
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        Brush.horizontalGradient(
                            listOf(
                                Color.Transparent,
                                config.colorTheme.primaryColor.copy(alpha = 0.5f),
                                Color.Transparent
                            )
                        )
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Voice Commands Help
                        VoiceCommandHelp(
                            config = config,
                            currentMode = currentMode
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Audio Waveform
                        if (jarvisState == JarvisState.LISTENING || jarvisState == JarvisState.SPEAKING) {
                            HolographicWaveform(
                                modifier = Modifier.fillMaxWidth().height(80.dp),
                                audioLevel = rmsAudio,
                                config = hologramConfig
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                        }

                        // Progress Ring (when processing)
                        if (jarvisState == JarvisState.PROCESSING) {
                            HolographicRingProgress(
                                modifier = Modifier.size(100.dp),
                                progress = (System.currentTimeMillis() / 2000f) % 1f,
                                config = hologramConfig
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                        }

                        // Quick Actions with voice command hints
                        Text(
                            text = "VOICE COMMANDS",
                            color = config.colorTheme.accentColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            letterSpacing = 2.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            HoloActionChip(
                                label = "SCAN",
                                hint = "\"scan\"",
                                icon = Icons.Default.Search,
                                color = config.colorTheme.accentColor,
                                onClick = {
                                    currentMode = HologramMode.SCANNING
                                    displayMessage = "INITIATING DEEP SCAN..."
                                    engine.processUserQuery("run diagnostic scan")
                                }
                            )
                            HoloActionChip(
                                label = "PROJECT",
                                hint = "\"project\"",
                                icon = Icons.Default.PresentToAll,
                                color = config.colorTheme.secondaryColor,
                                onClick = {
                                    currentMode = HologramMode.PROJECTING
                                    displayMessage = "HOLOGRAPHIC PROJECTION ACTIVE"
                                    engine.processUserQuery("create presentation on AI")
                                }
                            )
                            HoloActionChip(
                                label = "ALERT",
                                hint = "\"alert\"",
                                icon = Icons.Default.Warning,
                                color = JarvisRed,
                                onClick = {
                                    currentMode = HologramMode.ALERT
                                    displayMessage = "TACTICAL ALERT ENGAGED"
                                    engine.processUserQuery("protocol perimeter defense")
                                }
                            )
                            HoloActionChip(
                                label = "COMMS",
                                hint = "\"channel\"",
                                icon = Icons.Default.Chat,
                                color = JarvisGreen,
                                onClick = {
                                    currentMode = HologramMode.COMMUNICATION
                                    displayMessage = "SECURE CHANNEL ESTABLISHED"
                                    engine.processUserQuery("open assistant screen")
                                }
                            )
                        }

                        // Display message
                        if (displayMessage.isNotBlank()) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(
                                                config.colorTheme.primaryColor.copy(alpha = 0.1f),
                                                config.colorTheme.accentColor.copy(alpha = 0.1f)
                                            )
                                        ),
                                        shape = RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Text(
                                    text = displayMessage,
                                    color = config.colorTheme.accentColor,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Floating particles overlay
        FloatingHolographicParticles(
            modifier = Modifier.fillMaxSize(),
            color = config.colorTheme.primaryColor,
            count = 50
        )
    }
}

@Composable
fun VoiceCommandIndicator(
    modifier: Modifier,
    config: com.example.data.repository.AssistantAppearanceConfig,
    rmsAudio: Float
) {
    val infiniteTransition = rememberInfiniteTransition(label = "voice_indicator")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "voice_pulse"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp)
            .height(80.dp)
            .align(Alignment.TopCenter)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            config.colorTheme.primaryColor.copy(alpha = 0.05f),
                            config.colorTheme.accentColor.copy(alpha = 0.1f),
                            config.colorTheme.primaryColor.copy(alpha = 0.05f)
                        )
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
                .border(
                    1.5.dp,
                    Brush.horizontalGradient(
                        listOf(
                            config.colorTheme.primaryColor.copy(alpha = 0.3f),
                            config.colorTheme.accentColor.copy(alpha = 0.5f),
                            config.colorTheme.primaryColor.copy(alpha = 0.3f)
                        )
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(config.colorTheme.accentColor)
                            .graphicsLayer { scaleX = pulseScale; scaleY = pulseScale }
                    )
                    Text(
                        text = "LISTENING...",
                        color = config.colorTheme.accentColor,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "Say: \"hologram scan\", \"hologram project\", \"hologram alert\"",
                        color = JarvisTextMuted,
                        fontSize = 10.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                    )
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Audio level bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    androidx.compose.foundation.Canvas(
                        modifier = Modifier.fillMaxWidth().height(8.dp).padding(horizontal = 32.dp)
                    ) {
                        val barWidth = size.width / 20f
                        for (i in 0..19) {
                            val normalized = (i + 1) / 20f
                            val height = (size.height * 0.2f + size.height * 0.8f * rmsAudio * (1f + normalized * 0.5f))
                            val color = when {
                                normalized < 0.33f -> config.colorTheme.primaryColor
                                normalized < 0.66f -> config.colorTheme.accentColor
                                else -> config.colorTheme.secondaryColor
                            }
                            drawRect(
                                color = color.copy(alpha = 0.5f + 0.5f * rmsAudio),
                                topLeft = androidx.compose.ui.geometry.Offset(i * barWidth + 2f, size.height - height),
                                size = androidx.compose.ui.geometry.Size(barWidth - 4f, height)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HolographicDisplayPanel(
    modifier: Modifier,
    message: String,
    config: com.example.data.repository.AssistantAppearanceConfig,
    mode: HologramMode,
    isSpeaking: Boolean
) {
    val infiniteTransition = rememberInfiniteTransition(label = "display_panel")
    val pulseAlpha = if (isSpeaking) {
        infiniteTransition.animateFloat(
            initialValue = 0.5f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(500, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "speak_pulse"
        ).value
    } else 1f

    AnimatedVisibility(
        visible = message.isNotBlank(),
        enter = fadeIn(tween(300)) + slideInVertically(),
        exit = fadeOut(tween(200)) + slideOutVertically()
    ) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(120.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(
                            config.colorTheme.primaryColor.copy(alpha = 0.08f * pulseAlpha),
                            config.colorTheme.secondaryColor.copy(alpha = 0.05f * pulseAlpha)
                        )
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
                .border(
                    2.dp,
                    Brush.horizontalGradient(
                        listOf(
                            config.colorTheme.primaryColor.copy(alpha = 0.3f * pulseAlpha),
                            config.colorTheme.accentColor.copy(alpha = 0.6f * pulseAlpha),
                            config.colorTheme.primaryColor.copy(alpha = 0.3f * pulseAlpha)
                        )
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Mode indicator
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(
                                when (mode) {
                                    HologramMode.IDLE -> config.colorTheme.primaryColor.copy(alpha = 0.5f)
                                    HologramMode.SCANNING -> config.colorTheme.accentColor
                                    HologramMode.PROCESSING -> JarvisAmber
                                    HologramMode.PROJECTING -> config.colorTheme.secondaryColor
                                    HologramMode.ALERT -> JarvisRed
                                    HologramMode.COMMUNICATION -> JarvisGreen
                                }
                            )
                    )
                    Text(
                        text = mode.name.uppercase(),
                        color = config.colorTheme.accentColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        letterSpacing = 1.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Message with typewriter effect feel
                Text(
                    text = message,
                    color = JarvisTextPrimary.copy(alpha = pulseAlpha),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    textAlign = TextAlign.Center,
                    maxLines = 3,
                    overflow = androidx.compose.ui.text.TextOverflow.Ellipsis,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp)
                )
            }
        }
    }
}

@Composable
fun VoiceCommandHelp(
    config: com.example.data.repository.AssistantAppearanceConfig,
    currentMode: HologramMode
) {
    val commands = when (currentMode) {
        HologramMode.IDLE -> listOf(
            "Say \"hologram scan\" to start deep scan",
            "Say \"hologram project\" for projections",
            "Say \"hologram alert\" for tactical mode",
            "Say \"hologram channel\" for comms"
        )
        HologramMode.SCANNING -> listOf(
            "Scanning environment...",
            "Say \"hologram project\" to project results",
            "Say \"hologram idle\" to stop scan"
        )
        HologramMode.PROJECTING -> listOf(
            "Projection active",
            "Say \"hologram scan\" to analyze",
            "Say \"hologram idle\" to stop"
        )
        HologramMode.ALERT -> listOf(
            "⚠ TACTICAL ALERT ⚠",
            "Say \"hologram idle\" to disengage",
            "Say \"hologram comms\" for secure channel"
        )
        HologramMode.COMMUNICATION -> listOf(
            "Secure channel open",
            "Say \"hologram scan\" for recon",
            "Say \"hologram idle\" to close"
        )
        HologramMode.PROCESSING -> listOf(
            "Processing data...",
            "Results will project automatically",
            "Say \"hologram idle\" to cancel"
        )
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = "VOICE COMMANDS",
            color = config.colorTheme.accentColor,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
            letterSpacing = 1.5.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            commands.forEach { cmd ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "▸ $cmd",
                        color = JarvisTextSecondary,
                        fontSize = 10.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
private fun HologramModeChip(
    mode: HologramMode,
    isSelected: Boolean,
    config: HolographicConfig,
    onClick: () -> Unit
) {
    val colors = when (mode) {
        HologramMode.IDLE -> config.primaryColor
        HologramMode.SCANNING -> config.accentColor
        HologramMode.PROCESSING -> JarvisAmber
        HologramMode.PROJECTING -> config.secondaryColor
        HologramMode.ALERT -> JarvisRed
        HologramMode.COMMUNICATION -> JarvisGreen
    }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) colors.copy(alpha = 0.2f) else Color(0x1AFFFFFF),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) colors else Color(0x33FFFFFF)
        ),
        modifier = Modifier
            .weight(1f)
            .height(56.dp)
            .fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = mode.name.uppercase(),
                color = if (isSelected) colors else JarvisTextSecondary,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) colors else colors.copy(alpha = 0.3f))
            )
        }
    }
}

@Composable
private fun HoloActionChip(
    label: String,
    hint: String,
    icon: androidx.compose.material.icons.Icons.Default,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = color.copy(alpha = 0.15f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.5f)),
        modifier = Modifier
            .weight(1f)
            .height(64.dp)
            .fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                color = color,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Text(
                text = hint,
                color = color.copy(alpha = 0.5f),
                fontSize = 8.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
            )
        }
    }
}

@Composable
fun HolographicGridOverlay(
    modifier: Modifier,
    pulseScale: Float,
    primaryColor: Color,
    scanLineProgress: Float
) {
    Canvas(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(0.dp))
    ) {
        val gridSize = 40f
        val cols = (size.width / gridSize).toInt() + 1
        val rows = (size.height / gridSize).toInt() + 1

        // Vertical lines
        for (i in 0..cols) {
            val x = i * gridSize
            val alpha = (0.02f + 0.015f * kotlin.math.sin(System.currentTimeMillis() / 1000f + i * 0.5f)) * pulseScale
            drawLine(
                color = primaryColor.copy(alpha = alpha),
                start = androidx.compose.ui.geometry.Offset(x, 0f),
                end = androidx.compose.ui.geometry.Offset(x, size.height),
                strokeWidth = 0.5f
            )
        }

        // Horizontal lines
        for (i in 0..rows) {
            val y = i * gridSize
            val alpha = (0.02f + 0.015f * kotlin.math.sin(System.currentTimeMillis() / 1200f + i * 0.3f)) * pulseScale
            drawLine(
                color = primaryColor.copy(alpha = alpha),
                start = androidx.compose.ui.geometry.Offset(0f, y),
                end = androidx.compose.ui.geometry.Offset(size.width, y),
                strokeWidth = 0.5f
            )
        }

        // Central crosshair with pulsing
        val centerX = size.width / 2f
        val centerY = size.height / 2f
        val crosshairSize = 80f * pulseScale
        drawLine(
            color = primaryColor.copy(alpha = 0.1f * pulseScale),
            start = androidx.compose.ui.geometry.Offset(centerX - crosshairSize, centerY),
            end = androidx.compose.ui.geometry.Offset(centerX + crosshairSize, centerY),
            strokeWidth = 1f
        )
        drawLine(
            color = primaryColor.copy(alpha = 0.1f * pulseScale),
            start = androidx.compose.ui.geometry.Offset(centerX, centerY - crosshairSize),
            end = androidx.compose.ui.geometry.Offset(centerX, centerY + crosshairSize),
            strokeWidth = 1f
        )

        // Scanning line
        val scanY = centerY - crosshairSize + 2 * crosshairSize * scanLineProgress
        val scanAlpha = 1f - kotlin.math.abs(scanLineProgress - 0.5f) * 1.5f
        
        drawLine(
            color = primaryColor.copy(alpha = 0.6f * scanAlpha),
            start = androidx.compose.ui.geometry.Offset(centerX - crosshairSize, scanY),
            end = androidx.compose.ui.geometry.Offset(centerX + crosshairSize, scanY),
            strokeWidth = 2f
        )
        
        // Scan glow
        val glowPath = androidx.compose.ui.graphics.Path().apply {
            moveTo(centerX - crosshairSize, scanY - 15f)
            lineTo(centerX + crosshairSize, scanY - 15f)
            lineTo(centerX + crosshairSize, scanY + 15f)
            lineTo(centerX - crosshairSize, scanY + 15f)
            close()
        }
        drawPath(
            path = glowPath,
            color = primaryColor.copy(alpha = 0.08f * scanAlpha),
            style = androidx.compose.ui.graphics.drawscope.Fill
        )

        // Corner markers
        val markerSize = 50f
        val markerPositions = listOf(
            Pair(markerSize, markerSize), // TL
            Pair(size.width - markerSize, markerSize), // TR
            Pair(markerSize, size.height - markerSize), // BL
            Pair(size.width - markerSize, size.height - markerSize) // BR
        )
        for ((mx, my) in markerPositions) {
            val isLeft = mx < centerX
            val isTop = my < centerY
            val bracketPath = androidx.compose.ui.graphics.Path().apply {
                if (isLeft && isTop) {
                    moveTo(mx, my + markerSize)
                    lineTo(mx, my)
                    lineTo(mx + markerSize, my)
                } else if (!isLeft && isTop) {
                    moveTo(mx - markerSize, my)
                    lineTo(mx, my)
                    lineTo(mx, my + markerSize)
                } else if (isLeft && !isTop) {
                    moveTo(mx, my - markerSize)
                    lineTo(mx, my)
                    lineTo(mx + markerSize, my)
                } else {
                    moveTo(mx, my - markerSize)
                    lineTo(mx, my)
                    lineTo(mx - markerSize, my)
                }
            }
            drawPath(
                path = bracketPath,
                color = primaryColor.copy(alpha = 0.15f * pulseScale),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
            )
        }
    }
}

@Composable
fun FloatingHolographicParticles(
    modifier: Modifier,
    color: Color,
    count: Int = 30
) {
    val particles = remember {
        (1..count).map { _ ->
            Particle(
                x = Math.random().toFloat(),
                y = Math.random().toFloat(),
                vx = (Math.random().toFloat() - 0.5f) * 0.0003f,
                vy = (Math.random().toFloat() - 0.5f) * 0.0003f,
                size = (Math.random().toFloat() * 3f + 1f),
                alpha = (Math.random().toFloat() * 0.15f + 0.03f),
                color = color
            )
        }
    }
    
    val infiniteTransition = rememberInfiniteTransition(label = "particles")
    val _ = infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(16, easing = { it }),
            repeatMode = RepeatMode.Restart
        )
    )
    
    Canvas(modifier = modifier.fillMaxSize()) {
        for (particle in particles) {
            particle.x += particle.vx
            particle.y += particle.vy
            
            if (particle.x < 0) particle.x = 1f
            if (particle.x > 1) particle.x = 0f
            if (particle.y < 0) particle.y = 1f
            if (particle.y > 1) particle.y = 0f
            
            val x = particle.x * size.width
            val y = particle.y * size.height
            val radius = particle.size.dp.toPx()
            
            drawCircle(
                color = particle.color.copy(alpha = particle.alpha),
                center = androidx.compose.ui.geometry.Offset(x, y),
                radius = radius
            )
        }
    }
}

data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val size: Float,
    val alpha: Float,
    val color: Color
)

@OptIn(androidx.compose.animation.ExperimentalAnimationApi::class)
@Composable
fun HolographicTransitionScreen(
    engine: JarvisCoreEngine,
    onComplete: () -> Unit,
    message: String = "INITIALIZING HOLO-MATRIX..."
) {
    val progress by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(3000, easing = FastOutSlowInEasing)
    )

    LaunchedEffect(Unit) {
        delay(3500)
        onComplete()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisObsidian)
    ) {
        HolographicGridOverlay(
            modifier = Modifier.fillMaxSize(),
            pulseScale = 1f,
            primaryColor = engine.appearanceConfig.value.colorTheme.primaryColor,
            scanLineProgress = progress
        )

        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            HolographicRingProgress(
                modifier = Modifier.size(160.dp),
                progress = progress,
                config = HolographicConfig(
                    primaryColor = engine.appearanceConfig.value.colorTheme.primaryColor,
                    secondaryColor = engine.appearanceConfig.value.colorTheme.secondaryColor,
                    accentColor = engine.appearanceConfig.value.colorTheme.accentColor
                )
            )

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = message,
                color = engine.appearanceConfig.value.colorTheme.accentColor,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                letterSpacing = 3.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "${(progress * 100).toInt()}%",
                color = JarvisTextSecondary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
            )
        }
    }
}

import androidx.compose.animation.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.rememberInfiniteTransition