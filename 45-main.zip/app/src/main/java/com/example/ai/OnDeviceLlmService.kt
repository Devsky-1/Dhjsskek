package com.example.ai

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

enum class LlmModel(
    val modelName: String,
    val modelUrl: String,
    val sizeMb: Int,
    val description: String
) {
    GEMMA_2B("gemma-2b-it-gpu-int4.bin",
        "https://storage.googleapis.com/mediapipe-models/llm/gemma_2b/gpu/int4/gemma-2b-it-gpu-int4.bin",
        1200, "Google Gemma 2B - Fast, efficient"),
    PHI_2("phi-2-gpu-int4.bin",
        "https://storage.googleapis.com/mediapipe-models/llm/phi_2/gpu/int4/phi-2-gpu-int4.bin",
        1600, "Microsoft Phi-2 - Strong reasoning"),
    FALCON_RW_1B("falcon-rw-1b-gpu-int4.bin",
        "https://storage.googleapis.com/mediapipe-models/llm/falcon_rw_1b/gpu/int4/falcon-rw-1b-gpu-int4.bin",
        800, "Falcon RW 1B - Lightweight"),
    STABLELM_3B("stablelm-3b-gpu-int4.bin",
        "https://storage.googleapis.com/mediapipe-models/llm/stablelm_3b/gpu/int4/stablelm-3b-gpu-int4.bin",
        1800, "StableLM 3B - Balanced performance")
}

enum class LlmState {
    UNINITIALIZED, DOWNLOADING, LOADING, READY, GENERATING, ERROR
}

class OnDeviceLlmService @Inject constructor(
    private val context: Context
) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var llmInference: LlmInference? = null
    private var currentModel: LlmModel = LlmModel.GEMMA_2B

    private val _state = MutableStateFlow(LlmState.UNINITIALIZED)
    val state: StateFlow<LlmState> = _state.asStateFlow()

    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _currentResponse = MutableStateFlow<String>("")
    val currentResponse: StateFlow<String> = _currentResponse.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    init {
        initializeDefaultModel()
    }

    private fun initializeDefaultModel() {
        scope.launch {
            try {
                val modelFile = getModelFile(currentModel)
                if (!modelFile.exists()) {
                    downloadModel(currentModel)
                } else {
                    loadModel(modelFile)
                }
            } catch (e: Exception) {
                Log.e("OnDeviceLlmService", "Init failed", e)
                _state.value = LlmState.ERROR
                _error.value = e.message
            }
        }
    }

    private fun getModelFile(model: LlmModel): File {
        return File(context.filesDir, "models/${model.modelName}")
    }

    fun switchModel(model: LlmModel) {
        if (model == currentModel && llmInference != null) return
        currentModel = model
        scope.launch {
            try {
                val modelFile = getModelFile(model)
                if (!modelFile.exists()) {
                    downloadModel(model)
                } else {
                    loadModel(modelFile)
                }
            } catch (e: Exception) {
                Log.e("OnDeviceLlmService", "Switch model failed", e)
                _state.value = LlmState.ERROR
                _error.value = e.message
            }
        }
    }

    private fun downloadModel(model: LlmModel) {
        _state.value = LlmState.DOWNLOADING
        _progress.value = 0f
        _error.value = null

        scope.launch {
            try {
                val modelFile = getModelFile(model)
                modelFile.parentFile?.mkdirs()

                val url = java.net.URL(model.modelUrl)
                val connection = url.openConnection()
                connection.connect()

                val fileSize = connection.contentLengthLong()
                val input = connection.getInputStream()
                val output = FileOutputStream(modelFile)

                val buffer = ByteArray(8192)
                var downloaded = 0L
                var len: Int
                while (input.read(buffer).also { len = it } != -1) {
                    output.write(buffer, 0, len)
                    downloaded += len
                    if (fileSize > 0) {
                        _progress.value = downloaded.toFloat() / fileSize.toFloat()
                    }
                }
                output.flush()
                output.close()
                input.close()

                _progress.value = 1f
                loadModel(modelFile)

            } catch (e: Exception) {
                Log.e("OnDeviceLlmService", "Download failed", e)
                _state.value = LlmState.ERROR
                _error.value = "Download failed: ${e.message}"
            }
        }
    }

    private fun loadModel(modelFile: File) {
        _state.value = LlmState.LOADING
        _progress.value = 0f

        scope.launch {
            try {
                val options = LlmInferenceOptions.builder()
                    .setModelPath(modelFile.absolutePath)
                    .setMaxTokens(2048)
                    .setTopK(40)
                    .setTemperature(0.7f)
                    .setRandomSeed(42)
                    .build()

                llmInference = LlmInference.createFromOptions(context, options)
                _state.value = LlmState.READY
                _progress.value = 1f
                _error.value = null
                Log.d("OnDeviceLlmService", "Model loaded: ${currentModel.modelName}")

            } catch (e: Exception) {
                Log.e("OnDeviceLlmService", "Load failed", e)
                _state.value = LlmState.ERROR
                _error.value = "Load failed: ${e.message}"
            }
        }
    }

    fun generateResponse(
        prompt: String,
        systemPrompt: String = "You are JARVIS, a helpful AI assistant. Be concise and professional.",
        onToken: ((String) -> Unit)? = null,
        onComplete: ((String) -> Unit)? = null
    ) {
        if (_state.value != LlmState.READY || llmInference == null) {
            _error.value = "Model not ready"
            onComplete?.invoke("Model not ready. Please wait for initialization.")
            return
        }

        _state.value = LlmState.GENERATING
        _isGenerating.value = true
        _currentResponse.value = ""

        scope.launch {
            try {
                val fullPrompt = "<start_of_turn>system\n$systemPrompt<end_of_turn>\n<start_of_turn>user\n$prompt<end_of_turn>\n<start_of_turn>model\n"
                
                val response = llmInference?.generateResponse(fullPrompt)
                
                if (response != null) {
                    _currentResponse.value = response
                    onToken?.invoke(response)
                    onComplete?.invoke(response)
                } else {
                    onComplete?.invoke("No response generated")
                }
                
                _state.value = LlmState.READY
                _isGenerating.value = false
                
            } catch (e: Exception) {
                Log.e("OnDeviceLlmService", "Generation failed", e)
                _state.value = LlmState.ERROR
                _isGenerating.value = false
                _error.value = "Generation failed: ${e.message}"
                onComplete?.invoke("Error: ${e.message}")
            }
        }
    }

    fun generateStreamingResponse(
        prompt: String,
        systemPrompt: String = "You are JARVIS, a helpful AI assistant. Be concise and professional.",
        onToken: (String) -> Unit,
        onComplete: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        if (_state.value != LlmState.READY || llmInference == null) {
            onError("Model not ready")
            return
        }

        _state.value = LlmState.GENERATING
        _isGenerating.value = true
        _currentResponse.value = ""

        scope.launch {
            try {
                val fullPrompt = "<start_of_turn>system\n$systemPrompt<end_of_turn>\n<start_of_turn>user\n$prompt<end_of_turn>\n<start_of_turn>model\n"
                
                // MediaPipe LLM Inference doesn't support streaming yet, so we simulate it
                val response = llmInference?.generateResponse(fullPrompt) ?: ""
                
                // Simulate streaming by chunking the response
                val words = response.split(" ")
                var accumulated = ""
                for (word in words) {
                    accumulated += "$word "
                    _currentResponse.value = accumulated
                    onToken(accumulated)
                    Thread.sleep(50) // Simulate streaming delay
                }
                
                onComplete(accumulated.trim())
                _state.value = LlmState.READY
                _isGenerating.value = false
                
            } catch (e: Exception) {
                Log.e("OnDeviceLlmService", "Streaming failed", e)
                _state.value = LlmState.ERROR
                _isGenerating.value = false
                _error.value = "Streaming failed: ${e.message}"
                onError(e.message ?: "Unknown error")
            }
        }
    }

    fun stopGeneration() {
        _isGenerating.value = false
        _state.value = LlmState.READY
    }

    fun getAvailableModels(): List<LlmModel> = LlmModel.values().toList()

    fun getCurrentModel(): LlmModel = currentModel

    fun isModelDownloaded(model: LlmModel): Boolean = getModelFile(model).exists()

    fun deleteModel(model: LlmModel) {
        getModelFile(model).delete()
    }

    fun getModelSize(model: LlmModel): String = "${model.sizeMb} MB"

    companion object {
        private const val TAG = "OnDeviceLlmService"
    }
}