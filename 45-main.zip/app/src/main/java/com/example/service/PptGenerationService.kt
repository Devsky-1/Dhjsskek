package com.example.service

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.util.Log
import org.apache.poi.xslf.usermodel.XMLSlideShow
import org.apache.poi.xslf.usermodel.XSLFSlide
import org.apache.poi.xslf.usermodel.XSLFTextShape
import org.apache.poi.xslf.usermodel.XSLFTextParagraph
import org.apache.poi.xslf.usermodel.XSLFTextRun
import org.apache.poi.xslf.usermodel.XSLFShape
import org.apache.poi.sl.usermodel.TextAlign
import org.apache.poi.sl.usermodel.VerticalAlignment
import org.apache.poi.util.Units
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class PptGenerationService(private val context: Context) {

    companion object {
        private const val TAG = "PptGenerationService"
        
        // JARVIS Theme Colors
        val JARVIS_DARK = java.awt.Color(0x0F, 0x16, 0x26)
        val JARVIS_DARKER = java.awt.Color(0x07, 0x0B, 0x14)
        val JARVIS_CYAN = java.awt.Color(0x00, 0xD4, 0xFF)
        val JARVIS_TEAL = java.awt.Color(0x00, 0xFF, 0x88)
        val JARVIS_AMBER = java.awt.Color(0xFF, 0x6B, 0x35)
        val JARVIS_WHITE = java.awt.Color(0xE0, 0xE0, 0xE0)
        val JARVIS_GRAY = java.awt.Color(0x88, 0x88, 0x88)
        val JARVIS_LIGHT_GRAY = java.awt.Color(0x44, 0x44, 0x44)
    }

    interface PptGenerationCallback {
        fun onSuccess(filePath: String, fileName: String)
        fun onError(error: String)
    }

    enum class PptTemplate(
        val name: String,
        val description: String
    ) {
        JARVIS_CLASSIC("JARVIS Classic", "Dark theme with cyan accents - default"),
        STARK_INDUSTRIES("Stark Industries", "Corporate style with gold accents"),
        TACTICAL_HUD("Tactical HUD", "High contrast for presentations"),
        MINIMAL_LIGHT("Minimal Light", "Clean light theme"),
        HOLOGRAPHIC("Holographic", "Futuristic with glow effects")
    }

    enum class SlideLayout {
        TITLE, CONTENT, TWO_COLUMN, IMAGE_LEFT, IMAGE_RIGHT, 
        QUOTE, CODE, DIAGRAM, TIMELINE, COMPARISON, 
        STATS, PROCESS, CLOSING
    }

    fun generatePpt(
        title: String,
        slides: List<PptSlideData>,
        template: PptTemplate = PptTemplate.JARVIS_CLASSIC,
        callback: PptGenerationCallback
    ) {
        thread {
            try {
                val ppt = XMLSlideShow()
                val pageSize = ppt.pageSize

                // Create slides based on template
                createTitleSlide(ppt, title, pageSize, template)

                for (slideData in slides) {
                    createSlideByLayout(ppt, slideData, pageSize, template)
                }

                val fileName = "JARVIS_${template.name}_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.pptx"
                val file = getOutputFile(fileName)

                FileOutputStream(file).use { outputStream ->
                    ppt.write(outputStream)
                }

                ppt.close()

                callback.onSuccess(file.absolutePath, fileName)
                Log.d(TAG, "PPT generated successfully: ${file.absolutePath}")

            } catch (e: Exception) {
                Log.e(TAG, "Error generating PPT", e)
                callback.onError("Failed to generate PPT: ${e.message}")
            }
        }
    }

    fun generatePptFromTopic(
        topic: String,
        slideCount: Int = 10,
        template: PptTemplate = PptTemplate.JARVIS_CLASSIC,
        callback: PptGenerationCallback
    ) {
        thread {
            try {
                val slides = generateSlidesFromTopic(topic, slideCount, template)
                generatePpt(topic, slides, template, callback)
            } catch (e: Exception) {
                Log.e(TAG, "Error generating PPT from topic", e)
                callback.onError("Failed to generate PPT: ${e.message}")
            }
        }
    }

    fun generatePptFromVoiceCommand(
        voiceCommand: String,
        callback: PptGenerationCallback
    ) {
        // Parse voice command for topic, template, slide count
        val (topic, template, slideCount) = parseVoiceCommand(voiceCommand)
        generatePptFromTopic(topic, slideCount, template, callback)
    }

    private fun parseVoiceCommand(command: String): Triple<String, PptTemplate, Int> {
        val text = command.lowercase()
        var topic = "General Topic"
        var template = PptTemplate.JARVIS_CLASSIC
        var slideCount = 10

        // Extract topic
        val topicPatterns = listOf(
            Regex("(?i)(?:on|about|for)\\s+(.+)"),
            Regex("(?i)(?:ppt|presentation|slides?)\\s+(?:on|about|for)\\s+(.+)"),
            Regex("(?i)(?:create|make|generate)\\s+(?:a\\s+)?(?:ppt|presentation|slides?)\\s+(?:on|about|for)\\s+(.+)")
        )
        for (pattern in topicPatterns) {
            val match = pattern.find(text)
            if (match != null) {
                topic = match.groupValues[1].trim().capitalize()
                break
            }
        }

        // Extract template
        if (text.contains("stark") || text.contains("industries")) template = PptTemplate.STARK_INDUSTRIES
        else if (text.contains("tactical") || text.contains("hud")) template = PptTemplate.TACTICAL_HUD
        else if (text.contains("minimal") || text.contains("light")) template = PptTemplate.MINIMAL_LIGHT
        else if (text.contains("hologram") || text.contains("holo")) template = PptTemplate.HOLOGRAPHIC

        // Extract slide count
        val countPattern = Regex("(?i)(\\d+)\\s*(?:slides?|pages?)")
        val countMatch = countPattern.find(text)
        if (countMatch != null) {
            slideCount = countMatch.groupValues[1].toIntOrNull() ?: 10
        }

        return Triple(topic, template, slideCount.coerceIn(3, 20))
    }

    private fun generateSlidesFromTopic(topic: String, count: Int, template: PptTemplate): List<PptSlideData> {
        val slides = mutableListOf<PptSlideData>()
        val slideCount = count.coerceIn(3, 20)

        // Title slide
        slides.add(PptSlideData(
            title = topic,
            layout = SlideLayout.TITLE,
            bulletPoints = listOf(
                "Presented by J.A.R.V.I.S.",
                SimpleDateFormat("MMMM d, yyyy", Locale.getDefault()).format(Date()),
                "Template: ${template.description}"
            )
        ))

        // Agenda slide
        slides.add(PptSlideData(
            title = "Agenda",
            layout = SlideLayout.CONTENT,
            bulletPoints = listOf(
                "Overview & Introduction",
                "Core Concepts & Fundamentals",
                "Deep Dive: Key Areas",
                "Case Studies & Applications",
                "Future Outlook & Trends",
                "Conclusion & Next Steps"
            ).take(slideCount - 2)
        ))

        // Generate content slides based on topic
        val contentTopics = getTopicSpecificContent(topic)
        
        for (i in 0 until min(slideCount - 3, contentTopics.size)) {
            val layout = when (i % 6) {
                0 -> SlideLayout.CONTENT
                1 -> SlideLayout.TWO_COLUMN
                2 -> SlideLayout.PROCESS
                3 -> SlideLayout.COMPARISON
                4 -> SlideLayout.STATS
                else -> SlideLayout.TIMELINE
            }
            
            slides.add(PptSlideData(
                title = contentTopics[i].title,
                layout = layout,
                bulletPoints = contentTopics[i].points,
                secondaryPoints = contentTopics[i].secondaryPoints
            ))
        }

        // Stats/Key Metrics slide
        if (slideCount > 5) {
            slides.add(PptSlideData(
                title = "Key Metrics",
                layout = SlideLayout.STATS,
                bulletPoints = listOf(
                    "Performance: 99.9% uptime",
                    "Accuracy: 94.7% precision",
                    "Latency: <50ms response",
                    "Scalability: 10K+ concurrent",
                    "Security: AES-256 encryption",
                    "Compliance: SOC2, GDPR ready"
                )
            ))
        }

        // Timeline/Roadmap slide
        slides.add(PptSlideData(
            title = "Roadmap & Future",
            layout = SlideLayout.TIMELINE,
            bulletPoints = listOf(
                "Q1: Core features & stabilization",
                "Q2: Advanced AI integration",
                "Q3: Multi-platform deployment",
                "Q4: Enterprise features & scaling",
                "Next Year: AI-first architecture"
            )
        ))

        // Closing slide
        slides.add(PptSlideData(
            title = "Thank You",
            layout = SlideLayout.CLOSING,
            bulletPoints = listOf(
                "Questions & Discussion",
                "Contact: JARVIS@starkindustries.com",
                "GitHub: github.com/jarvis-ai",
                "Documentation: docs.jarvis.ai",
                "Generated by J.A.R.V.I.S. v1.0"
            )
        ))

        return slides
    }

    private fun getTopicSpecificContent(topic: String): List<TopicContent> {
        val lowerTopic = topic.lowercase()
        
        return when {
            lowerTopic.contains("ai") || lowerTopic.contains("artificial intelligence") || lowerTopic.contains("machine learning") -> listOf(
                TopicContent("What is Artificial Intelligence?", SlideLayout.CONTENT,
                    listOf("Definition & Core Concepts", "Narrow vs General AI", "Key Milestones", "Current State of AI"),
                    listOf("Symbolic AI (1950s-80s)", "Machine Learning (1990s-2010s)", "Deep Learning (2010s-present)", "Foundation Models (2020s+)"))
                TopicContent("Machine Learning Fundamentals", SlideLayout.PROCESS,
                    listOf("Supervised Learning", "Unsupervised Learning", "Reinforcement Learning", "Self-Supervised Learning"),
                    listOf("Classification & Regression", "Clustering & Dimensionality", "Agents & Environments", "Contrastive Learning"))
                TopicContent("Deep Learning & Neural Networks", SlideLayout.DIAGRAM,
                    listOf("Perceptrons & MLPs", "CNNs for Vision", "RNNs/LSTMs for Sequence", "Transformers & Attention"),
                    listOf("Feedforward Networks", "Convolutional Layers", "Recurrent Connections", "Self-Attention Mechanism"))
                TopicContent("Generative AI & LLMs", SlideLayout.TWO_COLUMN,
                    listOf("GPT Architecture", "Training Pipeline", "Fine-tuning Methods", "RLHF & Alignment"),
                    listOf("Transformer Decoder", "Pre-training + Fine-tune", "LoRA / Adapters", "Human Feedback"))
                TopicContent("AI Applications", SlideLayout.COMPARISON,
                    listOf("Natural Language Processing", "Computer Vision", "Robotics & Control", "Scientific Discovery"),
                    listOf("Chatbots, Translation", "Detection, Segmentation", "Autonomous Systems", "Drug Discovery, Materials"))
                TopicContent("AI Ethics & Safety", SlideLayout.CONTENT,
                    listOf("Bias & Fairness", "Privacy & Security", "Transparency", "Alignment Problem"),
                    listOf("Dataset Auditing", "Federated Learning", "Explainable AI", "Value Alignment"))
                TopicContent("AI in Enterprise", SlideLayout.STATS,
                    listOf("Automation ROI: 300%+", "Decision Speed: 10x faster", "Cost Reduction: 40-60%", "Innovation Index: 2.5x"),
                    listOf("Process Automation", "Predictive Analytics", "Customer Intelligence", "R&D Acceleration"))
                TopicContent("Future of AI", SlideLayout.TIMELINE,
                    listOf("2024: Multimodal Models", "2025: Agentic AI Systems", "2026: Embodied Intelligence", "2027+: AGI Milestones"),
                    listOf("GPT-5 / Gemini 2", "AutoGPT / BabyAGI", "Robotics Integration", "Scientific Reasoning"))
            )
            lowerTopic.contains("android") || lowerTopic.contains("mobile") || lowerTopic.contains("kotlin") -> listOf(
                TopicContent("Modern Android Development", SlideLayout.CONTENT,
                    listOf("Jetpack Compose", "Kotlin Coroutines", "Flow & LiveData", "Hilt/Dagger DI"),
                    listOf("Declarative UI", "Structured Concurrency", "Reactive Streams", "Dependency Injection"))
                TopicContent("Architecture Patterns", SlideLayout.COMPARISON,
                    listOf("MVVM", "MVI", "Clean Architecture", "Modular Architecture"),
                    listOf("ViewModel + State", "Unidirectional Flow", "Separation of Concerns", "Feature Modules"))
                TopicContent("Performance & Optimization", SlideLayout.STATS,
                    listOf("Startup Time: <500ms", "Frame Drops: <1%", "Memory: <150MB", "APK Size: <20MB"),
                    listOf("Baseline Profiles", "Recomposition", "Image Loading", "Code Shrinking"))
                TopicContent("Testing Strategies", SlideLayout.PROCESS,
                    listOf("Unit Tests", "Integration Tests", "UI Tests", "E2E Tests"),
                    listOf("JUnit + MockK", "Compose Testing", "Espresso/Compose", "Firebase Test Lab"))
            )
            lowerTopic.contains("jarvis") || lowerTopic.contains("assistant") || lowerTopic.contains("voice") -> listOf(
                TopicContent("Voice-First Architecture", SlideLayout.CONTENT,
                    listOf("Wake Word Detection", "Speech Recognition", "Natural Language Understanding", "Text-to-Speech"),
                    listOf("On-device Processing", "Streaming ASR", "Intent Classification", "Neural TTS"))
                TopicContent("Multimodal Interaction", SlideLayout.TWO_COLUMN,
                    listOf("Voice Commands", "Gesture Control", "Eye Tracking", "Holographic UI"),
                    listOf("Natural Language", "Hand Tracking", "Gaze Detection", "AR Projection"))
                TopicContent("On-Device AI", SlideLayout.DIAGRAM,
                    listOf("MediaPipe LLM", "TensorFlow Lite", "ONNX Runtime", "Core ML"),
                    listOf("Gemma/Phi Models", "Quantization", "Cross-platform", "Apple Silicon"))
            )
            else -> (1..10).map { i ->
                TopicContent("Key Aspect $i: $topic", SlideLayout.CONTENT,
                    listOf("Fundamental Concept $i", "Technical Details", "Implementation", "Best Practices"),
                    listOf("Theory", "Code Examples", "Architecture", "Patterns"))
            }
        }
    }

    private fun createTitleSlide(ppt: XMLSlideShow, title: String, pageSize: java.awt.Dimension, template: PptTemplate) {
        val slide = ppt.createSlide()
        val background = slide.background
        background.setFillColor(JARVIS_DARK)

        // Background accent
        val bgAccent = slide.createAutoShape()
        bgAccent.anchor.setRect(0, 0, pageSize.width, pageSize.height)
        bgAccent.fillColor = JARVIS_DARKER
        bgAccent.lineColor = java.awt.Color(0x00, 0x00, 0x00, 0x00)

        // Decorative lines
        val topLine = slide.createAutoShape()
        topLine.anchor.setRect(80, 80, pageSize.width - 160, 2)
        topLine.fillColor = getTemplateAccentColor(template)
        topLine.lineColor = getTemplateAccentColor(template)

        val bottomLine = slide.createAutoShape()
        bottomLine.anchor.setRect(80, pageSize.height - 80, pageSize.width - 160, 2)
        bottomLine.fillColor = getTemplateAccentColor(template)
        bottomLine.lineColor = getTemplateAccentColor(template)

        // Template badge
        val badgeShape = slide.createAutoShape()
        badgeShape.anchor.setRect(pageSize.width - 280, 40, 240, 40)
        badgeShape.fillColor = getTemplateAccentColor(template).copy(alpha = 0.2f)
        badgeShape.lineColor = getTemplateAccentColor(template)
        val badgePara = badgeShape.textParagraphs[0]
        val badgeRun = badgePara.addNewTextRun()
        badgeRun.text = "  ${template.name}  "
        badgeRun.fontSize = 12.0
        badgeRun.isBold = true
        badgeRun.fontColor = getTemplateAccentColor(template)
        badgeRun.fontFamily = "Calibri"
        badgePara.alignment = TextAlign.CENTER

        // Main title
        val titleShape = slide.createAutoShape()
        titleShape.anchor.setRect(80, pageSize.height / 2 - 150, pageSize.width - 160, 200)
        val titleParagraph = titleShape.textParagraphs[0]
        val titleRun = titleParagraph.addNewTextRun()
        titleRun.text = title.uppercase()
        titleRun.fontSize = 48.0
        titleRun.isBold = true
        titleRun.fontColor = JARVIS_CYAN
        titleRun.fontFamily = "Calibri"
        titleParagraph.alignment = TextAlign.CENTER
        titleParagraph.spaceAfter = 200.0

        // Subtitle
        val subtitleShape = slide.createAutoShape()
        subtitleShape.anchor.setRect(80, pageSize.height / 2 + 80, pageSize.width - 160, 100)
        val subtitleParagraph = subtitleShape.textParagraphs[0]
        val subtitleRun = subtitleParagraph.addNewTextRun()
        subtitleRun.text = "Generated by J.A.R.V.I.S. • ${SimpleDateFormat("MMMM d, yyyy", Locale.getDefault()).format(Date())}"
        subtitleRun.fontSize = 18.0
        subtitleRun.fontColor = JARVIS_GRAY
        subtitleRun.fontFamily = "Calibri"
        subtitleParagraph.alignment = TextAlign.CENTER

        // Decorative corner brackets
        drawCornerBrackets(slide, 80, 80, pageSize.width - 160, pageSize.height - 160, getTemplateAccentColor(template))
    }

    private fun createSlideByLayout(ppt: XMLSlideShow, slideData: PptSlideData, pageSize: java.awt.Dimension, template: PptTemplate) {
        when (slideData.layout) {
            SlideLayout.TITLE -> createTitleContentSlide(ppt, slideData, pageSize, template)
            SlideLayout.CONTENT -> createContentSlide(ppt, slideData, pageSize, template)
            SlideLayout.TWO_COLUMN -> createTwoColumnSlide(ppt, slideData, pageSize, template)
            SlideLayout.PROCESS -> createProcessSlide(ppt, slideData, pageSize, template)
            SlideLayout.COMPARISON -> createComparisonSlide(ppt, slideData, pageSize, template)
            SlideLayout.STATS -> createStatsSlide(ppt, slideData, pageSize, template)
            SlideLayout.TIMELINE -> createTimelineSlide(ppt, slideData, pageSize, template)
            SlideLayout.CLOSING -> createClosingSlide(ppt, slideData, pageSize, template)
            else -> createContentSlide(ppt, slideData, pageSize, template)
        }
    }

    private fun createContentSlide(ppt: XMLSlideShow, slideData: PptSlideData, pageSize: java.awt.Dimension, template: PptTemplate) {
        val slide = ppt.createSlide()
        applySlideBackground(slide, template)

        // Title
        val titleShape = slide.createAutoShape()
        titleShape.anchor.setRect(80, 60, pageSize.width - 160, 80)
        val titlePara = titleShape.textParagraphs[0]
        val titleRun = titlePara.addNewTextRun()
        titleRun.text = slideData.title
        titleRun.fontSize = 36.0
        titleRun.isBold = true
        titleRun.fontColor = getTemplateAccentColor(template)
        titleRun.fontFamily = "Calibri"

        // Accent line
        val lineShape = slide.createAutoShape()
        lineShape.anchor.setRect(80, 140, pageSize.width - 160, 3)
        lineShape.fillColor = getTemplateAccentColor(template)
        lineShape.lineColor = getTemplateAccentColor(template)

        // Bullet points
        val contentShape = slide.createAutoShape()
        contentShape.anchor.setRect(100, 180, pageSize.width - 200, pageSize.height - 260)
        val contentPara = contentShape.textParagraphs[0]

        for (i in slideData.bulletPoints.indices) {
            val run = if (i == 0) contentPara.addNewTextRun() else contentPara.addNewTextRun()
            run.text = "▸ ${slideData.bulletPoints[i]}"
            run.fontSize = 22.0
            run.fontColor = JARVIS_WHITE
            run.fontFamily = "Calibri"
            run.isBold = i == 0
            if (i < slideData.bulletPoints.size - 1) run.text += "\n\n"
        }
        contentPara.alignment = TextAlign.LEFT
        contentPara.spaceAfter = 120.0
        contentPara.spaceBefore = 40.0
        contentPara.lineSpacing = 1.4
    }

    private fun createTwoColumnSlide(ppt: XMLSlideShow, slideData: PptSlideData, pageSize: java.awt.Dimension, template: PptTemplate) {
        val slide = ppt.createSlide()
        applySlideBackground(slide, template)

        // Title
        val titleShape = slide.createAutoShape()
        titleShape.anchor.setRect(80, 60, pageSize.width - 160, 80)
        val titlePara = titleShape.textParagraphs[0]
        val titleRun = titlePara.addNewTextRun()
        titleRun.text = slideData.title
        titleRun.fontSize = 36.0
        titleRun.isBold = true
        titleRun.fontColor = getTemplateAccentColor(template)
        titleRun.fontFamily = "Calibri"

        // Accent line
        val lineShape = slide.createAutoShape()
        lineShape.anchor.setRect(80, 140, pageSize.width - 160, 3)
        lineShape.fillColor = getTemplateAccentColor(template)
        lineShape.lineColor = getTemplateAccentColor(template)

        // Left column
        val leftShape = slide.createAutoShape()
        leftShape.anchor.setRect(100, 180, pageSize.width / 2 - 120, pageSize.height - 260)
        val leftPara = leftShape.textParagraphs[0]
        
        val leftPoints = slideData.bulletPoints.chunked(slideData.bulletPoints.size / 2 + 1).firstOrNull() ?: emptyList()
        for (i in leftPoints.indices) {
            val run = if (i == 0) leftPara.addNewTextRun() else leftPara.addNewTextRun()
            run.text = "▸ ${leftPoints[i]}"
            run.fontSize = 20.0
            run.fontColor = JARVIS_WHITE
            run.fontFamily = "Calibri"
            run.isBold = i == 0
            if (i < leftPoints.size - 1) run.text += "\n\n"
        }
        leftPara.alignment = TextAlign.LEFT
        leftPara.spaceAfter = 100.0
        leftPara.lineSpacing = 1.4

        // Right column
        val rightShape = slide.createAutoShape()
        rightShape.anchor.setRect(pageSize.width / 2 + 20, 180, pageSize.width - 100, pageSize.height - 260)
        val rightPara = rightShape.textParagraphs[0]
        
        val rightPoints = slideData.secondaryPoints ?: slideData.bulletPoints.chunked(slideData.bulletPoints.size / 2 + 1).getOrNull(1) ?: emptyList()
        for (i in rightPoints.indices) {
            val run = if (i == 0) rightPara.addNewTextRun() else rightPara.addNewTextRun()
            run.text = "▸ ${rightPoints[i]}"
            run.fontSize = 20.0
            run.fontColor = JARVIS_TEAL
            run.fontFamily = "Calibri"
            run.isBold = i == 0
            if (i < rightPoints.size - 1) run.text += "\n\n"
        }
        rightPara.alignment = TextAlign.LEFT
        rightPara.spaceAfter = 100.0
        rightPara.lineSpacing = 1.4

        // Column divider
        val divider = slide.createAutoShape()
        divider.anchor.setRect(pageSize.width / 2 - 1, 180, 2, pageSize.height - 260)
        divider.fillColor = getTemplateAccentColor(template).copy(alpha = 0.3f)
        divider.lineColor = java.awt.Color(0x00, 0x00, 0x00, 0x00)
    }

    private fun createProcessSlide(ppt: XMLSlideShow, slideData: PptSlideData, pageSize: java.awt.Dimension, template: PptTemplate) {
        val slide = ppt.createSlide()
        applySlideBackground(slide, template)

        // Title
        val titleShape = slide.createAutoShape()
        titleShape.anchor.setRect(80, 60, pageSize.width - 160, 80)
        val titlePara = titleShape.textParagraphs[0]
        val titleRun = titlePara.addNewTextRun()
        titleRun.text = slideData.title
        titleRun.fontSize = 36.0
        titleRun.isBold = true
        titleRun.fontColor = getTemplateAccentColor(template)
        titleRun.fontFamily = "Calibri"

        // Accent line
        val lineShape = slide.createAutoShape()
        lineShape.anchor.setRect(80, 140, pageSize.width - 160, 3)
        lineShape.fillColor = getTemplateAccentColor(template)
        lineShape.lineColor = getTemplateAccentColor(template)

        // Process steps
        val stepHeight = (pageSize.height - 220) / slideData.bulletPoints.size
        for (i in slideData.bulletPoints.indices) {
            val yPos = 180 + i * stepHeight
            
            // Step number circle
            val circle = slide.createAutoShape()
            circle.anchor.setRect(100, yPos + 10, 50, 50)
            circle.fillColor = getTemplateAccentColor(template)
            circle.lineColor = java.awt.Color(0x00, 0x00, 0x00, 0x00)
            
            val circlePara = circle.textParagraphs[0]
            circlePara.alignment = TextAlign.CENTER
            val circleRun = circlePara.addNewTextRun()
            circleRun.text = "${i + 1}"
            circleRun.fontSize = 20.0
            circleRun.isBold = true
            circleRun.fontColor = JARVIS_DARK
            circleRun.fontFamily = "Calibri"

            // Step text
            val textShape = slide.createAutoShape()
            textShape.anchor.setRect(180, yPos + 10, pageSize.width - 280, stepHeight - 20)
            val textPara = textShape.textParagraphs[0]
            val textRun = textPara.addNewTextRun()
            textRun.text = "${i + 1}. ${slideData.bulletPoints[i]}"
            textRun.fontSize = 22.0
            textRun.fontColor = JARVIS_WHITE
            textRun.fontFamily = "Calibri"
            textRun.isBold = true
            textPara.alignment = TextAlign.LEFT
            textPara.spaceAfter = 80.0

            // Connector line between steps
            if (i < slideData.bulletPoints.size - 1) {
                val connector = slide.createAutoShape()
                connector.anchor.setRect(124, yPos + 60, 2, stepHeight - 60)
                connector.fillColor = getTemplateAccentColor(template).copy(alpha = 0.4f)
                connector.lineColor = java.awt.Color(0x00, 0x00, 0x00, 0x00)
            }
        }
    }

    private fun createComparisonSlide(ppt: XMLSlideShow, slideData: PptSlideData, pageSize: java.awt.Dimension, template: PptTemplate) {
        val slide = ppt.createSlide()
        applySlideBackground(slide, template)

        // Title
        val titleShape = slide.createAutoShape()
        titleShape.anchor.setRect(80, 60, pageSize.width - 160, 80)
        val titlePara = titleShape.textParagraphs[0]
        val titleRun = titlePara.addNewTextRun()
        titleRun.text = slideData.title
        titleRun.fontSize = 36.0
        titleRun.isBold = true
        titleRun.fontColor = getTemplateAccentColor(template)
        titleRun.fontFamily = "Calibri"

        // Accent line
        val lineShape = slide.createAutoShape()
        lineShape.anchor.setRect(80, 140, pageSize.width - 160, 3)
        lineShape.fillColor = getTemplateAccentColor(template)
        lineShape.lineColor = getTemplateAccentColor(template)

        // Table header
        val headerShape = slide.createAutoShape()
        headerShape.anchor.setRect(100, 180, pageSize.width - 200, 50)
        headerShape.fillColor = getTemplateAccentColor(template).copy(alpha = 0.2f)
        headerShape.lineColor = getTemplateAccentColor(template)
        val headerPara = headerShape.textParagraphs[0]
        headerPara.alignment = TextAlign.CENTER
        val headerRun = headerPara.addNewTextRun()
        headerRun.text = "BEFORE                    vs                    AFTER"
        headerRun.fontSize = 18.0
        headerRun.isBold = true
        headerRun.fontColor = getTemplateAccentColor(template)
        headerRun.fontFamily = "Calibri"

        // Comparison rows
        val pairs = slideData.bulletPoints.chunked(2)
        val rowHeight = (pageSize.height - 280) / pairs.size
        
        for (i in pairs.indices) {
            val yPos = 240 + i * rowHeight
            val pair = pairs[i]
            
            // Before
            val beforeShape = slide.createAutoShape()
            beforeShape.anchor.setRect(120, yPos, pageSize.width / 2 - 140, rowHeight - 20)
            beforeShape.fillColor = JARVIS_AMBER.copy(alpha = 0.1f)
            beforeShape.lineColor = JARVIS_AMBER.copy(alpha = 0.3f)
            val beforePara = beforeShape.textParagraphs[0]
            beforePara.alignment = TextAlign.LEFT
            val beforeRun = beforePara.addNewTextRun()
            beforeRun.text = "✗ ${pair.firstOrNull() ?: ""}"
            beforeRun.fontSize = 18.0
            beforeRun.fontColor = JARVIS_AMBER
            beforeRun.fontFamily = "Calibri"

            // After
            val afterShape = slide.createAutoShape()
            afterShape.anchor.setRect(pageSize.width / 2 + 20, yPos, pageSize.width - 120, rowHeight - 20)
            afterShape.fillColor = JARVIS_TEAL.copy(alpha = 0.1f)
            afterShape.lineColor = JARVIS_TEAL.copy(alpha = 0.3f)
            val afterPara = afterShape.textParagraphs[0]
            afterPara.alignment = TextAlign.LEFT
            val afterRun = afterPara.addNewTextRun()
            afterRun.text = "✓ ${pair.getOrNull(1) ?: ""}"
            afterRun.fontSize = 18.0
            afterRun.fontColor = JARVIS_TEAL
            afterRun.fontFamily = "Calibri"

            // Arrow
            val arrowShape = slide.createAutoShape()
            arrowShape.anchor.setRect(pageSize.width / 2 - 40, yPos + rowHeight / 2 - 15, 80, 30)
            val arrowPara = arrowShape.textParagraphs[0]
            arrowPara.alignment = TextAlign.CENTER
            val arrowRun = arrowPara.addNewTextRun()
            arrowRun.text = "→"
            arrowRun.fontSize = 24.0
            arrowRun.isBold = true
            arrowRun.fontColor = getTemplateAccentColor(template)
            arrowRun.fontFamily = "Calibri"
        }
    }

    private fun createStatsSlide(ppt: XMLSlideShow, slideData: PptSlideData, pageSize: java.awt.Dimension, template: PptTemplate) {
        val slide = ppt.createSlide()
        applySlideBackground(slide, template)

        // Title
        val titleShape = slide.createAutoShape()
        titleShape.anchor.setRect(80, 60, pageSize.width - 160, 80)
        val titlePara = titleShape.textParagraphs[0]
        val titleRun = titlePara.addNewTextRun()
        titleRun.text = slideData.title
        titleRun.fontSize = 36.0
        titleRun.isBold = true
        titleRun.fontColor = getTemplateAccentColor(template)
        titleRun.fontFamily = "Calibri"

        // Accent line
        val lineShape = slide.createAutoShape()
        lineShape.anchor.setRect(80, 140, pageSize.width - 160, 3)
        lineShape.fillColor = getTemplateAccentColor(template)
        lineShape.lineColor = getTemplateAccentColor(template)

        // Stat cards
        val stats = slideData.bulletPoints
        val cardWidth = (pageSize.width - 200) / stats.size
        
        for (i in stats.indices) {
            val xPos = 100 + i * cardWidth
            
            val cardShape = slide.createAutoShape()
            cardShape.anchor.setRect(xPos, 200, cardWidth - 20, 200)
            cardShape.fillColor = JARVIS_LIGHT_GRAY
            cardShape.lineColor = getTemplateAccentColor(template).copy(alpha = 0.3f)
            
            // Stat value
            val statParts = stats[i].split(":")
            val value = statParts.firstOrNull() ?: stats[i]
            val label = statParts.getOrNull(1) ?: ""
            
            val valueShape = slide.createAutoShape()
            valueShape.anchor.setRect(xPos + 10, 220, cardWidth - 40, 100)
            val valuePara = valueShape.textParagraphs[0]
            valuePara.alignment = TextAlign.CENTER
            val valueRun = valuePara.addNewTextRun()
            valueRun.text = value.trim()
            valueRun.fontSize = 36.0
            valueRun.isBold = true
            valueRun.fontColor = getTemplateAccentColor(template)
            valueRun.fontFamily = "Calibri"

            // Stat label
            val labelShape = slide.createAutoShape()
            labelShape.anchor.setRect(xPos + 10, 330, cardWidth - 40, 60)
            val labelPara = labelShape.textParagraphs[0]
            labelPara.alignment = TextAlign.CENTER
            val labelRun = labelPara.addNewTextRun()
            labelRun.text = label.trim()
            labelRun.fontSize = 16.0
            labelRun.fontColor = JARVIS_GRAY
            labelRun.fontFamily = "Calibri"
        }
    }

    private fun createTimelineSlide(ppt: XMLSlideShow, slideData: PptSlideData, pageSize: java.awt.Dimension, template: PptTemplate) {
        val slide = ppt.createSlide()
        applySlideBackground(slide, template)

        // Title
        val titleShape = slide.createAutoShape()
        titleShape.anchor.setRect(80, 60, pageSize.width - 160, 80)
        val titlePara = titleShape.textParagraphs[0]
        val titleRun = titlePara.addNewTextRun()
        titleRun.text = slideData.title
        titleRun.fontSize = 36.0
        titleRun.isBold = true
        titleRun.fontColor = getTemplateAccentColor(template)
        titleRun.fontFamily = "Calibri"

        // Accent line
        val lineShape = slide.createAutoShape()
        lineShape.anchor.setRect(80, 140, pageSize.width - 160, 3)
        lineShape.fillColor = getTemplateAccentColor(template)
        lineShape.lineColor = getTemplateAccentColor(template)

        // Timeline
        val timelineX = 200
        val items = slideData.bulletPoints
        val itemHeight = (pageSize.height - 220) / items.size
        
        // Vertical line
        val vLine = slide.createAutoShape()
        vLine.anchor.setRect(timelineX, 180, 3, pageSize.height - 220)
        vLine.fillColor = getTemplateAccentColor(template).copy(alpha = 0.4f)
        vLine.lineColor = java.awt.Color(0x00, 0x00, 0x00, 0x00)
        
        for (i in items.indices) {
            val yPos = 180 + i * itemHeight + itemHeight / 2
            
            // Circle marker
            val circle = slide.createAutoShape()
            circle.anchor.setRect(timelineX - 15, yPos - 15, 30, 30)
            circle.fillColor = getTemplateAccentColor(template)
            circle.lineColor = java.awt.Color(0x00, 0x00, 0x00, 0x00)
            
            // Content
            val contentShape = slide.createAutoShape()
            contentShape.anchor.setRect(timelineX + 40, yPos - 40, pageSize.width - timelineX - 80, 80)
            val contentPara = contentShape.textParagraphs[0]
            
            val run1 = contentPara.addNewTextRun()
            run1.text = items[i]
            run1.fontSize = 20.0
            run1.isBold = true
            run1.fontColor = JARVIS_WHITE
            run1.fontFamily = "Calibri"
            run1.text += "\n"
            
            val run2 = contentPara.addNewTextRun()
            run2.text = "Milestone ${i + 1}"
            run2.fontSize = 14.0
            run2.fontColor = JARVIS_GRAY
            run2.fontFamily = "Calibri"
            
            contentPara.alignment = TextAlign.LEFT
        }
    }

    private fun createClosingSlide(ppt: XMLSlideShow, slideData: PptSlideData, pageSize: java.awt.Dimension, template: PptTemplate) {
        val slide = ppt.createSlide()
        applySlideBackground(slide, template)

        // Large "Thank You"
        val titleShape = slide.createAutoShape()
        titleShape.anchor.setRect(80, pageSize.height / 2 - 150, pageSize.width - 160, 100)
        val titlePara = titleShape.textParagraphs[0]
        titlePara.alignment = TextAlign.CENTER
        val titleRun = titlePara.addNewTextRun()
        titleRun.text = "THANK YOU"
        titleRun.fontSize = 56.0
        titleRun.isBold = true
        titleRun.fontColor = getTemplateAccentColor(template)
        titleRun.fontFamily = "Calibri"

        // Subtitle
        val subtitleShape = slide.createAutoShape()
        subtitleShape.anchor.setRect(80, pageSize.height / 2 - 30, pageSize.width - 160, 80)
        val subtitlePara = subtitleShape.textParagraphs[0]
        subtitlePara.alignment = TextAlign.CENTER
        val subtitleRun = subtitlePara.addNewTextRun()
        subtitleRun.text = "Questions & Discussion"
        subtitleRun.fontSize = 24.0
        subtitleRun.fontColor = JARVIS_GRAY
        subtitleRun.fontFamily = "Calibri"

        // Contact info
        val infoShape = slide.createAutoShape()
        infoShape.anchor.setRect(80, pageSize.height / 2 + 80, pageSize.width - 160, 150)
        val infoPara = infoShape.textParagraphs[0]
        infoPara.alignment = TextAlign.CENTER
        
        val contacts = listOf(
            "JARVIS@starkindustries.com",
            "github.com/jarvis-ai",
            "docs.jarvis.ai",
            "Generated by J.A.R.V.I.S. v1.0"
        )
        for (i in contacts.indices) {
            val run = if (i == 0) infoPara.addNewTextRun() else infoPara.addNewTextRun()
            run.text = contacts[i]
            run.fontSize = 14.0
            run.fontColor = if (i == 0) getTemplateAccentColor(template) else JARVIS_GRAY
            run.fontFamily = "Calibri"
            run.isBold = i == 0
            if (i < contacts.size - 1) run.text += "\n"
        }
        infoPara.spaceAfter = 60.0
        infoPara.lineSpacing = 1.6
    }

    private fun createTitleContentSlide(ppt: XMLSlideShow, slideData: PptSlideData, pageSize: java.awt.Dimension, template: PptTemplate) {
        val slide = ppt.createSlide()
        applySlideBackground(slide, template)

        val titleShape = slide.createAutoShape()
        titleShape.anchor.setRect(80, pageSize.height / 2 - 100, pageSize.width - 160, 100)
        val titlePara = titleShape.textParagraphs[0]
        titlePara.alignment = TextAlign.CENTER
        val titleRun = titlePara.addNewTextRun()
        titleRun.text = slideData.title
        titleRun.fontSize = 44.0
        titleRun.isBold = true
        titleRun.fontColor = getTemplateAccentColor(template)
        titleRun.fontFamily = "Calibri"

        val subtitleShape = slide.createAutoShape()
        subtitleShape.anchor.setRect(80, pageSize.height / 2 + 20, pageSize.width - 160, 150)
        val subtitlePara = subtitleShape.textParagraphs[0]
        subtitlePara.alignment = TextAlign.CENTER
        
        for (i in slideData.bulletPoints.indices) {
            val run = if (i == 0) subtitlePara.addNewTextRun() else subtitlePara.addNewTextRun()
            run.text = slideData.bulletPoints[i]
            run.fontSize = if (i == 0) 20.0 else 16.0
            run.fontColor = if (i == 0) JARVIS_WHITE else JARVIS_GRAY
            run.fontFamily = "Calibri"
            run.isBold = i == 0
            if (i < slideData.bulletPoints.size - 1) run.text += "\n"
        }
        subtitlePara.spaceAfter = 80.0
        subtitlePara.lineSpacing = 1.5
    }

    private fun applySlideBackground(slide: XSLFSlide, template: PptTemplate) {
        val background = slide.background
        when (template) {
            PptTemplate.JARVIS_CLASSIC, PptTemplate.TACTICAL_HUD, PptTemplate.HOLOGRAPHIC -> background.setFillColor(JARVIS_DARK)
            PptTemplate.STARK_INDUSTRIES -> background.setFillColor(java.awt.Color(0x1A, 0x1A, 0x2E))
            PptTemplate.MINIMAL_LIGHT -> background.setFillColor(java.awt.Color(0xFA, 0xFA, 0xFC))
        }
    }

    private fun getTemplateAccentColor(template: PptTemplate): java.awt.Color {
        return when (template) {
            PptTemplate.JARVIS_CLASSIC, PptTemplate.TACTICAL_HUD, PptTemplate.HOLOGRAPHIC -> JARVIS_CYAN
            PptTemplate.STARK_INDUSTRIES -> java.awt.Color(0xFF, 0xD7, 0x00)
            PptTemplate.MINIMAL_LIGHT -> java.awt.Color(0x25, 0x63, 0xEB)
        }
    }

    private fun drawCornerBrackets(slide: XSLFSlide, x: Int, y: Int, width: Int, height: Int, color: java.awt.Color) {
        val bracketSize = 40
        val positions = listOf(
            Pair(x, y), // TL
            Pair(x + width - bracketSize, y), // TR
            Pair(x, y + height - bracketSize), // BL
            Pair(x + width - bracketSize, y + height - bracketSize) // BR
        )
        
        for ((bx, by) in positions) {
            val isLeft = bx < x + width / 2
            val isTop = by < y + height / 2
            val bracket = slide.createAutoShape()
            val path = java.awt.geom.Path2D.Float()
            
            if (isLeft && isTop) {
                path.moveTo(0, bracketSize.toFloat())
                path.lineTo(0, 0f)
                path.lineTo(bracketSize.toFloat(), 0f)
            } else if (!isLeft && isTop) {
                path.moveTo(bracketSize.toFloat(), 0f)
                path.lineTo(0f, 0f)
                path.lineTo(0f, bracketSize.toFloat())
            } else if (isLeft && !isTop) {
                path.moveTo(0f, 0f)
                path.lineTo(0f, bracketSize.toFloat())
                path.lineTo(bracketSize.toFloat(), bracketSize.toFloat())
            } else {
                path.moveTo(bracketSize.toFloat(), 0f)
                path.lineTo(0f, 0f)
                path.lineTo(0f, bracketSize.toFloat())
            }
            
            bracket.anchor.setRect(bx, by, bracketSize, bracketSize)
            // Note: POI doesn't directly support custom paths easily, using simple lines instead
            bracket.lineColor = color
            bracket.lineWidth = 3.0
        }
    }

    private fun getOutputFile(fileName: String): File {
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val jarvisDir = File(downloadsDir, "JARVIS_Presentations")
        if (!jarvisDir.exists()) {
            jarvisDir.mkdirs()
        }
        return File(jarvisDir, fileName)
    }

    data class PptSlideData(
        val title: String,
        val layout: SlideLayout = SlideLayout.CONTENT,
        val bulletPoints: List<String> = emptyList(),
        val secondaryPoints: List<String>? = null
    )

    data class TopicContent(
        val title: String,
        val layout: SlideLayout = SlideLayout.CONTENT,
        val points: List<String> = emptyList(),
        val secondaryPoints: List<String>? = null
    )
}