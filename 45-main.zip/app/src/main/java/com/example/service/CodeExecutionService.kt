package com.example.service

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter

class CodeExecutionService(private val context: Context) {

    companion object {
        private const val TAG = "CodeExecutionService"
    }

    interface ExecutionCallback {
        fun onSuccess(output: String)
        fun onError(error: String)
    }

    fun executeCode(
        code: String,
        language: String = "python",
        callback: ExecutionCallback
    ) {
        // For security, we'll use a sandboxed approach
        // In a real app, you'd use a proper sandbox like Termux API, Jupyter, or a cloud service
        thread {
            try {
                val output = when (language.lowercase()) {
                    "python" -> executePython(code)
                    "kotlin" -> executeKotlin(code)
                    "javascript", "js" -> executeJavaScript(code)
                    "shell", "bash", "sh" -> executeShell(code)
                    else -> "Language $language not supported. Supported: python, kotlin, javascript, shell"
                }
                callback.onSuccess(output)
            } catch (e: Exception) {
                Log.e(TAG, "Code execution error", e)
                callback.onError("Execution failed: ${e.message}")
            }
        }
    }

    private fun executePython(code: String): String {
        // Use a simple approach - write to file and try to execute
        // Note: This requires Python to be installed on device (e.g., via Termux)
        // For production, consider using Chaquopy or a cloud-based solution
        val tempFile = File(context.cacheDir, "jarvis_script_${System.currentTimeMillis()}.py")
        try {
            FileOutputStream(tempFile).use { fos ->
                OutputStreamWriter(fos).use { writer ->
                    writer.write(code)
                }
            }

            // Try to execute with python3 if available
            val process = Runtime.getRuntime().exec(arrayOf("python3", tempFile.absolutePath))
            val output = StringBuilder()
            val error = StringBuilder()

            process.inputStream.use { it.reader().use { reader -> output.append(reader.readText()) } }
            process.errorStream.use { it.reader().use { reader -> error.append(reader.readText()) } }
            process.waitFor()

            if (error.isNotEmpty()) {
                return "Error: ${error.toString().trim()}"
            }
            return if (output.isNotEmpty()) output.toString().trim() else "Code executed successfully (no output)"
        } catch (e: Exception) {
            return "Python execution not available on this device. ${e.message}"
        } finally {
            tempFile.delete()
        }
    }

    private fun executeKotlin(code: String): String {
        // Kotlin compilation requires kotlinc which isn't typically available on Android
        // This would need a cloud service or a local compiler like kotlinc-jvm
        return "Kotlin execution requires cloud compilation service. Code:\n$code"
    }

    private fun executeJavaScript(code: String): String {
        // Use Rhino or V8 if available, or evaluate simple expressions
        // For now, return a placeholder
        return "JavaScript execution requires a JS engine (Rhino/V8). Code:\n$code"
    }

    private fun executeShell(code: String): String {
        try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", code))
            val output = StringBuilder()
            val error = StringBuilder()

            process.inputStream.use { it.reader().use { reader -> output.append(reader.readText()) } }
            process.errorStream.use { it.reader().use { reader -> error.append(reader.readText()) } }
            process.waitFor()

            if (error.isNotEmpty()) {
                return "Error: ${error.toString().trim()}"
            }
            return if (output.isNotEmpty()) output.toString().trim() else "Command executed successfully"
        } catch (e: Exception) {
            return "Shell execution failed: ${e.message}"
        }
    }

    fun executeGitCommand(args: String, callback: ExecutionCallback) {
        thread {
            try {
                val process = Runtime.getRuntime().exec(arrayOf("git", *args.split(" ")))
                val output = StringBuilder()
                val error = StringBuilder()

                process.inputStream.use { it.reader().use { reader -> output.append(reader.readText()) } }
                process.errorStream.use { it.reader().use { reader -> error.append(reader.readText()) } }
                process.waitFor()

                if (error.isNotEmpty()) {
                    callback.onError("Git error: ${error.toString().trim()}")
                } else {
                    callback.onSuccess(output.toString().trim())
                }
            } catch (e: Exception) {
                callback.onError("Git command failed: ${e.message}")
            }
        }
    }
}