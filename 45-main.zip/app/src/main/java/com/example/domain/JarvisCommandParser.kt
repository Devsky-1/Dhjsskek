package com.example.domain

import java.util.Locale
import java.util.regex.Pattern

sealed interface ParsedJarvisCommand {
    data class Flashlight(val enable: Boolean) : ParsedJarvisCommand
    data class Timer(val seconds: Int, val label: String) : ParsedJarvisCommand
    data class Weather(val location: String) : ParsedJarvisCommand
    data class Reminder(val title: String, val dueTime: String, val priority: String = "NORMAL") : ParsedJarvisCommand
    data class Note(val title: String, val content: String) : ParsedJarvisCommand
    data class Diagnostic(val component: String = "ALL") : ParsedJarvisCommand
    data class Protocol(val protocolName: String) : ParsedJarvisCommand
    data class OpenApp(val appName: String, val packageName: String? = null) : ParsedJarvisCommand
    object GoHome : ParsedJarvisCommand
    data class OpenAssistantScreen(val tabIndex: Int) : ParsedJarvisCommand
    data class MathCalculation(val expression: String, val result: String) : ParsedJarvisCommand
    object StopSpeaking : ParsedJarvisCommand
    object TimeQuery : ParsedJarvisCommand
    object DateQuery : ParsedJarvisCommand
    object DailyBriefing : ParsedJarvisCommand
    object ClearHistory : ParsedJarvisCommand
    data class IronManProtocol(val protocolType: String) : ParsedJarvisCommand
    object FireRepulsor : ParsedJarvisCommand
    data class GeneratePpt(
    val topic: String, 
    val slideCount: Int = 10, 
    val template: com.example.service.PptGenerationService.PptTemplate = com.example.service.PptGenerationService.PptTemplate.JARVIS_CLASSIC
) : ParsedJarvisCommand
    data class SendEmail(val to: String, val subject: String, val body: String) : ParsedJarvisCommand
    data class SendSms(val to: String, val body: String) : ParsedJarvisCommand
    data class CreateCalendarEvent(val title: String, val dateTime: String, val description: String) : ParsedJarvisCommand
    data class SearchWeb(val query: String) : ParsedJarvisCommand
    data class TranslateText(val text: String, val targetLanguage: String) : ParsedJarvisCommand
    data class FileOperation(val operation: String, val path: String, val content: String?) : ParsedJarvisCommand
    data class GeneralQuery(val query: String) : ParsedJarvisCommand
}

object JarvisCommandParser {

    fun parse(input: String): ParsedJarvisCommand {
        val text = input.trim().lowercase()

        // Immediate Stop / Silence commands
        if (text == "stop" || text == "cancel" || text == "shut up" || text == "be quiet" ||
            text == "chup" || text == "ruko" || text == "band karo" || text == "रुको" || text == "चुप रहो" ||
            text.startsWith("stop speaking") || text.startsWith("stop talking")) {
            return ParsedJarvisCommand.StopSpeaking
        }

        // Direct Assistant Internal Navigation Screen Commands
        if (text.contains("jarvis setting") || text.contains("assistant setting") ||
            text == "open settings" || text == "settings kholo" || text.contains("customize jarvis") ||
            text.contains("customization studio") || text.contains("change voice")) {
            return ParsedJarvisCommand.OpenAssistantScreen(1)
        }

        if (text.contains("open diagnostic") || text.contains("show diagnostic") ||
            text.contains("show telemetry") || text.contains("open telemetry") ||
            text.contains("hardware scan") || text.contains("system status screen") ||
            text.contains("telemetry check")) {
            return ParsedJarvisCommand.OpenAssistantScreen(3)
        }

        if (text.contains("open memory") || text.contains("open notes") ||
            text.contains("open reminder") || text.contains("show reminder") ||
            text.contains("show notes") || text.contains("memory matrix")) {
            return ParsedJarvisCommand.OpenAssistantScreen(4)
        }

        if (text == "lock screen" || text.contains("ambient mode") || text.contains("lock hud") ||
            text.contains("open lock screen") || text.contains("lock overlay")) {
            return ParsedJarvisCommand.OpenAssistantScreen(2)
        }

        if (text.contains("tactical hud") || text.contains("flight visor") || text.contains("combat hud") ||
            text.contains("iron man hud") || text.contains("helmet visor") || text.contains("suit up") ||
            text == "visor" || text.contains("open visor") || text.contains("visor kholo") || text.contains("mark hud") ||
            text.contains("armor hud") || text.contains("tactical visor") || text.contains("हेलमेट हुड") || text.contains("वाइज़र खोलो")) {
            return ParsedJarvisCommand.OpenAssistantScreen(5)
        }

        // Open Apps commands
        if (text.startsWith("open ") || text.startsWith("launch ") || text.contains(" kholo") || text.contains(" खोलो")) {
            when {
                text.contains("youtube") || text.contains("यू ट्यूब") ->
                    return ParsedJarvisCommand.OpenApp("YouTube", "com.google.android.youtube")
                text.contains("chrome") || text.contains("browser") || text.contains("क्रोम") ->
                    return ParsedJarvisCommand.OpenApp("Chrome", "com.android.chrome")
                text.contains("camera") || text.contains("कैमरा") ->
                    return ParsedJarvisCommand.OpenApp("Camera", "android.media.action.IMAGE_CAPTURE")
                text.contains("settings") || text.contains("setting") || text.contains("सेटिंग") ->
                    return ParsedJarvisCommand.OpenApp("Settings", "android.settings.SETTINGS")
                text.contains("calculator") || text.contains("कैलकुलेटर") ->
                    return ParsedJarvisCommand.OpenApp("Calculator", "com.google.android.calculator")
                text.contains("maps") || text.contains("map") || text.contains("नक्शा") ->
                    return ParsedJarvisCommand.OpenApp("Maps", "com.google.android.apps.maps")
                else -> {
                    val app = text.replace(Regex("(?i)^(open|launch|kholo|खोलो)\\s*"), "").trim()
                    if (app.isNotBlank()) return ParsedJarvisCommand.OpenApp(app)
                }
            }
        }

        // Go Home command
        if (text == "go home" || text == "home screen" || text == "open home" || text == "return home" ||
            text == "home" || text == "ghar jao" || text == "home jao" || text == "होम स्क्रीन" || text == "होम जाओ") {
            return ParsedJarvisCommand.GoHome
        }

        // Direct Math Calculation ("What is 25 times 4?" -> "100.")
        val mathCmd = tryParseMath(text)
        if (mathCmd != null) {
            return mathCmd
        }

        // Time Query
        if (text.contains("what time") || text.contains("current time") || text.contains("tell me the time") ||
            text.contains("time kya hai") || text.contains("time kya hua") || text.contains("kitne baje") ||
            text.contains("समय क्या है") || text.contains("टाइम क्या है") || text == "time") {
            return ParsedJarvisCommand.TimeQuery
        }

        // Date Query
        if (text.contains("what date") || text.contains("today's date") || text.contains("what is the date") ||
            text.contains("date kya hai") || text.contains("aaj ki date") || text.contains("आज की तारीख") ||
            text == "date" || text == "aaj konsa din hai") {
            return ParsedJarvisCommand.DateQuery
        }

        // Flashlight intents (English, Hindi & Hinglish)

        if (text.contains("flashlight on") || text.contains("turn on flashlight") || text.contains("torch on") ||
            text.contains("enable lights") || text.contains("illuminate") || text.contains("torch chalu") ||
            text.contains("torch jalao") || text.contains("light jalao") || text.contains("light on") ||
            text.contains("flashlight chalu") || text.contains("टॉर्च चालू") || text.contains("टॉर्च जलाओ") ||
            text.contains("लाइट जलाओ") || text.contains("लाइट ऑन")) {
            return ParsedJarvisCommand.Flashlight(true)
        }
        if (text.contains("flashlight off") || text.contains("turn off flashlight") || text.contains("torch off") ||
            text.contains("disable lights") || text.contains("torch band") || text.contains("torch bujhao") ||
            text.contains("light band") || text.contains("flashlight band") || text.contains("टॉर्च बंद") ||
            text.contains("टॉर्च बुझाओ") || text.contains("लाइट बंद")) {
            return ParsedJarvisCommand.Flashlight(false)
        }

        // Clean slate / Clear history (English, Hindi & Hinglish)
        if (text.contains("clean slate") || text.contains("clear history") || text.contains("purge logs") ||
            text.contains("history saaf") || text.contains("chat delete") || text.contains("sab clear") ||
            text.contains("हिस्ट्री साफ") || text.contains("सब मिटाओ")) {
            return ParsedJarvisCommand.ClearHistory
        }

        // Protocols
        if (text.contains("protocol")) {
            val name = when {
                text.contains("house party") -> "House Party Protocol"
                text.contains("stealth") -> "Stealth Mode"
                text.contains("defense") || text.contains("sentry") -> "Perimeter Defense Grid"
                text.contains("overclock") || text.contains("power") -> "Arc Reactor Overclock"
                else -> "Standard Operational Protocol"
            }
            return ParsedJarvisCommand.Protocol(name)
        }

        // Hologram commands - open holographic chamber
        if (text.contains("hologram") || text.contains("holo") || text.contains("holochamber") ||
            text.contains("holo chamber") || text.contains("holographic") || text.contains("projection") ||
            text.contains("होलोग्राम") || text.contains("प्रोजेक्शन")) {
            // Check for mode-specific commands
            val mode = extractHologramMode(text)
            if (mode != "IDLE") {
                return ParsedJarvisCommand.OpenAssistantScreen(6) // Holographic chamber screen index
            }
            return ParsedJarvisCommand.OpenAssistantScreen(6)
        }

        if (text.contains("veronica") || text.contains("hulkbuster") || text.contains("हल्कबस्टर")) {
            return ParsedJarvisCommand.IronManProtocol("VERONICA")
        }

        if (text.contains("house party")) {
            return ParsedJarvisCommand.IronManProtocol("HOUSE_PARTY")
        }

        if (text.contains("sentry on") || text.contains("arm sentry") || text.contains("sentry mode") ||
            text.contains("activate sentry") || text.contains("perimeter defense") || text.contains("tripwire") ||
            text.contains("सेंट्री चालू")) {
            return ParsedJarvisCommand.IronManProtocol("SENTRY_ARM")
        }

        if (text.contains("disarm sentry") || text.contains("sentry off") || text.contains("stand down sentry") ||
            text.contains("deactivate sentry") || text.contains("सेंट्री बंद")) {
            return ParsedJarvisCommand.IronManProtocol("SENTRY_DISARM")
        }

        if (text.contains("arc reactor overclock") || text.contains("maximum power") || text.contains("divert power to repulsors") ||
            text.contains("overclock power") || text.contains("पावर ओवरक्लॉक")) {
            return ParsedJarvisCommand.IronManProtocol("OVERCLOCK")
        }

        if (text.contains("armor integrity") || text.contains("suit status") || text.contains("mark 85") ||
            text.contains("suit diagnostics") || text.contains("nanotech status") || text.contains("सूट स्थिति")) {
            return ParsedJarvisCommand.IronManProtocol("SUIT_STATUS")
        }

        // Timers: e.g. "set a timer for 5 minutes", "timer 30 seconds", "5 minute ka timer lagao", "टाइमर लगाओ"
        if (text.contains("timer") || text.contains("countdown") || text.contains("टाइमर") || text.contains("minute ka timer")) {
            val seconds = extractTimerSeconds(text)
            if (seconds > 0) {
                val label = extractTimerLabel(text)
                return ParsedJarvisCommand.Timer(seconds, label)
            }
        }

        // Reminders: e.g. "remind me to call Pepper at 5 PM", "reminder buy groceries", "yaad dilana 5 baje"
        if (text.startsWith("remind") || text.contains("set a reminder") || text.contains("reminder") ||
            text.contains("yaad dilana") || text.contains("yaad dila do") || text.contains("रिमाइंडर") || text.contains("याद दिलाना")) {
            val (title, due) = extractReminderDetails(input)
            return ParsedJarvisCommand.Reminder(title = title, dueTime = due)
        }

        // Notes: e.g. "take a note buy milk", "note Stark tech idea", "note banao", "likh lo"
        if (text.startsWith("take a note") || text.startsWith("note:") || text.startsWith("new note") ||
            text.startsWith("write note") || text.contains("note banao") || text.contains("note likho") ||
            text.contains("likh lo") || text.contains("नोट बनाओ") || text.contains("नोट लिखो")) {
            val content = input
                .replace(Regex("(?i)^(take a note|new note|write note|note banao|note likho|likh lo|नोट बनाओ|नोट लिखो|note:?)\\s*(that|to|about|ki|yeh)?\\s*"), "")
                .trim()
            val title = if (content.length > 25) content.take(25) + "..." else content
            return ParsedJarvisCommand.Note(title = if (title.isBlank()) "Quick Note" else title, content = content)
        }

        // Diagnostics / System checks (English, Hindi & Hinglish)
        if (text.contains("diagnostic") || text.contains("system status") || text.contains("telemetry check") ||
            text.contains("hardware scan") || text.contains("battery kitni") || text.contains("battery level") ||
            text.contains("status batao") || text.contains("kaisa chal raha") || text.contains("सिस्टम स्टेटस") ||
            text.contains("बैटरी कितनी")) {
            return ParsedJarvisCommand.Diagnostic("ALL")
        }

        // Daily Briefing / Greetings
        if (text == "good morning" || text.contains("daily briefing") || text.contains("morning report") ||
            text.contains("status briefing") || text.contains("aaj ka report") || text.contains("shubh prabhat") ||
            text.contains("namaste") || text.contains("शुभ प्रभात") || text.contains("नमस्ते") || text.contains("aaj ka haal")) {
            return ParsedJarvisCommand.DailyBriefing
        }

        // Weather: e.g. "weather", "weather in Mumbai", "mausam kaisa hai", "मौसम कैसा है"
        if (text.contains("weather") || text.contains("forecast") || text.contains("temperature") ||
            text.contains("atmospheric") || text.contains("mausam") || text.contains("barish") ||
            text.contains("मौसम") || text.contains("बारिश")) {
            val location = extractLocation(text)
            return ParsedJarvisCommand.Weather(location)
        }

        // PPT Generation: "create ppt on AI", "make presentation about Android", "generate slides for Kotlin"
        if (text.contains("ppt") || text.contains("presentation") || text.contains("slides") ||
            text.contains("powerpoint") || text.contains("slide deck") || text.contains("ppt banao") ||
            text.contains("प्रेजेंटेशन") || text.contains("स्लाइड")) {
            val (topic, template, slideCount) = extractPptDetails(text)
            return ParsedJarvisCommand.GeneratePpt(topic, slideCount, template)
        }

        // Developer Tools: "run code", "execute python", "dev tools", "terminal"
        if (text.contains("run code") || text.contains("execute code") || text.contains("run python") ||
            text.contains("execute python") || text.contains("dev tools") || text.contains("developer tools") ||
            text.contains("terminal") || text.contains("code runner") || text.contains("code chalao")) {
            return ParsedJarvisCommand.OpenAssistantScreen(7) // Developer tools screen index
        }

        // PPT Viewer: "show presentations", "my presentations", "open ppt", "view slides"
        if (text.contains("show presentation") || text.contains("my presentation") || text.contains("open ppt") ||
            text.contains("view presentation") || text.contains("list presentation") || text.contains("presentation dekh") ||
            text.contains("प्रेजेंटेशन दिखाओ") || text.contains("स्लाइड देखो")) {
            return ParsedJarvisCommand.OpenAssistantScreen(8) // PPT viewer screen index
        }

        // Email: "send email to tony@stark.com subject meeting body hello"
        if (text.contains("send email") || text.contains("email to") || text.contains("mail to") ||
            text.contains("bhejo email") || text.contains("ईमेल भेजो")) {
            val (to, subject, body) = extractEmailDetails(input)
            return ParsedJarvisCommand.SendEmail(to, subject, body)
        }

        // SMS: "send sms to 555-1234 hello", "text pepper message"
        if (text.contains("send sms") || text.contains("send text") || text.contains("text message") ||
            text.contains("sms bhejo") || text.contains("message bhejo") || text.contains("एसएमएस")) {
            val (to, body) = extractSmsDetails(input)
            return ParsedJarvisCommand.SendSms(to, body)
        }

        // Calendar: "create event meeting tomorrow 3pm", "add to calendar"
        if (text.contains("create event") || text.contains("add to calendar") || text.contains("schedule meeting") ||
            text.contains("calendar event") || text.contains("event banao") || text.contains("कैलेंडर")) {
            val (title, dateTime, description) = extractCalendarDetails(input)
            return ParsedJarvisCommand.CreateCalendarEvent(title, dateTime, description)
        }

        // Web Search: "search for quantum computing", "google AI news", "look up bitcoin price"
        if (text.startsWith("search ") || text.startsWith("google ") || text.startsWith("look up ") ||
            text.contains("search for") || text.contains("google search") || text.contains("web search") ||
            text.contains("search karein") || text.contains("ढूंढो")) {
            val query = extractSearchQuery(text)
            return ParsedJarvisCommand.SearchWeb(query)
        }

        // Translation: "translate hello to spanish", "translate this to french"
        if (text.contains("translate") || text.contains("translate to") || text.contains("anuvad") ||
            text.contains("अनुवाद")) {
            val (textToTranslate, targetLang) = extractTranslationDetails(input)
            return ParsedJarvisCommand.TranslateText(textToTranslate, targetLang)
        }

        // File Operations: "create file notes.txt", "read file config.json", "delete file temp.log"
        if (text.contains("create file") || text.contains("read file") || text.contains("delete file") ||
            text.contains("write file") || text.contains("file banao") || text.contains("file padho") ||
            text.contains("फाइल")) {
            val (operation, path, content) = extractFileOperation(text)
            return ParsedJarvisCommand.FileOperation(operation, path, content)
        }

        return ParsedJarvisCommand.GeneralQuery(input)
    }

    private fun extractPptTopic(text: String): String {
        val patterns = listOf(
            Regex("(?i)(?:ppt|presentation|slides?|powerpoint|slide deck)\\s+(?:on|about|for|topic)\\s+(.+)"),
            Regex("(?i)(?:create|make|generate|build)\\s+(?:a\\s+)?(?:ppt|presentation|slides?)\\s+(?:on|about|for)\\s+(.+)"),
            Regex("(?i)(?:ppt|presentation|slides?)\\s+banao\\s+(.+)"),
            Regex("(?i)(?:प्रेजेंटेशन|स्लाइड)\\s+(?:बनाओ|बनाइये)\\s+(.+)")
        )
        for (pattern in patterns) {
            val match = pattern.find(text)
            if (match != null) return match.groupValues[1].trim().capitalizeFirstLetter()
        }
        // Default: use the text after the keyword
        val keywords = listOf("ppt on", "presentation on", "slides on", "presentation about", "slides about", "ppt about", "ppt banao", "presentation banao")
        for (kw in keywords) {
            val idx = text.indexOf(kw)
            if (idx != -1 && idx + kw.length < text.length) {
                return text.substring(idx + kw.length).trim().capitalizeFirstLetter()
            }
        }
        return "General Topic"
    }

    private fun extractPptDetails(text: String): Triple<String, com.example.service.PptGenerationService.PptTemplate, Int> {
        val topic = extractPptTopic(text)
        val slideCount = extractSlideCount(text)
        val template = extractPptTemplate(text)
        return Triple(topic, template, slideCount)
    }

    private fun extractPptTemplate(text: String): com.example.service.PptGenerationService.PptTemplate {
        return when {
            text.contains("stark") || text.contains("industries") -> com.example.service.PptGenerationService.PptTemplate.STARK_INDUSTRIES
            text.contains("tactical") || text.contains("hud") -> com.example.service.PptGenerationService.PptTemplate.TACTICAL_HUD
            text.contains("minimal") || text.contains("light") -> com.example.service.PptGenerationService.PptTemplate.MINIMAL_LIGHT
            text.contains("hologram") || text.contains("holo") -> com.example.service.PptGenerationService.PptTemplate.HOLOGRAPHIC
            else -> com.example.service.PptGenerationService.PptTemplate.JARVIS_CLASSIC
        }
    }

    private fun extractSlideCount(text: String): Int {
        val pattern = Regex("(?i)(\\d+)\\s*(?:slides?|pages?)")
        val match = pattern.find(text)
        return match?.groupValues?.get(1)?.toIntOrNull() ?: 10
    }

    private fun extractEmailDetails(input: String): Triple<String, String, String> {
        val clean = input.replace(Regex("(?i)^(send email to|email to|mail to|bhejo email)\\s*"), "").trim()
        val subjectIndex = clean.indexOf(" subject ")
        val bodyIndex = clean.indexOf(" body ")
        var to = clean
        var subject = "No Subject"
        var body = ""
        if (subjectIndex != -1) {
            to = clean.substring(0, subjectIndex).trim()
            val afterSubject = clean.substring(subjectIndex + 9)
            if (bodyIndex != -1) {
                subject = afterSubject.substring(0, bodyIndex - subjectIndex - 9).trim()
                body = clean.substring(bodyIndex + 6).trim()
            } else {
                subject = afterSubject.trim()
            }
        }
        if (to.isBlank()) to = "recipient@example.com"
        return Triple(to, subject, body)
    }

    private fun extractSmsDetails(input: String): Pair<String, String> {
        val clean = input.replace(Regex("(?i)^(send sms to|send text to|text message to|sms bhejo|message bhejo)\\s*"), "").trim()
        val spaceIndex = clean.indexOf(" ")
        if (spaceIndex != -1) {
            val to = clean.substring(0, spaceIndex).trim()
            val body = clean.substring(spaceIndex + 1).trim()
            return Pair(to, if (body.isBlank()) "Message from JARVIS" else body)
        }
        return Pair(clean, "Message from JARVIS")
    }

    private fun extractCalendarDetails(input: String): Triple<String, String, String> {
        val clean = input.replace(Regex("(?i)^(create event|add to calendar|schedule meeting|calendar event|event banao)\\s*"), "").trim()
        // Simple parsing - in reality would need more sophisticated date parsing
        val title = clean.takeIf { it.isNotBlank() } ?: "New Event"
        return Triple(title, "Tomorrow 10:00 AM", "Created by JARVIS")
    }

    private fun extractSearchQuery(text: String): String {
        val patterns = listOf(
            Regex("(?i)^(search|google|look up|search for|google search|web search)\\s+(.+)"),
            Regex("(?i)(?:search|google|look up)\\s+karein\\s+(.+)"),
            Regex("(?i)(?:ढूंढो|खोजो)\\s+(.+)")
        )
        for (pattern in patterns) {
            val match = pattern.find(text)
            if (match != null) return match.groupValues[1].trim()
        }
        return text.trim()
    }

    private fun extractTranslationDetails(input: String): Pair<String, String> {
        val clean = input.replace(Regex("(?i)^(translate|anuvad)\\s*"), "").trim()
        val toIndex = clean.lastIndexOf(" to ")
        if (toIndex != -1) {
            val text = clean.substring(0, toIndex).trim()
            val lang = clean.substring(toIndex + 4).trim()
            return Pair(text, lang)
        }
        return Pair(clean, "Spanish")
    }

    private fun extractFileOperation(text: String): Triple<String, String, String?> {
        val operation = when {
            text.contains("create file") || text.contains("make file") || text.contains("file banao") -> "create"
            text.contains("read file") || text.contains("open file") || text.contains("file padho") -> "read"
            text.contains("delete file") || text.contains("remove file") -> "delete"
            text.contains("write file") || text.contains("save file") -> "write"
            else -> "create"
        }
        val pattern = Regex("(?i)file\\s+([\\w\\-.\\/]+)")
        val path = pattern.find(text)?.groupValues?.get(1) ?: "notes.txt"
        val content = if (operation == "write" || operation == "create") {
            val contentPattern = Regex("(?i)(?:with|content|containing)\\s+(.+)")
            contentPattern.find(text)?.groupValues?.get(1)
        } else null
        return Triple(operation, path, content)
    }

    private fun extractTimerSeconds(text: String): Int {
        var totalSec = 0
        // Minutes match
        val minPattern = Pattern.compile("(\\d+)\\s*(min|minute|minutes|m\\b)")
        val minMatcher = minPattern.matcher(text)
        if (minMatcher.find()) {
            val mins = minMatcher.group(1)?.toIntOrNull() ?: 0
            totalSec += mins * 60
        }

        // Seconds match
        val secPattern = Pattern.compile("(\\d+)\\s*(sec|second|seconds|s\\b)")
        val secMatcher = secPattern.matcher(text)
        if (secMatcher.find()) {
            val secs = secMatcher.group(1)?.toIntOrNull() ?: 0
            totalSec += secs
        }

        // Hour match
        val hrPattern = Pattern.compile("(\\d+)\\s*(hour|hours|hr|hrs|h\\b)")
        val hrMatcher = hrPattern.matcher(text)
        if (hrMatcher.find()) {
            val hrs = hrMatcher.group(1)?.toIntOrNull() ?: 0
            totalSec += hrs * 3600
        }

        if (totalSec == 0) {
            // Check standalone number: "timer 5" -> assume minutes
            val numPattern = Pattern.compile("timer\\s+(\\d+)")
            val numMatcher = numPattern.matcher(text)
            if (numMatcher.find()) {
                val num = numMatcher.group(1)?.toIntOrNull() ?: 0
                totalSec = num * 60
            }
        }

        return if (totalSec > 0) totalSec else 300 // default 5m
    }

    private fun extractTimerLabel(text: String): String {
        val forIndex = text.indexOf(" for ")
        return if (forIndex != -1 && forIndex + 5 < text.length) {
            text.substring(forIndex + 5).capitalizeFirstLetter()
        } else {
            "Countdown Timer"
        }
    }

    private fun extractReminderDetails(input: String): Pair<String, String> {
        val clean = input.replace(Regex("(?i)^(remind me to|set a reminder to|set reminder for|remind me)\\s*"), "").trim()
        val atIndex = clean.lastIndexOf(" at ")
        val tomorrowIndex = clean.lastIndexOf(" tomorrow")

        var title = clean
        var dueTime = "Today"

        if (atIndex != -1) {
            title = clean.substring(0, atIndex).trim()
            dueTime = clean.substring(atIndex + 4).trim()
        } else if (tomorrowIndex != -1) {
            title = clean.substring(0, tomorrowIndex).trim()
            dueTime = "Tomorrow"
        }

        if (title.isBlank()) title = "Important Task"
        return Pair(title.capitalizeFirstLetter(), dueTime)
    }

    private fun extractLocation(text: String): String {
        val inIndex = text.indexOf(" in ")
        val forIndex = text.indexOf(" for ")
        return when {
            inIndex != -1 && inIndex + 4 < text.length -> text.substring(inIndex + 4).trim().capitalizeFirstLetter()
            forIndex != -1 && forIndex + 5 < text.length -> text.substring(forIndex + 5).trim().capitalizeFirstLetter()
            else -> "Local City"
        }
    }

    private fun String.capitalizeFirstLetter(): String {
        return if (isEmpty()) this else this.substring(0, 1).uppercase() + this.substring(1)
    }

    private fun tryParseMath(rawText: String): ParsedJarvisCommand.MathCalculation? {
        val clean = rawText.lowercase()
            .replace("?", "")
            .replace("!", "")
            .replace("what is", "")
            .replace("what's", "")
            .replace("calculate", "")
            .replace("solve", "")
            .replace("tell me", "")
            .replace("how much is", "")
            .replace("kitna hoga", "")
            .replace("kya hoga", "")
            .trim()

        // Replace textual operator words with mathematical symbols
        val normalized = clean
            .replace("multiplied by", "*")
            .replace("times", "*")
            .replace("into", "*")
            .replace("guna", "*")
            .replace("गुणा", "*")
            .replace("divided by", "/")
            .replace("divide by", "/")
            .replace("over", "/")
            .replace("bhag", "/")
            .replace("भाग", "/")
            .replace("plus", "+")
            .replace("add", "+")
            .replace("jod", "+")
            .replace("जोड़", "+")
            .replace("minus", "-")
            .replace("ghata", "-")
            .replace("घटाओ", "-")
            .replace("x", "*")
            .trim()

        val mathRegex = Regex("^([0-9]+(?:\\.[0-9]+)?)\\s*([\\+\\-\\*/])\\s*([0-9]+(?:\\.[0-9]+)?)$")
        val match = mathRegex.find(normalized) ?: return null

        val num1 = match.groupValues[1].toDoubleOrNull() ?: return null
        val op = match.groupValues[2]
        val num2 = match.groupValues[3].toDoubleOrNull() ?: return null

        val calcResult: Double = when (op) {
            "+" -> num1 + num2
            "-" -> num1 - num2
            "*" -> num1 * num2
            "/" -> {
                if (num2 == 0.0) return ParsedJarvisCommand.MathCalculation(rawText, "Undefined division by zero, sir.")
                num1 / num2
            }
            else -> return null
        }

        // Format: integer results formatted cleanly as "100." per Jarvis style, decimals to 2-4 digits
        val formatted = if (calcResult % 1.0 == 0.0) {
            "${calcResult.toLong()}."
        } else {
            val rounded = String.format(Locale.getDefault(), "%.4f", calcResult).trimEnd('0').trimEnd('.')
            "$rounded."
        }

        return ParsedJarvisCommand.MathCalculation(expression = rawText, result = formatted)
    }

    private fun extractHologramMode(text: String): String {
        return when {
            text.contains("scan") || text.contains("scanning") || text.contains("स्कैन") -> "SCANNING"
            text.contains("process") || text.contains("processing") || text.contains("प्रोसेस") -> "PROCESSING"
            text.contains("project") || text.contains("projection") || text.contains("प्रोजेक्ट") -> "PROJECTING"
            text.contains("alert") || text.contains("tactical") || text.contains("अलर्ट") -> "ALERT"
            text.contains("comm") || text.contains("communication") || text.contains("कम्युनिकेशन") -> "COMMUNICATION"
            text.contains("idle") || text.contains("standby") || text.contains("stop") || text.contains("बंद") -> "IDLE"
            else -> "IDLE"
        }
    }
}
