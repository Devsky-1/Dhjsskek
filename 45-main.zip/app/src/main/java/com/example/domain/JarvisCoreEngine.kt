package com.example.domain

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import android.app.SearchManager
import com.example.audio.SpeechRecognizerHelper
import com.example.audio.SpeechState
import com.example.audio.TextToSpeechHelper
import com.example.data.api.GeminiClient
import com.example.data.db.ChatMessageEntity
import com.example.data.db.JarvisDatabase
import com.example.data.db.JarvisNoteEntity
import com.example.data.db.QuickCommandEntity
import com.example.data.db.ReminderEntity
import com.example.data.repository.AssistantAppearanceConfig
import com.example.data.repository.AssistantColorTheme
import com.example.data.repository.AssistantPersonality
import com.example.data.repository.AssistantPreferencesManager
import com.example.data.repository.AssistantShape
import com.example.data.repository.JarvisRepository
import com.example.device.ActiveTimer
import com.example.device.DeviceController
import com.example.device.DeviceTelemetry
import com.example.service.PptGenerationService
import com.example.ui.components.JarvisState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class JarvisCoreEngine private constructor(val context: Context) {

    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val database = JarvisDatabase.getDatabase(context, engineScope)
    val repository = JarvisRepository(database.jarvisDao())
    val preferencesManager = AssistantPreferencesManager(context)

    val deviceController = DeviceController(context, engineScope)
    val ttsHelper = TextToSpeechHelper(context)
    val speechHelper = SpeechRecognizerHelper(context)
    val wakeWordEngine = com.example.audio.WakeWordEngine(context)
    val pptGenerationService = PptGenerationService(context)

    val appearanceConfig: StateFlow<AssistantAppearanceConfig> = preferencesManager.configFlow
    val isAmbientWakeWordListening: StateFlow<Boolean> = wakeWordEngine.isAmbientListening

    // Data streams from Room
    val messages: StateFlow<List<ChatMessageEntity>> = repository.allMessages
        .stateIn(engineScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reminders: StateFlow<List<ReminderEntity>> = repository.allReminders
        .stateIn(engineScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<JarvisNoteEntity>> = repository.allNotes
        .stateIn(engineScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val quickCommands: StateFlow<List<QuickCommandEntity>> = repository.allQuickCommands
        .stateIn(engineScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Telemetry & Active Timers
    val telemetry: StateFlow<DeviceTelemetry> = deviceController.telemetry
    val activeTimers: StateFlow<List<ActiveTimer>> = deviceController.activeTimers

    // UI & Assistant State
    private val _jarvisState = MutableStateFlow(JarvisState.STANDBY)
    val jarvisState: StateFlow<JarvisState> = _jarvisState.asStateFlow()

    private val _currentQueryInput = MutableStateFlow("")
    val currentQueryInput: StateFlow<String> = _currentQueryInput.asStateFlow()

    private val _lastJarvisResponse = MutableStateFlow("At your service, sir.")
    val lastJarvisResponse: StateFlow<String> = _lastJarvisResponse.asStateFlow()

    private val _activeProtocol = MutableStateFlow("STANDARD PROTOCOL")
    val activeProtocol: StateFlow<String> = _activeProtocol.asStateFlow()

    val rmsAudioLevel: StateFlow<Float> = speechHelper.rmsAudioLevel
    val isTtsSpeaking: StateFlow<Boolean> = ttsHelper.isSpeaking
    val isMuted: StateFlow<Boolean> = ttsHelper.isMuted

    init {
        // Apply initial TTS & STT settings
        ttsHelper.setAssistantLanguage(appearanceConfig.value.voiceLanguage, appearanceConfig.value.selectedTtsVoiceName)
        ttsHelper.setPitch(appearanceConfig.value.speechPitch)
        ttsHelper.setSpeechRate(appearanceConfig.value.speechSpeed)
        if (appearanceConfig.value.selectedTtsVoiceName.isNotBlank()) {
            ttsHelper.setVoiceByName(appearanceConfig.value.selectedTtsVoiceName)
        }
        speechHelper.setAssistantLanguage(appearanceConfig.value.voiceLanguage)

        // Configure wake word
        wakeWordEngine.configure(
            wakeWord = appearanceConfig.value.effectiveWakeWord,
            enabled = appearanceConfig.value.wakeWordEnabled,
            language = appearanceConfig.value.voiceLanguage
        )

        // Start ambient wake word listener
        startAmbientWakeWordListener()

        // Observe TTS state to update visualizer & manage ambient wake word
        engineScope.launch {
            ttsHelper.isSpeaking.collect { speaking ->
                if (speaking && _jarvisState.value != JarvisState.LISTENING) {
                    _jarvisState.value = JarvisState.SPEAKING
                    wakeWordEngine.pause()
                } else if (!speaking && _jarvisState.value == JarvisState.SPEAKING) {
                    _jarvisState.value = JarvisState.STANDBY
                    wakeWordEngine.resume()
                }
            }
        }

        // Observe speech recognition state
        engineScope.launch {
            speechHelper.speechState.collect { state ->
                when (state) {
                    is SpeechState.Listening -> {
                        _jarvisState.value = JarvisState.LISTENING
                        wakeWordEngine.pause()
                    }
                    is SpeechState.PartialResult -> {
                        _currentQueryInput.value = state.text
                    }
                    is SpeechState.FinalResult -> {
                        _currentQueryInput.value = state.text
                        processUserQuery(state.text)
                    }
                    is SpeechState.Error -> {
                        _jarvisState.value = JarvisState.STANDBY
                        wakeWordEngine.resume()
                    }
                    SpeechState.Idle -> {
                        if (_jarvisState.value == JarvisState.LISTENING) {
                            _jarvisState.value = JarvisState.STANDBY
                            wakeWordEngine.resume()
                        }
                    }
                }
            }
        }

        // Dynamic config observer
        engineScope.launch {
            appearanceConfig.collect { config ->
                ttsHelper.setAssistantLanguage(config.voiceLanguage, config.selectedTtsVoiceName)
                ttsHelper.setPitch(config.speechPitch)
                ttsHelper.setSpeechRate(config.speechSpeed)
                if (config.selectedTtsVoiceName.isNotBlank()) {
                    ttsHelper.setVoiceByName(config.selectedTtsVoiceName)
                }
                speechHelper.setAssistantLanguage(config.voiceLanguage)
                wakeWordEngine.configure(
                    wakeWord = config.effectiveWakeWord,
                    enabled = config.wakeWordEnabled,
                    language = config.voiceLanguage
                )
            }
        }

        // Auto re-listen on continuous conversation after speech completes
        ttsHelper.onSpeechCompleted = {
            if (appearanceConfig.value.continuousVoiceConversation && !isMuted.value) {
                engineScope.launch {
                    kotlinx.coroutines.delay(400)
                    if (_jarvisState.value == JarvisState.STANDBY) {
                        deviceController.vibrateHaptic(30)
                        speechHelper.startListening(
                            language = appearanceConfig.value.voiceLanguage,
                            onResult = { spokenText ->
                                processUserQuery(spokenText)
                            },
                            onError = {
                                _jarvisState.value = JarvisState.STANDBY
                                wakeWordEngine.resume()
                            }
                        )
                    }
                }
            } else {
                wakeWordEngine.resume()
            }
        }
    }

    private fun startAmbientWakeWordListener() {
        wakeWordEngine.startAmbientListening { command ->
            engineScope.launch(Dispatchers.Main) {
                if (appearanceConfig.value.wakeHapticFeedback) {
                    deviceController.vibrateHaptic(60)
                }

                // Show only the selected floating shape from Studio (like Siri) - no full-screen window!
                try {
                    com.example.service.JarvisFloatingOverlayService.activateFromWakeWord(context, command)
                } catch (_: Exception) {}

                if (!command.isNullOrBlank()) {
                    // Spoken command attached directly after wake word (e.g. "Hey Jarvis turn on flashlight")
                    _currentQueryInput.value = command
                    processUserQuery(command)
                } else {
                    // Wake word triggered alone ("Hey Jarvis") -> transition into active listening
                    _jarvisState.value = JarvisState.LISTENING
                    val wakeGreeting = when (appearanceConfig.value.voiceLanguage) {
                        com.example.data.repository.AssistantLanguage.HINDI ->
                            "नमस्ते सर, मैं सुन रहा हूँ। आज्ञा दीजिए।"
                        com.example.data.repository.AssistantLanguage.HINGLISH ->
                            "Haan ji Sir, main sun raha hoon. Boliye!"
                        com.example.data.repository.AssistantLanguage.ENGLISH -> when (appearanceConfig.value.personality) {
                            AssistantPersonality.JARVIS_AI -> "Online, sir. How may I assist?"
                            AssistantPersonality.SIRI_PRO -> "I'm listening."
                            AssistantPersonality.PRO_EXECUTIVE -> "Ready. Go ahead."
                        }
                    }
                    ttsHelper.speak(wakeGreeting)
                }
            }
        }
    }

    fun triggerWakeWordTest(customWord: String? = null) {
        val word = customWord ?: appearanceConfig.value.effectiveWakeWord
        deviceController.vibrateHaptic(70)
        wakeWordEngine.playActivationChime()
        val reply = when (appearanceConfig.value.voiceLanguage) {
            com.example.data.repository.AssistantLanguage.HINDI ->
                "वेक वर्ड '$word' सफलतापूर्वक कैलिब्रेट हो गया है, सर। माइक्रोफोन सेंसर्स सक्रिय हैं।"
            com.example.data.repository.AssistantLanguage.HINGLISH ->
                "Wake word '$word' perfectly calibrate ho gaya hai Sir! System ekdum alert aur active hai."
            com.example.data.repository.AssistantLanguage.ENGLISH ->
                "Wake word '$word' verified and calibrated successfully, sir. Ambient acoustic sensors are operational."
        }
        engineScope.launch(Dispatchers.Main) {
            ttsHelper.speak(reply)
        }
    }

    fun setQueryInput(text: String) {
        _currentQueryInput.value = text
    }

    fun toggleVoiceRecognition(onComplete: ((String) -> Unit)? = null) {
        if (_jarvisState.value == JarvisState.LISTENING) {
            speechHelper.stopListening()
            _jarvisState.value = JarvisState.STANDBY
        } else {
            ttsHelper.stop()
            deviceController.vibrateHaptic(50)
            speechHelper.startListening(
                onResult = { spokenText ->
                    processUserQuery(spokenText, onComplete)
                },
                onError = {
                    _jarvisState.value = JarvisState.STANDBY
                }
            )
        }
    }

    fun startListeningForAssist(onResult: (String) -> Unit, onError: (String) -> Unit) {
        ttsHelper.stop()
        deviceController.vibrateHaptic(50)
        speechHelper.startListening(
            onResult = { spokenText ->
                _currentQueryInput.value = spokenText
                processUserQuery(spokenText)
                onResult(spokenText)
            },
            onError = { err ->
                _jarvisState.value = JarvisState.STANDBY
                onError(err)
            }
        )
    }

    fun toggleMute() {
        ttsHelper.toggleMute()
        deviceController.vibrateHaptic(30)
    }

    fun submitCurrentQuery() {
        val query = _currentQueryInput.value.trim()
        if (query.isNotBlank()) {
            processUserQuery(query)
            _currentQueryInput.value = ""
        }
    }

    fun processUserQuery(query: String, onResponseReady: ((String) -> Unit)? = null) {
        if (query.isBlank()) return
        _jarvisState.value = JarvisState.PROCESSING
        deviceController.vibrateHaptic(30)

        engineScope.launch(Dispatchers.IO) {
            // Save user message to Room DB
            repository.saveMessage(sender = "USER", text = query)

            // Parse command intent
            val command = JarvisCommandParser.parse(query)
            executeParsedCommand(command, query, onResponseReady)
        }
    }

    private suspend fun executeParsedCommand(
        command: ParsedJarvisCommand,
        rawQuery: String,
        onResponseReady: ((String) -> Unit)? = null
    ) {
        val lang = appearanceConfig.value.voiceLanguage

        when (command) {
            is ParsedJarvisCommand.StopSpeaking -> {
                ttsHelper.stop()
                _jarvisState.value = JarvisState.STANDBY
                wakeWordEngine.resume()
                deviceController.vibrateHaptic(35)
                onResponseReady?.invoke("")
            }

            is ParsedJarvisCommand.TimeQuery -> {
                val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "अभी समय $timeFormat हुआ है, सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "Abhi time $timeFormat hai Sir."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "The time is exactly $timeFormat, sir."
                }
                respondAsJarvis(reply, actionType = "TIME", actionPayload = timeFormat, onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.DateQuery -> {
                val dateFormat = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(Date())
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "आज की तारीख $dateFormat है, सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "Aaj ki date $dateFormat hai Sir."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "Today is $dateFormat, sir."
                }
                respondAsJarvis(reply, actionType = "DATE", actionPayload = dateFormat, onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.OpenApp -> {
                val launched = deviceController.openApp(command.appName, command.packageName)
                val reply = if (launched) {
                    when (lang) {
                        com.example.data.repository.AssistantLanguage.HINDI ->
                            "${command.appName} खोला जा रहा है, सर।"
                        com.example.data.repository.AssistantLanguage.HINGLISH ->
                            "${command.appName} open kar raha hoon Sir!"
                        com.example.data.repository.AssistantLanguage.ENGLISH ->
                            "Launching ${command.appName}, sir."
                    }
                } else {
                    when (lang) {
                        com.example.data.repository.AssistantLanguage.HINDI ->
                            "${command.appName} खोलने में असमर्थ, कृपया जांचें कि यह इंस्टॉल है।"
                        com.example.data.repository.AssistantLanguage.HINGLISH ->
                            "${command.appName} nahi mila Sir, please check if installed."
                        com.example.data.repository.AssistantLanguage.ENGLISH ->
                            "Unable to locate or launch ${command.appName} on this system, sir."
                    }
                }
                respondAsJarvis(reply, actionType = "OPEN_APP", actionPayload = command.appName, onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.GoHome -> {
                deviceController.goHome()
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "होम स्क्रीन पर जा रहे हैं, सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "Home screen par switch kar raha hoon Sir!"
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "Returning to home screen, sir."
                }
                respondAsJarvis(reply, actionType = "HOME", onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.OpenAssistantScreen -> {
                val reply = when (command.tabIndex) {
                    1 -> when (lang) {
                        com.example.data.repository.AssistantLanguage.HINDI -> "जार्विस सेटिंग्स खोली जा रही हैं, सर।"
                        com.example.data.repository.AssistantLanguage.HINGLISH -> "Jarvis Settings open kar raha hoon Sir."
                        com.example.data.repository.AssistantLanguage.ENGLISH -> "Opening Assistant customization studio, sir."
                    }
                    3 -> when (lang) {
                        com.example.data.repository.AssistantLanguage.HINDI -> "सिस्टम टेलीमेट्री और डायग्नोस्टिक्स स्क्रीन खुली, सर।"
                        com.example.data.repository.AssistantLanguage.HINGLISH -> "Live system diagnostics screen open kar raha hoon Sir."
                        com.example.data.repository.AssistantLanguage.ENGLISH -> "Opening live system telemetry and hardware diagnostics grid, sir."
                    }
                    4 -> when (lang) {
                        com.example.data.repository.AssistantLanguage.HINDI -> "मेमोरी मैट्रिक्स खोली जा रही है, सर।"
                        com.example.data.repository.AssistantLanguage.HINGLISH -> "Memory Matrix vault open ho raha hai Sir."
                        com.example.data.repository.AssistantLanguage.ENGLISH -> "Opening encrypted memory matrix and agenda archives, sir."
                    }
                    2 -> when (lang) {
                        com.example.data.repository.AssistantLanguage.HINDI -> "एम्बिएंट लॉक स्क्रीन सक्रिय, सर।"
                        com.example.data.repository.AssistantLanguage.HINGLISH -> "Lock screen ambient mode activate ho raha hai Sir."
                        com.example.data.repository.AssistantLanguage.ENGLISH -> "Engaging tactical ambient lock screen HUD, sir."
                    }
                    5 -> when (lang) {
                        com.example.data.repository.AssistantLanguage.HINDI -> "होलोग्राफिक चैंबर सक्रिय, सर। त्रि-आयामी प्रोजेक्शन मैट्रिक्स ऑनलाइन।"
                        com.example.data.repository.AssistantLanguage.HINGLISH -> "Holographic Chamber active Sir! 3D projection matrix online."
                        com.example.data.repository.AssistantLanguage.ENGLISH -> "Holographic Chamber engaged, sir. Tri-dimensional projection matrix initialized."
                    }
                    6 -> when (lang) {
                        com.example.data.repository.AssistantLanguage.HINDI -> "होलोग्राफिक चैंबर सक्रिय, सर। त्रि-आयामी प्रोजेक्शन मैट्रिक्स ऑनलाइन।"
                        com.example.data.repository.AssistantLanguage.HINGLISH -> "Holographic Chamber active Sir! 3D projection matrix online."
                        com.example.data.repository.AssistantLanguage.ENGLISH -> "Holographic Chamber engaged, sir. Tri-dimensional projection matrix initialized."
                    }
                    7 -> when (lang) {
                        com.example.data.repository.AssistantLanguage.HINDI -> "डेवलपर टूल्स सक्रिय, सर। कोड एक्सीक्यूशन एनवायरनमेंट तैयार है।"
                        com.example.data.repository.AssistantLanguage.HINGLISH -> "Developer tools active Sir! Code execution environment ready."
                        com.example.data.repository.AssistantLanguage.ENGLISH -> "Developer tools engaged, sir. Code execution environment initialized."
                    }
                    8 -> when (lang) {
                        com.example.data.repository.AssistantLanguage.HINDI -> "प्रेजेंटेशन लाइब्रेरी खुली, सर। सभी जनरेटेड स्लाइड्स यहाँ उपलब्ध हैं।"
                        com.example.data.repository.AssistantLanguage.HINGLISH -> "Presentation library open Sir! Saare generated slides yahan hain."
                        com.example.data.repository.AssistantLanguage.ENGLISH -> "Presentation library accessed, sir. All generated slides available for review."
                    }
                    else -> "Opening requested screen, sir."
                }
                respondAsJarvis(reply, actionType = "NAVIGATE", actionPayload = "${command.tabIndex}", onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.MathCalculation -> {
                respondAsJarvis(command.result, actionType = "CALCULATION", actionPayload = command.expression, onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.Flashlight -> {

                val success = deviceController.setFlashlight(command.enable)
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        if (command.enable) "टॉर्च चालू कर दी गई है, सर। रोशनी सक्रिय है।" else "टॉर्च बंद कर दी गई है, सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        if (command.enable) "Tactical flashlight on kar di gayi hai Sir! Full illumination active." else "Flashlight band kar di gayi hai Sir."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        if (command.enable) "Illumination protocol engaged, sir. Tactical LED emitter activated." else "Flashlight powered down, sir. Systems returning to ambient standby."
                }
                respondAsJarvis(reply, actionType = "FLASHLIGHT", actionPayload = if (command.enable) "ON" else "OFF", onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.Timer -> {
                deviceController.startTimer(command.seconds, command.label)
                val minutes = command.seconds / 60
                val secs = command.seconds % 60
                val durationText = when {
                    minutes > 0 && secs > 0 -> "$minutes minutes and $secs seconds"
                    minutes > 0 -> "$minutes minutes"
                    else -> "$secs seconds"
                }
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "$durationText का टाइमर '${command.label}' के लिए शुरू कर दिया गया है, सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "$durationText ka countdown timer set ho gaya hai Sir! Time complete hone par alert kar doonga."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "Timer initialized for $durationText under '${command.label}', sir. I will alert you upon countdown completion."
                }
                respondAsJarvis(reply, actionType = "TIMER", actionPayload = "${command.seconds}", onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.Reminder -> {
                repository.addReminder(command.title, command.dueTime, command.priority)
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "रिमाइंडर मेमोरी में दर्ज कर लिया गया है: '${command.title}', ${command.dueTime} के लिए, सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "Reminder log ho gaya hai: '${command.title}', schedule time ${command.dueTime} hai Sir."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "Reminder logged to memory matrix: '${command.title}' scheduled for ${command.dueTime}, sir."
                }
                respondAsJarvis(reply, actionType = "REMINDER", actionPayload = command.title, onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.Note -> {
                repository.addNote(command.title, command.content)
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "नोट सुरक्षित कर लिया गया है: '${command.title}', सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "Note encrypted archives mein save ho gaya hai: '${command.title}', Sir."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "Note secured in encrypted archives: '${command.title}', sir."
                }
                respondAsJarvis(reply, actionType = "NOTE", actionPayload = command.content, onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.DailyBriefing -> {
                val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
                val dateFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())
                val battery = telemetry.value.batteryLevel
                val pendingReminders = reminders.value.count { !it.isCompleted }
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "शुभ दिवस सर। समय $timeFormat हुआ है, $dateFormat। बैटरी $battery% है, मौसम 24°C के साथ अनुकूल है, और आपके $pendingReminders रिमाइंडर बाकी हैं।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "Good day Sir! Abhi time $timeFormat hai, $dateFormat. Battery level $battery% pe hai aur weather 24°C clear hai. Aapke $pendingReminders reminders scheduled hain."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "Good day, sir. It is $timeFormat on $dateFormat. Power levels are at $battery%. Weather is clear at 24°C. You have $pendingReminders scheduled reminders in your agenda. All defense grids are nominal."
                }
                respondAsJarvis(reply, actionType = "BRIEFING", onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.Diagnostic -> {
                val t = telemetry.value
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "सिस्टम रिपोर्ट, सर: बैटरी ${t.batteryLevel}% (${if (t.isCharging) "चार्जिंग" else "डिस्चार्जिंग"}), रैम उपयोग ${t.ramUsagePercent}%, फ्री स्टोरेज ${String.format(Locale.getDefault(), "%.1f", t.storageFreeGb)}GB उपलब्ध, और नेटवर्क स्थिति ${t.networkStatus} है।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "System Diagnostic Report Sir: Battery ${t.batteryLevel}% (${if (t.isCharging) "Charging" else "On Battery"}), RAM usage ${t.ramUsagePercent}%, Free Space ${String.format(Locale.getDefault(), "%.1f", t.storageFreeGb)}GB, aur network connection ${t.networkStatus} hai."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "System Diagnostic Report, sir: Core battery at ${t.batteryLevel}% (${if (t.isCharging) "Charging" else "Discharging"}), RAM allocation at ${t.ramUsagePercent}% (${t.ramUsedMb}MB of ${t.ramTotalMb}MB), Flash storage with ${String.format(Locale.getDefault(), "%.1f", t.storageFreeGb)}GB available, and Network link is ${t.networkStatus}."
                }
                respondAsJarvis(reply, actionType = "DIAGNOSTIC", onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.Protocol -> {
                _activeProtocol.value = command.protocolName.uppercase()
                val reply = when (command.protocolName) {
                    "House Party Protocol" -> {
                        _jarvisState.value = JarvisState.ALERT
                        if (lang == com.example.data.repository.AssistantLanguage.HINDI) "हाउस पार्टी प्रोटोकॉल अधिकृत, सर। सभी यूनिट्स सक्रिय कर दी गई हैं।"
                        else if (lang == com.example.data.repository.AssistantLanguage.HINGLISH) "House Party Protocol authorized Sir! Sabhi units aapke location pe deploy ho rahi hain."
                        else "House Party Protocol authorized, sir. All automated secondary combat units dispatched to your coordinates."
                    }
                    "Stealth Mode" -> {
                        ttsHelper.stop()
                        if (lang == com.example.data.repository.AssistantLanguage.HINDI) "स्टेल्थ मोड सक्रिय, सर। ऑडियो शांत कर दिया गया है।"
                        else if (lang == com.example.data.repository.AssistantLanguage.HINGLISH) "Stealth mode active Sir. Audio telemetry suppress ho gaya hai."
                        else "Stealth mode engaged, sir. Audio telemetry suppressed, visual signature reduced."
                    }
                    "Perimeter Defense Grid" -> {
                        if (lang == com.example.data.repository.AssistantLanguage.HINDI) "सुरक्षा घेरा ग्रिड सक्रिय, सर। सेंसर्स पूरी क्षमता पर हैं।"
                        else if (lang == com.example.data.repository.AssistantLanguage.HINGLISH) "Perimeter defense grid online Sir! Sensors scanning range maximum pe hai."
                        else "Perimeter Defense Grid online, sir. Sentry scanners sweep radius set to maximum."
                    }
                    else -> {
                        if (lang == com.example.data.repository.AssistantLanguage.HINDI) "प्रोटोकॉल ${command.protocolName} निष्पादित, सर।"
                        else if (lang == com.example.data.repository.AssistantLanguage.HINGLISH) "Protocol ${command.protocolName} execute ho gaya Sir."
                        else "Protocol ${command.protocolName} executed, sir. Subsystems aligned."
                    }
                }
                respondAsJarvis(reply, actionType = "PROTOCOL", actionPayload = command.protocolName, onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.Weather -> {
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "${command.location} में मौसम: 22°C, आसमान साफ और 48% आर्द्रता है, सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "${command.location} mein weather conditions: 22°C, mostly clear sky aur halki hawa chal rahi hai Sir."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "Atmospheric conditions in ${command.location}: 22°C, mostly clear with 12 km/h westerly winds, 48% humidity. Optimal flight conditions, sir."
                }
                respondAsJarvis(reply, actionType = "WEATHER", actionPayload = command.location, onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.ClearHistory -> {
                repository.clearHistory()
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "मेमोरी बफ़र्स पूरी तरह साफ कर दिए गए हैं, सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "Memory buffers clear ho gaye hain Sir. Clean slate protocol complete!"
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "Memory buffers purged, sir. Clean slate protocol completed."
                }
                respondAsJarvis(reply, actionType = "CLEAR", onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.FireRepulsor -> {
                deviceController.setFlashlight(true)
                deviceController.vibrateHaptic(250)
                kotlinx.coroutines.delay(150)
                deviceController.setFlashlight(false)
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI -> "रिपल्सर पूरी क्षमता से डिस्चार्ज हुआ, सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH -> "Repulsor blast fired at maximum capacity Sir!"
                    com.example.data.repository.AssistantLanguage.ENGLISH -> "Repulsor beam discharged at 100% capacity, sir. Recoil stabilized."
                }
                respondAsJarvis(reply, actionType = "REPULSOR_FIRE", onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.IronManProtocol -> {
                val reply = when (command.protocolType) {
                    "VERONICA" -> "Veronica orbital support module deployed from low-Earth orbit, sir. Mark XLIV Hulkbuster exo-frame locking onto your coordinates."
                    "HOUSE_PARTY" -> "House Party Protocol authorized, sir. All autonomous secondary Mark combat units airborne and converging on target."
                    "SENTRY_ARM" -> "Perimeter Sentry Mode armed, sir. Device motion tripwire calibrated. Any movement will trigger repulsor defensive countermeasures."
                    "SENTRY_DISARM" -> "Sentry Mode disarmed, sir. Standing down perimeter defenses."
                    "OVERCLOCK" -> "Arc Reactor power output overclocked to 12.8 Gigawatts, sir. Maximum energy routed to primary repulsor emitters."
                    "SUIT_STATUS" -> "Mark LXXXV Diagnostic Report, sir: Arc Reactor output at 3.2 GW, power routing nominal. Armor nanotech integrity 100% nominal."
                    else -> "Protocol ${command.protocolType} executed, sir."
                }
                respondAsJarvis(reply, actionType = "IRON_MAN_PROTOCOL", actionPayload = command.protocolType, onResponseReady = onResponseReady)
            }

            is ParsedJarvisCommand.GeneratePpt -> {
                val templateName = command.template.name
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "प्रेजेंटेशन '${command.topic}' पर बनाई जा रही है, सर। ${command.slideCount} स्लाइड्स के साथ। टेम्पलेट: $templateName"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "Presentation '${command.topic}' par ban rahi hai Sir! ${command.slideCount} slides ke saath. Template: $templateName"
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "Generating presentation on '${command.topic}' with ${command.slideCount} slides using ${command.template.description}, sir. Initializing PowerPoint matrices."
                }
                respondAsJarvis(reply, actionType = "GENERATE_PPT", actionPayload = command.topic, onResponseReady = onResponseReady)

                engineScope.launch(Dispatchers.IO) {
                    pptGenerationService.generatePptFromTopic(
                        topic = command.topic,
                        slideCount = command.slideCount,
                        template = command.template
                    ) { filePath, fileName ->
                        val doneReply = when (lang) {
                            com.example.data.repository.AssistantLanguage.HINDI ->
                                "प्रेजेंटेशन पूर्ण हुई, सर। '$fileName' डाउनलोड फोल्डर में सहेजी गई है।"
                            com.example.data.repository.AssistantLanguage.HINGLISH ->
                                "Presentation complete Sir! '$fileName' downloads mein save ho gayi hai."
                            com.example.data.repository.AssistantLanguage.ENGLISH ->
                                "Presentation compiled successfully, sir. '$fileName' saved to your Downloads/JARVIS_Presentations directory."
                        }
                        engineScope.launch(Dispatchers.Main) {
                            ttsHelper.speak(doneReply)
                            repository.saveMessage(sender = "JARVIS", text = doneReply, actionType = "PPT_COMPLETE", actionPayload = fileName)
                        }
                    } onError = { error ->
                        val errorReply = when (lang) {
                            com.example.data.repository.AssistantLanguage.HINDI ->
                                "क्षमा करें सर, प्रेजेंटेशन बनाने में त्रुटि: $error"
                            com.example.data.repository.AssistantLanguage.HINGLISH ->
                                "Sorry Sir, presentation banane mein error aaya: $error"
                            com.example.data.repository.AssistantLanguage.ENGLISH ->
                                "Apologies, sir. Presentation generation encountered an error: $error"
                        }
                        engineScope.launch(Dispatchers.Main) {
                            ttsHelper.speak(errorReply)
                            repository.saveMessage(sender = "JARVIS", text = errorReply, actionType = "PPT_ERROR", actionPayload = error)
                        }
                    }
                }
            }

            is ParsedJarvisCommand.SendEmail -> {
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "ईमेल '${command.to}' को भेजी जा रही है: '${command.subject}', सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "Email bhej raha hoon '${command.to}' ko: '${command.subject}', Sir."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "Dispatching email to ${command.to} with subject '${command.subject}', sir."
                }
                respondAsJarvis(reply, actionType = "SEND_EMAIL", actionPayload = command.to, onResponseReady = onResponseReady)
                // TODO: Implement actual email sending via intent
                engineScope.launch(Dispatchers.Main) {
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:${command.to}")
                        putExtra(Intent.EXTRA_SUBJECT, command.subject)
                        putExtra(Intent.EXTRA_TEXT, command.body)
                    }
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        ttsHelper.speak("Unable to open email client, sir. Please check your configuration.")
                    }
                }
            }

            is ParsedJarvisCommand.SendSms -> {
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "SMS '${command.to}' को भेजा जा रहा है, सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "SMS bhej raha hoon '${command.to}' ko, Sir."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "Sending SMS to ${command.to}, sir."
                }
                respondAsJarvis(reply, actionType = "SEND_SMS", actionPayload = command.to, onResponseReady = onResponseReady)
                engineScope.launch(Dispatchers.Main) {
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("smsto:${command.to}")
                        putExtra("sms_body", command.body)
                    }
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        ttsHelper.speak("Unable to open messaging app, sir.")
                    }
                }
            }

            is ParsedJarvisCommand.CreateCalendarEvent -> {
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "कैलेंडर इवेंट '${command.title}' ${command.dateTime} के लिए निर्धारित, सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "Calendar event '${command.title}' schedule ho gaya ${command.dateTime} ke liye, Sir."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "Calendar event '${command.title}' scheduled for ${command.dateTime}, sir."
                }
                respondAsJarvis(reply, actionType = "CALENDAR_EVENT", actionPayload = command.title, onResponseReady = onResponseReady)
                engineScope.launch(Dispatchers.Main) {
                    val intent = Intent(Intent.ACTION_INSERT).apply {
                        data = android.provider.CalendarContract.Events.CONTENT_URI
                        putExtra(android.provider.CalendarContract.Events.TITLE, command.title)
                        putExtra(android.provider.CalendarContract.Events.DESCRIPTION, command.description)
                    }
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        ttsHelper.speak("Unable to open calendar, sir.")
                    }
                }
            }

            is ParsedJarvisCommand.SearchWeb -> {
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "वेब पर '${command.query}' खोज रहा हूँ, सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "Web pe '${command.query}' search kar raha hoon Sir."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "Searching the web for '${command.query}', sir. Engaging neural web crawlers."
                }
                respondAsJarvis(reply, actionType = "WEB_SEARCH", actionPayload = command.query, onResponseReady = onResponseReady)
                engineScope.launch(Dispatchers.Main) {
                    val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                        putExtra(android.app.SearchManager.QUERY, command.query)
                    }
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        val searchUrl = "https://www.google.com/search?q=${command.query.replace(" ", "+")}"
                        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(searchUrl))
                        browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(browserIntent)
                    }
                }
            }

            is ParsedJarvisCommand.TranslateText -> {
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "'${command.text}' का ${command.targetLanguage} में अनुवाद किया जा रहा है, सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "'${command.text}' ka ${command.targetLanguage} mein translation ho raha hai Sir."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "Translating '${command.text}' to ${command.targetLanguage}, sir."
                }
                respondAsJarvis(reply, actionType = "TRANSLATE", actionPayload = "${command.text} -> ${command.targetLanguage}", onResponseReady = onResponseReady)
                engineScope.launch(Dispatchers.Main) {
                    val url = "https://translate.google.com/?sl=auto&tl=${command.targetLanguage}&text=${Uri.encode(command.text)}"
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        ttsHelper.speak("Unable to open translator, sir.")
                    }
                }
            }

            is ParsedJarvisCommand.FileOperation -> {
                val reply = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI ->
                        "फाइल ऑपरेशन: ${command.operation} ${command.path}${command.content?.let { " - $it" } ?: ""}, सर।"
                    com.example.data.repository.AssistantLanguage.HINGLISH ->
                        "File operation: ${command.operation} ${command.path}${command.content?.let { " - $it" } ?: ""}, Sir."
                    com.example.data.repository.AssistantLanguage.ENGLISH ->
                        "File operation: ${command.operation} ${command.path}${command.content?.let { " with content" } ?: ""}, sir."
                }
                respondAsJarvis(reply, actionType = "FILE_OP", actionPayload = "${command.operation}:${command.path}", onResponseReady = onResponseReady)
                // TODO: Implement actual file operations using Storage Access Framework
            }

            is ParsedJarvisCommand.GeneralQuery -> {
                // Call Gemini API or fallback to smart Jarvis offline reasoning with selected language and personality
                val recentMessages = messages.value.takeLast(6).map { it.sender to it.text }
                val aiResult = GeminiClient.askJarvis(
                    userPrompt = command.query,
                    conversationHistory = recentMessages,
                    language = appearanceConfig.value.voiceLanguage,
                    personality = appearanceConfig.value.personality
                )
                val defaultFallback = when (lang) {
                    com.example.data.repository.AssistantLanguage.HINDI -> "निर्देश प्राप्त हुआ, सर। सभी प्रणालियाँ तत्पर हैं।"
                    com.example.data.repository.AssistantLanguage.HINGLISH -> "Samajh gaya Sir! Subroutines update ho gaye hain."
                    com.example.data.repository.AssistantLanguage.ENGLISH -> "Understood, sir. Subroutines updated."
                }
                val reply = aiResult.getOrDefault(defaultFallback)
                respondAsJarvis(reply, onResponseReady = onResponseReady)
            }
        }
    }

    private suspend fun respondAsJarvis(
        reply: String,
        actionType: String? = null,
        actionPayload: String? = null,
        onResponseReady: ((String) -> Unit)? = null
    ) {
        _lastJarvisResponse.value = reply
        repository.saveMessage(
            sender = "JARVIS",
            text = reply,
            actionType = actionType,
            actionPayload = actionPayload
        )

        engineScope.launch(Dispatchers.Main) {
            ttsHelper.speak(reply)
            onResponseReady?.invoke(reply)
        }
    }

    fun speakText(text: String) {
        engineScope.launch(Dispatchers.Main) {
            ttsHelper.speak(text)
        }
    }

    fun quickExecuteBriefing() {
        engineScope.launch {
            processUserQuery("status briefing")
        }
    }

    fun quickToggleFlashlight() {
        val newState = !deviceController.telemetry.value.isFlashlightOn
        deviceController.setFlashlight(newState)
        val reply = if (newState) "Tactical light activated, sir." else "Tactical light deactivated, sir."
        engineScope.launch(Dispatchers.Main) {
            ttsHelper.speak(reply)
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: JarvisCoreEngine? = null

        fun getInstance(context: Context): JarvisCoreEngine {
            return INSTANCE ?: synchronized(this) {
                val instance = JarvisCoreEngine(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
