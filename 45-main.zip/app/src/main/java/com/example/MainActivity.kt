package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.JarvisViewModel
import com.example.ui.automation.FlowBuilderScreen
import com.example.ui.developer.DeveloperConsoleScreen
import com.example.ui.screens.AssistantCustomizationScreen
import com.example.ui.screens.DeveloperToolsScreen
import com.example.ui.screens.HolographicChamberScreen
import com.example.ui.screens.IronManArmorHudScreen
import com.example.ui.screens.LockScreenOverlay
import com.example.ui.screens.MainAssistantScreen
import com.example.ui.screens.MemoryMatrixScreen
import com.example.ui.screens.PptViewerScreen
import com.example.ui.screens.SystemDiagnosticsScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: JarvisViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Enable show when locked and screen turn-on for Voice Assistant
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        setContent {
            MyApplicationTheme {
                JarvisApp(viewModel = viewModel)
            }
        }

        // Start background service for ambient wake word detection if enabled and permitted
        if (viewModel.appearanceConfig.value.wakeWordEnabled &&
            androidx.core.content.ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            try {
                com.example.service.JarvisBackgroundService.start(this)
            } catch (_: Exception) {}
        }
    }
}

@Composable
fun JarvisApp(viewModel: JarvisViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val isLockScreenActive by viewModel.isLockScreenActive.collectAsStateWithLifecycle()

    // Dynamic runtime microphone permission launcher
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted && viewModel.appearanceConfig.value.wakeWordEnabled) {
            try {
                com.example.service.JarvisBackgroundService.start(context)
            } catch (_: Exception) {}
        }
    }

    LaunchedEffect(Unit) {
        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing
        ) { _ ->
            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "screen_transition"
            ) { tab ->
                when (tab) {
                    0 -> MainAssistantScreen(
                        viewModel = viewModel,
                        onOpenSettings = { viewModel.setSelectedTab(1) },
                        onOpenDiagnostics = { viewModel.setSelectedTab(3) },
                        onOpenMemory = { viewModel.setSelectedTab(4) },
                        onOpenTacticalVisor = { viewModel.setSelectedTab(5) },
                        onOpenHoloChamber = { viewModel.setSelectedTab(6) },
                        onOpenDevTools = { viewModel.setSelectedTab(7) },
                        onOpenPptViewer = { viewModel.setSelectedTab(8) },
                        onOpenFlowBuilder = { viewModel.setSelectedTab(9) },
                        onOpenDevConsole = { viewModel.setSelectedTab(10) }
                    )
                    1 -> {
                        BackHandler {
                            viewModel.setSelectedTab(0)
                        }
                        AssistantCustomizationScreen(
                            viewModel = viewModel,
                            onNavigateBack = { viewModel.setSelectedTab(0) },
                            onNavigateToDiagnostics = { viewModel.setSelectedTab(3) },
                            onNavigateToMemory = { viewModel.setSelectedTab(4) },
                            onNavigateToTacticalVisor = { viewModel.setSelectedTab(5) },
                            onNavigateToHoloChamber = { viewModel.setSelectedTab(6) },
                            onNavigateToDevTools = { viewModel.setSelectedTab(7) },
                            onNavigateToPptViewer = { viewModel.setSelectedTab(8) },
                            onNavigateToFlowBuilder = { viewModel.setSelectedTab(9) },
                            onNavigateToDevConsole = { viewModel.setSelectedTab(10) }
                        )
                    }
                    2 -> {
                        BackHandler {
                            viewModel.setSelectedTab(0)
                        }
                        LockScreenOverlay(
                            viewModel = viewModel,
                            onDismiss = { viewModel.setSelectedTab(0) }
                        )
                    }
                    3 -> {
                        BackHandler {
                            viewModel.setSelectedTab(0)
                        }
                        SystemDiagnosticsScreen(
                            viewModel = viewModel,
                            onNavigateBack = { viewModel.setSelectedTab(0) }
                        )
                    }
                    4 -> {
                        BackHandler {
                            viewModel.setSelectedTab(0)
                        }
                        MemoryMatrixScreen(
                            viewModel = viewModel,
                            onNavigateBack = { viewModel.setSelectedTab(0) }
                        )
                    }
                    5 -> {
                        BackHandler {
                            viewModel.setSelectedTab(0)
                        }
                        IronManArmorHudScreen(
                            viewModel = viewModel,
                            onNavigateBack = { viewModel.setSelectedTab(0) }
                        )
                    }
                    6 -> {
                        BackHandler {
                            viewModel.setSelectedTab(0)
                        }
                        HolographicChamberScreen(
                            engine = viewModel,
                            onDismiss = { viewModel.setSelectedTab(0) }
                        )
                    }
                    7 -> {
                        BackHandler {
                            viewModel.setSelectedTab(0)
                        }
                        DeveloperToolsScreen(
                            engine = viewModel,
                            onDismiss = { viewModel.setSelectedTab(0) }
                        )
                    }
                    8 -> {
                        BackHandler {
                            viewModel.setSelectedTab(0)
                        }
                        PptViewerScreen(
                            engine = viewModel,
                            onDismiss = { viewModel.setSelectedTab(0) }
                        )
                    }
                    9 -> {
                        BackHandler {
                            viewModel.setSelectedTab(0)
                        }
                        FlowBuilderScreen(
                            onSave = { flow -> /* Save flow */ },
                            onTest = { flow -> /* Test flow */ }
                        )
                    }
                    10 -> {
                        BackHandler {
                            viewModel.setSelectedTab(0)
                        }
                        DeveloperConsoleScreen(
                            onDismiss = { viewModel.setSelectedTab(0) }
                        )
                    }
                    else -> MainAssistantScreen(
                        viewModel = viewModel,
                        onOpenSettings = { viewModel.setSelectedTab(1) },
                        onOpenDiagnostics = { viewModel.setSelectedTab(3) },
                        onOpenMemory = { viewModel.setSelectedTab(4) },
                        onOpenTacticalVisor = { viewModel.setSelectedTab(5) },
                        onOpenHoloChamber = { viewModel.setSelectedTab(6) },
                        onOpenDevTools = { viewModel.setSelectedTab(7) },
                        onOpenPptViewer = { viewModel.setSelectedTab(8) },
                        onOpenFlowBuilder = { viewModel.setSelectedTab(9) },
                        onOpenDevConsole = { viewModel.setSelectedTab(10) }
                    )
                }
            }
        }

        // Fullscreen lock screen ambient overlay modal if activated
        AnimatedVisibility(
            visible = isLockScreenActive,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            LockScreenOverlay(
                viewModel = viewModel,
                onDismiss = { viewModel.toggleLockScreenSimulator(false) }
            )
        }
    }
}
