package com.example.memory

import android.content.Context
import android.util.Log
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RawQuery
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SimpleSQLiteQuery
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

@Entity(tableName = "memory_chunks")
data class MemoryChunk(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val content: String,
    val embedding: ByteArray, // Serialized FloatArray
    val source: String, // "conversation", "document", "note", "web"
    val metadata: String, // JSON metadata
    val timestamp: Long = System.currentTimeMillis(),
    val importance: Float = 1.0f,
    val accessCount: Int = 0,
    val lastAccessed: Long = System.currentTimeMillis()
)

@Dao
interface MemoryChunkDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(chunk: MemoryChunk): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(chunks: List<MemoryChunk>)

    @Query("SELECT * FROM memory_chunks ORDER BY importance DESC, timestamp DESC LIMIT :limit")
    suspend fun getRecent(limit: Int): List<MemoryChunk>

    @Query("SELECT * FROM memory_chunks WHERE source = :source ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getBySource(source: String, limit: Int): List<MemoryChunk>

    @Query("SELECT * FROM memory_chunks WHERE content LIKE :query ORDER BY importance DESC LIMIT :limit")
    suspend fun searchText(query: String, limit: Int): List<MemoryChunk>

    @RawQuery
    suspend fun vectorSearch(query: SimpleSQLiteQuery): List<MemoryChunk>

    @Query("DELETE FROM memory_chunks WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM memory_chunks WHERE timestamp < :cutoff")
    suspend fun deleteOlderThan(cutoff: Long)

    @Query("UPDATE memory_chunks SET accessCount = accessCount + 1, lastAccessed = :now WHERE id = :id")
    suspend fun incrementAccess(id: Long, now: Long)

    @Query("SELECT COUNT(*) FROM memory_chunks")
    suspend fun getCount(): Int
}

@Database(entities = [MemoryChunk::class], version = 1, exportSchema = false)
abstract class MemoryDatabase : RoomDatabase() {
    abstract fun memoryChunkDao(): MemoryChunkDao
}

data class MemorySearchResult(
    val chunk: MemoryChunk,
    val similarity: Float,
    val matchedText: String
)

data class MemoryStats(
    val totalChunks: Int,
    val totalSizeKb: Long,
    val bySource: Map<String, Int>,
    val avgImportance: Float
)

class RagMemoryService @Inject constructor(
    private val context: Context
) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val database: MemoryDatabase by lazy {
        Room.databaseBuilder(context, MemoryDatabase::class.java, "jarvis_memory")
            .fallbackToDestructiveMigration()
            .build()
    }
    private val dao = database.memoryChunkDao()

    // In-memory vector index for fast similarity search
    private val vectorIndex = ConcurrentHashMap<Long, FloatArray>()
    private val embeddingDim = 384 // all-MiniLM-L6-v2 dimension

    private val _state = MutableStateFlow(MemoryState.UNINITIALIZED)
    val state: StateFlow<MemoryState> = _state.asStateFlow()

    private val _stats = MutableStateFlow<MemoryStats?>(null)
    val stats: StateFlow<MemoryStats?> = _stats.asStateFlow()

    private val _isIndexing = MutableStateFlow(false)
    val isIndexing: StateFlow<Boolean> = _isIndexing.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    enum class MemoryState {
        UNINITIALIZED, INITIALIZING, READY, INDEXING, ERROR
    }

    init {
        initializeIndex()
    }

    private fun initializeIndex() {
        scope.launch {
            _state.value = MemoryState.INITIALIZING
            try {
                rebuildVectorIndex()
                updateStats()
                _state.value = MemoryState.READY
            } catch (e: Exception) {
                Log.e("RagMemoryService", "Init failed", e)
                _state.value = MemoryState.ERROR
                _error.value = e.message
            }
        }
    }

    private fun rebuildVectorIndex() {
        _isIndexing.value = true
        scope.launch {
            try {
                vectorIndex.clear()
                val chunks = dao.getRecent(10000)
                for (chunk in chunks) {
                    val embedding = byteArrayToFloatArray(chunk.embedding)
                    if (embedding.size == embeddingDim) {
                        vectorIndex[chunk.id] = embedding
                    }
                }
                Log.d("RagMemoryService", "Vector index rebuilt with ${vectorIndex.size} entries")
            } catch (e: Exception) {
                Log.e("RagMemoryService", "Index rebuild failed", e)
            } finally {
                _isIndexing.value = false
            }
        }
    }

    fun addMemory(
        content: String,
        source: String = "conversation",
        metadata: String = "{}",
        importance: Float = 1.0f,
        embedding: FloatArray? = null
    ) {
        scope.launch {
            try {
                val emb = embedding ?: generateEmbedding(content)
                val chunk = MemoryChunk(
                    content = content,
                    embedding = floatArrayToByteArray(emb),
                    source = source,
                    metadata = metadata,
                    importance = importance
                )
                val id = dao.insert(chunk)
                vectorIndex[id] = emb
                updateStats()
            } catch (e: Exception) {
                Log.e("RagMemoryService", "Add memory failed", e)
            }
        }
    }

    fun addMemoriesBatch(contents: List<String>, source: String = "document", metadata: String = "{}") {
        scope.launch {
            _isIndexing.value = true
            try {
                val chunks = contents.map { content ->
                    val emb = generateEmbedding(content)
                    MemoryChunk(
                        content = content,
                        embedding = floatArrayToByteArray(emb),
                        source = source,
                        metadata = metadata,
                        importance = 1.0f
                    )
                }
                dao.insertAll(chunks)
                rebuildVectorIndex()
                updateStats()
            } catch (e: Exception) {
                Log.e("RagMemoryService", "Batch add failed", e)
            } finally {
                _isIndexing.value = false
            }
        }
    }

    fun searchSimilar(
        query: String,
        limit: Int = 5,
        minSimilarity: Float = 0.7f
    ): List<MemorySearchResult> {
        val queryEmbedding = generateEmbedding(query)
        return searchByEmbedding(queryEmbedding, limit, minSimilarity)
    }

    fun searchByEmbedding(
        embedding: FloatArray,
        limit: Int = 5,
        minSimilarity: Float = 0.7f
    ): List<MemorySearchResult> {
        val results = mutableListOf<MemorySearchResult>()
        
        for ((id, chunkEmbedding) in vectorIndex) {
            val similarity = cosineSimilarity(embedding, chunkEmbedding)
            if (similarity >= minSimilarity) {
                val chunk = dao.getRecent(10000).firstOrNull { it.id == id }
                chunk?.let {
                    results.add(MemorySearchResult(
                        chunk = it,
                        similarity = similarity,
                        matchedText = highlightMatch(it.content, queryEmbeddingToText(embedding))
                    ))
                }
            }
        }
        
        return results.sortedByDescending { it.similarity }.take(limit)
    }

    private fun queryEmbeddingToText(embedding: FloatArray): String {
        // This is a placeholder - in reality you'd need the original query text
        return ""
    }

    private fun highlightMatch(content: String, query: String): String {
        if (query.isBlank()) return content
        val words = query.toLowerCase().split(" ").filter { it.length > 2 }
        var highlighted = content
        for (word in words) {
            highlighted = highlighted.replace(
                Regex("(?i)($word)"),
                "<mark>$$1</mark>"
            )
        }
        return highlighted
    }

    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return 0f
        var dotProduct = 0f
        var normA = 0f
        var normB = 0f
        for (i in a.indices) {
            dotProduct += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        return if (normA > 0 && normB > 0) {
            dotProduct / (kotlin.math.sqrt(normA) * kotlin.math.sqrt(normB))
        } else 0f
    }

    fun getRecentMemories(limit: Int = 20): List<MemoryChunk> {
        return dao.getRecent(limit)
    }

    fun getMemoriesBySource(source: String, limit: Int = 50): List<MemoryChunk> {
        return dao.getBySource(source, limit)
    }

    fun searchText(query: String, limit: Int = 20): List<MemoryChunk> {
        return dao.searchText("%$query%", limit)
    }

    fun incrementAccess(id: Long) {
        scope.launch {
            dao.incrementAccess(id, System.currentTimeMillis())
        }
    }

    fun deleteMemory(id: Long) {
        scope.launch {
            dao.deleteById(id)
            vectorIndex.remove(id)
            updateStats()
        }
    }

    fun cleanupOldMemories(olderThanDays: Int = 30) {
        scope.launch {
            val cutoff = System.currentTimeMillis() - (olderThanDays * 24L * 60L * 60L * 1000L)
            dao.deleteOlderThan(cutoff)
            rebuildVectorIndex()
            updateStats()
        }
    }

    fun exportMemories(): String {
        val chunks = dao.getRecent(10000)
        return kotlinx.serialization.json.Json.encodeToString(chunks)
    }

    fun importMemories(json: String) {
        scope.launch {
            try {
                val chunks = kotlinx.serialization.json.Json.decodeFromString<List<MemoryChunk>>(json)
                dao.insertAll(chunks)
                rebuildVectorIndex()
                updateStats()
            } catch (e: Exception) {
                Log.e("RagMemoryService", "Import failed", e)
            }
        }
    }

    private fun updateStats() {
        scope.launch {
            try {
                val count = dao.getCount()
                val chunks = dao.getRecent(10000)
                val totalSize = chunks.sumOf { it.content.length + it.embedding.size } / 1024
                val bySource = chunks.groupBy { it.source }.mapValues { it.value.size }
                val avgImportance = if (chunks.isNotEmpty()) chunks.averageOf { it.importance } else 0f
                
                _stats.value = MemoryStats(
                    totalChunks = count,
                    totalSizeKb = totalSize,
                    bySource = bySource,
                    avgImportance = avgImportance
                )
            } catch (e: Exception) {
                Log.e("RagMemoryService", "Stats update failed", e)
            }
        }
    }

    // Embedding generation - using a simple hash-based approach for offline use
    // In production, use MediaPipe Text Embedder or ONNX Runtime with all-MiniLM-L6-v2
    private fun generateEmbedding(text: String): FloatArray {
        val words = text.toLowerCase()
            .split(Regex("\\W+"))
            .filter { it.length > 2 }
            .take(100)
        
        val embedding = FloatArray(embeddingDim)
        for (word in words) {
            val hash = word.hashCode()
            for (i in 0 until embeddingDim) {
                val seed = (hash * 31 + i).toLong()
                // Simple pseudo-random based on word hash
                val value = (seed * 1103515245 + 12345) % 2147483648
                embedding[i] += (value.toFloat() / 1073741824f - 1f) * 0.1f
            }
        }
        
        // Normalize
        var norm = 0f
        for (v in embedding) norm += v * v
        norm = kotlin.math.sqrt(norm)
        if (norm > 0) {
            for (i in embedding.indices) embedding[i] /= norm
        }
        return embedding
    }

    private fun floatArrayToByteArray(array: FloatArray): ByteArray {
        val buffer = java.nio.ByteBuffer.allocate(array.size * 4)
        buffer.order(java.nio.ByteOrder.LITTLE_ENDIAN)
        buffer.asFloatBuffer().put(array)
        return buffer.array()
    }

    private fun byteArrayToFloatArray(bytes: ByteArray): FloatArray {
        val buffer = java.nio.ByteBuffer.wrap(bytes)
        buffer.order(java.nio.ByteOrder.LITTLE_ENDIAN)
        val array = FloatArray(bytes.size / 4)
        buffer.asFloatBuffer().get(array)
        return array
    }

    fun getMemoryCount(): Int = dao.getCount()

    fun shutdown() {
        scope.coroutineContext.cancel()
        database.close()
    }

    companion object {
        private const val TAG = "RagMemoryService"
    }
}