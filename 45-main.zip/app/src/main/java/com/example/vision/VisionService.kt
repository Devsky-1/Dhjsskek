package com.example.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.media.Image
import android.util.Log
import android.util.Size
import com.google.mediapipe.tasks.components.containers.Category
import com.google.mediapipe.tasks.components.containers.Keypoint
import com.google.mediapipe.tasks.components.containers.NormalizedKeypoint
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facedetector.FaceDetector
import com.google.mediapipe.tasks.vision.facedetector.FaceDetectorOptions
import com.google.mediapipe.tasks.vision.facedetector.FaceDetectorResult
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerOptions
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetectorOptions
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetectorResult
import com.google.mediapipe.tasks.vision.poseLandmarker.PoseLandmarker
import com.google.mediapipe.tasks.vision.poseLandmarker.PoseLandmarkerOptions
import com.google.mediapipe.tasks.vision.poseLandmarker.PoseLandmarkerResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.nio.ByteBuffer

enum class VisionMode {
    OBJECT_DETECTION, HAND_TRACKING, FACE_DETECTION, POSE_ESTIMATION, ALL
}

data class DetectedObject(
    val label: String,
    val confidence: Float,
    val boundingBox: Rect,
    val categoryIndex: Int
)

data class HandLandmarks(
    val handIndex: Int,
    val landmarks: List<NormalizedKeypoint>,
    val handedness: String, // "Left" or "Right"
    val worldLandmarks: List<Keypoint>
)

data class FaceDetection(
    val boundingBox: Rect,
    val confidence: Float,
    val keypoints: List<com.google.mediapipe.tasks.components.containers.Keypoint>
)

data class PoseLandmarks(
    val landmarks: List<NormalizedKeypoint>,
    val worldLandmarks: List<Keypoint>
)

data class VisionResult(
    val objects: List<DetectedObject> = emptyList(),
    val hands: List<HandLandmarks> = emptyList(),
    val faces: List<FaceDetection> = emptyList(),
    val pose: PoseLandmarks? = null,
    val timestamp: Long = System.currentTimeMillis()
)

class VisionService @Inject constructor(
    private val context: Context
) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var objectDetector: ObjectDetector? = null
    private var handLandmarker: HandLandmarker? = null
    private var faceDetector: FaceDetector? = null
    private var poseLandmarker: PoseLandmarker? = null

    private val _state = MutableStateFlow(VisionState.UNINITIALIZED)
    val state: StateFlow<VisionState> = _state.asStateFlow()

    private val _latestResult = MutableStateFlow<VisionResult>(VisionResult())
    val latestResult: StateFlow<VisionResult> = _latestResult.asStateFlow()

    private val _fps = MutableStateFlow(0f)
    val fps: StateFlow<Float> = _fps.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private var isProcessing = false
    private var lastProcessTime = 0L
    private var frameCount = 0

    enum class VisionState {
        UNINITIALIZED, INITIALIZING, READY, PROCESSING, ERROR
    }

    init {
        initializeDetectors()
    }

    private fun initializeDetectors() {
        scope.launch {
            _state.value = VisionState.INITIALIZING
            try {
                initializeObjectDetector()
                initializeHandLandmarker()
                initializeFaceDetector()
                initializePoseLandmarker()
                _state.value = VisionState.READY
                Log.d("VisionService", "All detectors initialized")
            } catch (e: Exception) {
                Log.e("VisionService", "Init failed", e)
                _state.value = VisionState.ERROR
                _error.value = e.message
            }
        }
    }

    private fun initializeObjectDetector() {
        val options = ObjectDetectorOptions.builder()
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setMaxResults(10)
            .setScoreThreshold(0.5f)
            .setResultListener { result, image, timestamp ->
                onObjectDetectionResult(result, timestamp)
            }
            .build()
        
        objectDetector = ObjectDetector.createFromOptions(context, options)
    }

    private fun initializeHandLandmarker() {
        val options = HandLandmarkerOptions.builder()
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setResultListener { result, image, timestamp ->
                onHandLandmarkResult(result, timestamp)
            }
            .build()
        
        handLandmarker = HandLandmarker.createFromOptions(context, options)
    }

    private fun initializeFaceDetector() {
        val options = FaceDetectorOptions.builder()
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setMinDetectionConfidence(0.5f)
            .setMinSuppressionThreshold(0.3f)
            .setResultListener { result, image, timestamp ->
                onFaceDetectionResult(result, timestamp)
            }
            .build()
        
        faceDetector = FaceDetector.createFromOptions(context, options)
    }

    private fun initializePoseLandmarker() {
        val options = PoseLandmarkerOptions.builder()
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumPoses(1)
            .setMinPoseDetectionConfidence(0.5f)
            .setMinPosePresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setOutputSegmentationMasks(false)
            .setResultListener { result, image, timestamp ->
                onPoseLandmarkResult(result, timestamp)
            }
            .build()
        
        poseLandmarker = PoseLandmarker.createFromOptions(context, options)
    }

    private fun onObjectDetectionResult(result: ObjectDetectorResult, timestamp: Long) {
        val objects = result.detections.map { detection ->
            val category = detection.categories.firstOrNull()
            DetectedObject(
                label = category?.categoryName ?: "Unknown",
                confidence = category?.score ?: 0f,
                boundingBox = Rect(
                    detection.boundingBox.originX,
                    detection.boundingBox.originY,
                    detection.boundingBox.originX + detection.boundingBox.width,
                    detection.boundingBox.originY + detection.boundingBox.height
                ),
                categoryIndex = category?.index ?: -1
            )
        }
        updateResult { it.copy(objects = objects) }
    }

    private fun onHandLandmarkResult(result: HandLandmarkerResult, timestamp: Long) {
        val hands = result.handLandmarks.mapIndexed { index, landmarks ->
            val handedness = result.handedness[index].firstOrNull()?.categoryName ?: "Unknown"
            val worldLandmarks = result.handWorldLandmarks.getOrNull(index) ?: emptyList()
            HandLandmarks(
                handIndex = index,
                landmarks = landmarks,
                handedness = handedness,
                worldLandmarks = worldLandmarks
            )
        }
        updateResult { it.copy(hands = hands) }
    }

    private fun onFaceDetectionResult(result: FaceDetectorResult, timestamp: Long) {
        val faces = result.detections.map { detection ->
            FaceDetection(
                boundingBox = Rect(
                    detection.boundingBox.originX,
                    detection.boundingBox.originY,
                    detection.boundingBox.originX + detection.boundingBox.width,
                    detection.boundingBox.originY + detection.boundingBox.height
                ),
                confidence = detection.categories.firstOrNull()?.score ?: 0f,
                keypoints = detection.keypoints ?: emptyList()
            )
        }
        updateResult { it.copy(faces = faces) }
    }

    private fun onPoseLandmarkResult(result: PoseLandmarkerResult, timestamp: Long) {
        val pose = result.poseLandmarks.firstOrNull()?.let { landmarks ->
            val worldLandmarks = result.poseWorldLandmarks.firstOrNull() ?: emptyList()
            PoseLandmarks(landmarks = landmarks, worldLandmarks = worldLandmarks)
        }
        updateResult { it.copy(pose = pose) }
    }

    private fun updateResult(transform: (VisionResult) -> VisionResult) {
        val newResult = transform(_latestResult.value).copy(timestamp = System.currentTimeMillis())
        _latestResult.value = newResult
        calculateFps()
    }

    private fun calculateFps() {
        val now = System.currentTimeMillis()
        frameCount++
        if (now - lastProcessTime >= 1000) {
            _fps.value = frameCount.toFloat()
            frameCount = 0
            lastProcessTime = now
        }
    }

    fun processFrame(image: Image, rotationDegrees: Int = 0) {
        if (_state.value != VisionState.READY || isProcessing) return
        isProcessing = true
        _state.value = VisionState.PROCESSING

        val timestamp = System.currentTimeMillis()
        val mpImage = com.google.mediapipe.framework.image.MPImage.fromMediaImage(image)

        try {
            objectDetector?.detectAsync(mpImage, timestamp)
            handLandmarker?.detectAsync(mpImage, timestamp)
            faceDetector?.detectAsync(mpImage, timestamp)
            poseLandmarker?.detectAsync(mpImage, timestamp)
        } catch (e: Exception) {
            Log.e("VisionService", "Detection failed", e)
            _error.value = e.message
        } finally {
            isProcessing = false
            _state.value = VisionState.READY
        }
    }

    fun processBitmap(bitmap: Bitmap, rotationDegrees: Int = 0) {
        if (_state.value != VisionState.READY || isProcessing) return
        isProcessing = true
        _state.value = VisionState.PROCESSING

        val timestamp = System.currentTimeMillis()
        val mpImage = com.google.mediapipe.framework.image.MPImage.fromBitmap(bitmap)

        try {
            objectDetector?.detectAsync(mpImage, timestamp)
            handLandmarker?.detectAsync(mpImage, timestamp)
            faceDetector?.detectAsync(mpImage, timestamp)
            poseLandmarker?.detectAsync(mpImage, timestamp)
        } catch (e: Exception) {
            Log.e("VisionService", "Detection failed", e)
            _error.value = e.message
        } finally {
            isProcessing = false
            _state.value = VisionState.READY
        }
    }

    fun processByteBuffer(buffer: ByteBuffer, width: Int, height: Int, rotationDegrees: Int = 0) {
        if (_state.value != VisionState.READY || isProcessing) return
        isProcessing = true
        _state.value = VisionState.PROCESSING

        val timestamp = System.currentTimeMillis()
        val mpImage = com.google.mediapipe.framework.image.MPImage.fromByteBuffer(buffer, width, height)

        try {
            objectDetector?.detectAsync(mpImage, timestamp)
            handLandmarker?.detectAsync(mpImage, timestamp)
            faceDetector?.detectAsync(mpImage, timestamp)
            poseLandmarker?.detectAsync(mpImage, timestamp)
        } catch (e: Exception) {
            Log.e("VisionService", "Detection failed", e)
            _error.value = e.message
        } finally {
            isProcessing = false
            _state.value = VisionState.READY
        }
    }

    fun detectObjectsAsync(bitmap: Bitmap, onResult: (List<DetectedObject>) -> Unit) {
        scope.launch {
            try {
                val mpImage = com.google.mediapipe.framework.image.MPImage.fromBitmap(bitmap)
                val result = objectDetector?.detect(mpImage)
                val objects = result?.detections?.map { detection ->
                    val category = detection.categories.firstOrNull()
                    DetectedObject(
                        label = category?.categoryName ?: "Unknown",
                        confidence = category?.score ?: 0f,
                        boundingBox = Rect(
                            detection.boundingBox.originX,
                            detection.boundingBox.originY,
                            detection.boundingBox.originX + detection.boundingBox.width,
                            detection.boundingBox.originY + detection.boundingBox.height
                        ),
                        categoryIndex = category?.index ?: -1
                    )
                } ?: emptyList()
                onResult(objects)
            } catch (e: Exception) {
                Log.e("VisionService", "Async detection failed", e)
                onResult(emptyList())
            }
        }
    }

    fun detectHandsAsync(bitmap: Bitmap, onResult: (List<HandLandmarks>) -> Unit) {
        scope.launch {
            try {
                val mpImage = com.google.mediapipe.framework.image.MPImage.fromBitmap(bitmap)
                val result = handLandmarker?.detect(mpImage)
                val hands = result?.handLandmarks?.mapIndexed { index, landmarks ->
                    val handedness = result.handedness.getOrNull(index)?.firstOrNull()?.categoryName ?: "Unknown"
                    val worldLandmarks = result.handWorldLandmarks.getOrNull(index) ?: emptyList()
                    HandLandmarks(
                        handIndex = index,
                        landmarks = landmarks,
                        handedness = handedness,
                        worldLandmarks = worldLandmarks
                    )
                } ?: emptyList()
                onResult(hands)
            } catch (e: Exception) {
                Log.e("VisionService", "Async hand detection failed", e)
                onResult(emptyList())
            }
        }
    }

    fun detectFacesAsync(bitmap: Bitmap, onResult: (List<FaceDetection>) -> Unit) {
        scope.launch {
            try {
                val mpImage = com.google.mediapipe.framework.image.MPImage.fromBitmap(bitmap)
                val result = faceDetector?.detect(mpImage)
                val faces = result?.detections?.map { detection ->
                    FaceDetection(
                        boundingBox = Rect(
                            detection.boundingBox.originX,
                            detection.boundingBox.originY,
                            detection.boundingBox.originX + detection.boundingBox.width,
                            detection.boundingBox.originY + detection.boundingBox.height
                        ),
                        confidence = detection.categories.firstOrNull()?.score ?: 0f,
                        keypoints = detection.keypoints ?: emptyList()
                    )
                } ?: emptyList()
                onResult(faces)
            } catch (e: Exception) {
                Log.e("VisionService", "Async face detection failed", e)
                onResult(emptyList())
            }
        }
    }

    fun detectPoseAsync(bitmap: Bitmap, onResult: (PoseLandmarks?) -> Unit) {
        scope.launch {
            try {
                val mpImage = com.google.mediapipe.framework.image.MPImage.fromBitmap(bitmap)
                val result = poseLandmarker?.detect(mpImage)
                val pose = result?.poseLandmarks?.firstOrNull()?.let { landmarks ->
                    val worldLandmarks = result.poseWorldLandmarks.firstOrNull() ?: emptyList()
                    PoseLandmarks(landmarks = landmarks, worldLandmarks = worldLandmarks)
                }
                onResult(pose)
            } catch (e: Exception) {
                Log.e("VisionService", "Async pose detection failed", e)
                onResult(null)
            }
        }
    }

    fun getObjectsForLabel(label: String): List<DetectedObject> {
        return _latestResult.value.objects.filter { it.label.equals(label, ignoreCase = true) }
    }

    fun getHandedness(handedness: String): List<HandLandmarks> {
        return _latestResult.value.hands.filter { it.handedness.equals(handedness, ignoreCase = true) }
    }

    fun isHandOpen(hand: HandLandmarks): Boolean {
        // Check if fingertips are extended (y < wrist y for palm facing camera)
        val landmarks = hand.landmarks
        if (landmarks.size < 21) return false
        
        val wrist = landmarks[0]
        val fingertips = listOf(4, 8, 12, 16, 20) // Thumb, Index, Middle, Ring, Pinky tips
        
        var extendedCount = 0
        for (tipIndex in fingertips) {
            val tip = landmarks[tipIndex]
            if (tip.y < wrist.y) extendedCount++
        }
        return extendedCount >= 3
    }

    fun getHandGesture(hand: HandLandmarks): String {
        if (isHandOpen(hand)) return "OPEN"
        // Check for fist
        val landmarks = hand.landmarks
        if (landmarks.size < 21) return "UNKNOWN"
        
        val wrist = landmarks[0]
        val fingertips = listOf(4, 8, 12, 16, 20)
        
        var curledCount = 0
        for (tipIndex in fingertips) {
            val tip = landmarks[tipIndex]
            if (tip.y > wrist.y) curledCount++
        }
        return if (curledCount >= 4) "FIST" else "PARTIAL"
    }

    fun getIndexFingerTip(hand: HandLandmarks): NormalizedKeypoint? {
        return hand.landmarks.getOrNull(8)
    }

    fun getPinchDistance(hand: HandLandmarks): Float? {
        val landmarks = hand.landmarks
        if (landmarks.size < 21) return null
        
        val thumbTip = landmarks[4]
        val indexTip = landmarks[8]
        
        val dx = thumbTip.x - indexTip.x
        val dy = thumbTip.y - indexTip.y
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }

    fun shutdown() {
        scope.coroutineContext.cancel()
        objectDetector?.close()
        handLandmarker?.close()
        faceDetector?.close()
        poseLandmarker?.close()
    }

    companion object {
        private const val TAG = "VisionService"
    }
}