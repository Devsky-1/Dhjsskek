package com.example.ar

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.opengl.Matrix
import android.util.Log
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import com.google.ar.core.Anchor
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Camera
import com.google.ar.core.Config
import com.google.ar.core.Frame
import com.google.ar.core.HitResult
import com.google.ar.core.LightEstimate
import com.google.ar.core.Plane
import com.google.ar.core.PointCloud
import com.google.ar.core.Pose
import com.google.ar.core.Session
import com.google.ar.core.Trackable
import com.google.ar.core.TrackingState
import com.google.ar.sceneform.AnchorNode
import com.google.ar.sceneform.FrameTime
import com.google.ar.sceneform.Node
import com.google.ar.sceneform.Scene
import com.google.ar.sceneform.SceneView
import com.google.ar.sceneform.math.Quaternion
import com.google.ar.sceneform.math.Vector3
import com.google.ar.sceneform.rendering.Color
import com.google.ar.sceneform.rendering.MaterialFactory
import com.google.ar.sceneform.rendering.ModelRenderable
import com.google.ar.sceneform.rendering.Renderable
import com.google.ar.sceneform.rendering.ViewRenderable
import com.google.ar.sceneform.ux.ArFragment
import com.google.ar.sceneform.ux.TransformableNode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

enum class HologramType(
    val name: String,
    val description: String
) {
    ORB("Orb", "Floating AI core orb"),
    PANEL("Panel", "Holographic information panel"),
    MODEL_3D("3D Model", "Full 3D holographic model"),
    PARTICLES("Particles", "Particle effect visualization"),
    TEXT("Text", "Floating text display"),
    GRID("Grid", "Tactical grid overlay"),
    SCANNER("Scanner", "Scanning beam effect")
}

enum class ArSessionState {
    UNINITIALIZED, CHECKING_AVAILABILITY, REQUESTING_INSTALL, INITIALIZING, 
    READY, TRACKING, PAUSED, ERROR
}

data class HologramAnchor(
    val id: String,
    val type: HologramType,
    val anchor: Anchor,
    val node: Node,
    val position: Vector3,
    val rotation: Quaternion,
    val scale: Float = 1f,
    val isVisible: Boolean = true
)

class ArHolographicService @Inject constructor(
    private val context: Context
) : LifecycleObserver {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var session: Session? = null
    private var sceneView: SceneView? = null
    private var arFragment: ArFragment? = null

    private val holograms = ConcurrentHashMap<String, HologramAnchor>()
    private var isSessionConfigured = false

    private val _state = MutableStateFlow(ArSessionState.UNINITIALIZED)
    val state: StateFlow<ArSessionState> = _state.asStateFlow()

    private val _planeCount = MutableStateFlow(0)
    val planeCount: StateFlow<Int> = _planeCount.asStateFlow()

    private val _lightIntensity = MutableStateFlow(0f)
    val lightIntensity: StateFlow<Float> = _lightIntensity.asStateFlow()

    private val _trackingQuality = MutableStateFlow("Unknown")
    val trackingQuality: StateFlow<String> = _trackingQuality.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    @OnLifecycleEvent(Lifecycle.Event.ON_CREATE)
    fun onCreate() {
        checkArAvailability()
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
    fun onResume() {
        if (session != null && sceneView != null) {
            resumeSession()
        }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
    fun onPause() {
        pauseSession()
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    fun onDestroy() {
        destroySession()
    }

    private fun checkArAvailability() {
        scope.launch {
            _state.value = ArSessionState.CHECKING_AVAILABILITY
            try {
                val availability = ArCoreApk.getInstance().checkAvailability(context)
                when (availability) {
                    ArCoreApk.Availability.SUPPORTED_INSTALLED -> {
                        initializeSession()
                    }
                    ArCoreApk.Availability.SUPPORTED_NOT_INSTALLED -> {
                        _state.value = ArSessionState.REQUESTING_INSTALL
                        val installStatus = ArCoreApk.getInstance().requestInstall(context, true)
                        if (installStatus == ArCoreApk.InstallStatus.INSTALL_REQUESTED) {
                            // User will be prompted to install
                        }
                    }
                    else -> {
                        _state.value = ArSessionState.ERROR
                        _error.value = "ARCore not supported on this device"
                    }
                }
            } catch (e: Exception) {
                Log.e("ArHolographicService", "AR check failed", e)
                _state.value = ArSessionState.ERROR
                _error.value = e.message
            }
        }
    }

    fun setSceneView(sceneView: SceneView) {
        this.sceneView = sceneView
        if (session != null) {
            sceneView.setupSession(session)
            configureScene()
        }
    }

    fun setArFragment(fragment: ArFragment) {
        this.arFragment = fragment
        if (session != null) {
            fragment.setSession(session)
        }
    }

    private fun initializeSession() {
        scope.launch {
            _state.value = ArSessionState.INITIALIZING
            try {
                session = Session(context)
                configureSession()
                
                sceneView?.setupSession(session)
                arFragment?.setSession(session)
                
                configureScene()
                _state.value = ArSessionState.READY
                isSessionConfigured = true
                Log.d("ArHolographicService", "AR Session initialized")
            } catch (e: Exception) {
                Log.e("ArHolographicService", "Session init failed", e)
                _state.value = ArSessionState.ERROR
                _error.value = "Session init failed: ${e.message}"
            }
        }
    }

    private fun configureSession() {
        session?.let { s ->
            val config = Config(s)
            config.updateFocusMode(Config.FocusMode.AUTO)
            config.updatePlaneFindingMode(Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL)
            config.updateLightEstimationMode(Config.LightEstimationMode.AMBIENT_INTENSITY)
            config.updateDepthMode(Config.DepthMode.AUTOMATIC)
            config.updateInstantPlacementMode(Config.InstantPlacementMode.LOCAL_Y_UP)
            s.configure(config)
        }
    }

    private fun configureScene() {
        sceneView?.scene?.addOnUpdateListener { frameTime ->
            onSceneUpdate(frameTime)
        }
    }

    private fun onSceneUpdate(frameTime: FrameTime) {
        if (session == null || sceneView == null) return

        try {
            val frame = sceneView?.arFrame
            frame?.let { f ->
                updateLightEstimation(f)
                updatePlaneTracking(f)
                updateHolograms(f)
            }
        } catch (e: Exception) {
            Log.e("ArHolographicService", "Frame update error", e)
        }
    }

    private fun updateLightEstimation(frame: Frame) {
        val lightEstimate = frame.lightEstimate
        if (lightEstimate?.state == LightEstimate.State.VALID) {
            _lightIntensity.value = lightEstimate.pixelIntensity
        }
    }

    private fun updatePlaneTracking(frame: Frame) {
        val planes = frame.updatedTrackables(Plane::class.java)
        var count = 0
        for (plane in planes) {
            if (plane.trackingState == TrackingState.TRACKING) {
                count++
            }
        }
        _planeCount.value = count
        
        val camera = frame.camera
        _trackingQuality.value = when (camera.trackingState) {
            TrackingState.TRACKING -> "Good"
            TrackingState.PAUSED -> "Paused"
            TrackingState.STOPPED -> "Stopped"
            else -> "Unknown"
        }
    }

    private fun updateHolograms(frame: Frame) {
        // Update hologram positions, rotations, animations
        for (hologram in holograms.values) {
            if (hologram.isVisible && hologram.anchor.trackingState == TrackingState.TRACKING) {
                // Apply animations, rotations, etc.
                animateHologram(hologram, frame)
            }
        }
    }

    private fun animateHologram(hologram: HologramAnchor, frame: Frame) {
        val time = frame.timestamp / 1_000_000_000.0 // Convert to seconds
        
        when (hologram.type) {
            HologramType.ORB -> {
                // Pulse animation
                val pulseScale = 1f + 0.1f * kotlin.math.sin(time * 2.0)
                hologram.node.localScale = Vector3(pulseScale, pulseScale, pulseScale)
                
                // Slow rotation
                hologram.node.localRotation = Quaternion.axisAngle(
                    Vector3(0f, 1f, 0f), 
                    (time * 10f) % 360f
                )
            }
            HologramType.PANEL -> {
                // Face camera
                val camera = frame.camera
                val cameraPose = camera.pose
                val direction = Vector3(
                    cameraPose.tx() - hologram.position.x,
                    cameraPose.ty() - hologram.position.y,
                    cameraPose.tz() - hologram.position.z
                ).normalized()
                hologram.node.lookAt(hologram.node.worldPosition + direction, Vector3(0f, 1f, 0f))
            }
            HologramType.PARTICLES -> {
                // Particle system handled by renderable
            }
            HologramType.SCANNER -> {
                // Rotating scanner beam
                hologram.node.localRotation = Quaternion.axisAngle(
                    Vector3(0f, 1f, 0f),
                    (time * 90f) % 360f
                )
            }
        }
    }

    fun placeHologram(
        type: HologramType,
        hitResult: HitResult,
        onComplete: (HologramAnchor?) -> Unit
    ) {
        if (session == null) {
            onComplete(null)
            return
        }

        scope.launch {
            try {
                val anchor = hitResult.createAnchor()
                val node = createHologramNode(type)
                
                val anchorNode = AnchorNode(anchor)
                anchorNode.setParent(sceneView?.scene)
                anchorNode.addChild(node)

                val pose = hitResult.hitPose
                val position = Vector3(pose.tx(), pose.ty(), pose.tz())
                val rotation = Quaternion(
                    pose.qx(), pose.qy(), pose.qz(), pose.qw()
                )

                val hologram = HologramAnchor(
                    id = java.util.UUID.randomUUID().toString(),
                    type = type,
                    anchor = anchor,
                    node = node,
                    position = position,
                    rotation = rotation
                )

                holograms[hologram.id] = hologram
                onComplete(hologram)

            } catch (e: Exception) {
                Log.e("ArHolographicService", "Place hologram failed", e)
                onComplete(null)
            }
        }
    }

    private fun createHologramNode(type: HologramType): Node {
        return when (type) {
            HologramType.ORB -> createOrbNode()
            HologramType.PANEL -> createPanelNode()
            HologramType.MODEL_3D -> createModelNode()
            HologramType.PARTICLES -> createParticleNode()
            HologramType.TEXT -> createTextNode("JARVIS")
            HologramType.GRID -> createGridNode()
            HologramType.SCANNER -> createScannerNode()
        }
    }

    private fun createOrbNode(): Node {
        val node = Node()
        scope.launch(Dispatchers.IO) {
            try {
                val renderable = ModelRenderable.builder()
                    .setSource(context, com.google.ar.sceneform.R.raw.sphere) // Need sphere model
                    .build()
                    .await()
                
                renderable.material = createHologramMaterial(Color(0x00D4FFFF))
                node.renderable = renderable
                node.localScale = Vector3(0.1f, 0.1f, 0.1f)
            } catch (e: Exception) {
                Log.e("ArHolographicService", "Orb creation failed", e)
            }
        }
        return node
    }

    private fun createPanelNode(): Node {
        val node = Node()
        scope.launch(Dispatchers.IO) {
            try {
                val renderable = ViewRenderable.builder()
                    .setView(context, com.example.R.layout.hologram_panel) // Custom layout
                    .build()
                    .await()
                
                node.renderable = renderable
                node.localScale = Vector3(0.5f, 0.5f, 0.5f)
            } catch (e: Exception) {
                Log.e("ArHolographicService", "Panel creation failed", e)
            }
        }
        return node
    }

    private fun createModelNode(): Node {
        val node = Node()
        // Load 3D model from assets
        return node
    }

    private fun createParticleNode(): Node {
        val node = Node()
        // Create particle system
        return node
    }

    private fun createTextNode(text: String): Node {
        val node = Node()
        scope.launch(Dispatchers.IO) {
            try {
                val renderable = ViewRenderable.builder()
                    .setView(context, com.example.R.layout.hologram_text) // Custom layout with TextView
                    .build()
                    .await()
                
                // Update text in renderable
                node.renderable = renderable
                node.localScale = Vector3(0.3f, 0.3f, 0.3f)
            } catch (e: Exception) {
                Log.e("ArHolographicService", "Text creation failed", e)
            }
        }
        return node
    }

    private fun createGridNode(): Node {
        val node = Node()
        // Create grid floor
        return node
    }

    private fun createScannerNode(): Node {
        val node = Node()
        scope.launch(Dispatchers.IO) {
            try {
                val renderable = ModelRenderable.builder()
                    .setSource(context, com.google.ar.sceneform.R.raw.scanner) // Need scanner model
                    .build()
                    .await()
                
                renderable.material = createHologramMaterial(Color(0xFF6B35FF))
                node.renderable = renderable
                node.localScale = Vector3(0.2f, 0.2f, 0.2f)
            } catch (e: Exception) {
                Log.e("ArHolographicService", "Scanner creation failed", e)
            }
        }
        return node
    }

    private fun createHologramMaterial(color: Color): com.google.ar.sceneform.rendering.Material {
        return com.google.ar.sceneform.rendering.MaterialFactory.makeTransparentWithColor(context, color)
    }

    fun removeHologram(id: String) {
        holograms[id]?.let { hologram ->
            hologram.anchor.detach()
            hologram.node.parent?.removeChild(hologram.node)
            holograms.remove(id)
        }
    }

    fun clearAllHolograms() {
        for (hologram in holograms.values) {
            hologram.anchor.detach()
            hologram.node.parent?.removeChild(hologram.node)
        }
        holograms.clear()
    }

    fun getHologram(id: String): HologramAnchor? = holograms[id]

    fun getAllHolograms(): List<HologramAnchor> = holograms.values.toList()

    fun setHologramVisibility(id: String, visible: Boolean) {
        holograms[id]?.let { hologram ->
            hologram.node.isEnabled = visible
            holograms[id] = hologram.copy(isVisible = visible)
        }
    }

    fun updateHologramPosition(id: String, position: Vector3) {
        holograms[id]?.let { hologram ->
            hologram.node.worldPosition = position
            holograms[id] = hologram.copy(position = position)
        }
    }

    fun updateHologramScale(id: String, scale: Float) {
        holograms[id]?.let { hologram ->
            hologram.node.localScale = Vector3(scale, scale, scale)
            holograms[id] = hologram.copy(scale = scale)
        }
    }

    fun createAnchorAtPose(pose: Pose): Anchor? = session?.createAnchor(pose)

    fun hitTest(x: Float, y: Float): List<HitResult> {
        return sceneView?.scene?.hitTest(x, y) ?: emptyList()
    }

    fun hitTestPlane(x: Float, y: Float): List<HitResult> {
        val frame = sceneView?.arFrame
        return frame?.hitTest(x, y) ?: emptyList()
    }

    fun resumeSession() {
        session?.resume()
        sceneView?.resume()
        arFragment?.onResume()
        _state.value = ArSessionState.TRACKING
    }

    fun pauseSession() {
        sceneView?.pause()
        arFragment?.onPause()
        session?.pause()
        _state.value = ArSessionState.PAUSED
    }

    fun destroySession() {
        clearAllHolograms()
        sceneView?.destroy()
        session?.close()
        session = null
        _state.value = ArSessionState.UNINITIALIZED
    }

    fun takeScreenshot(onBitmap: (Bitmap?) -> Unit) {
        sceneView?.view?.let { view ->
            view.isDrawingCacheEnabled = true
            val bitmap = Bitmap.createBitmap(view.drawingCache)
            view.isDrawingCacheEnabled = false
            onBitmap(bitmap)
        } ?: onBitmap(null)
    }

    companion object {
        private const val TAG = "ArHolographicService"
    }
}